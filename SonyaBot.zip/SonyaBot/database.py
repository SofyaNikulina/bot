# database.py
from sqlalchemy import create_engine, Column, Integer, String, Boolean, DateTime, Text, ForeignKey, JSON, BigInteger, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, scoped_session
from sqlalchemy.sql import func
import datetime
import threading
from config import Config

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False, index=True)
    username = Column(String(100))
    first_name = Column(String(100))
    last_name = Column(String(100))
    phone_number = Column(String(20))
    email = Column(String(100))
    city = Column(String(100))  # ДОБАВЛЕНО: город проживания
    profession = Column(String(100))  # ДОБАВЛЕНО: профессия
    full_name = Column(String(200))  # ДОБАВЛЕНО: ФИО для отправки подарков
    shipping_address = Column(Text)  # ДОБАВЛЕНО: адрес для отправки подарков
    agreed_to_policy = Column(Boolean, default=False)
    agreed_at = Column(DateTime)
    joined_at = Column(DateTime, default=datetime.datetime.utcnow)
    last_activity = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    is_active = Column(Boolean, default=True)
    settings = Column(JSON, default={
        'reminders': True,
        'notifications': True,
        'timezone': 'Europe/Moscow'
    })
    source = Column(String(50))
    notes = Column(Text)
    
    # Relationships
    subscriptions = relationship("Subscription", back_populates="user", cascade="all, delete-orphan")
    payments = relationship("Payment", back_populates="user", cascade="all, delete-orphan")
    promo_usages = relationship("PromoUsage", back_populates="user", cascade="all, delete-orphan")
    messages = relationship("UserMessage", back_populates="user", cascade="all, delete-orphan")

class Subscription(Base):
    __tablename__ = 'subscriptions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'))
    tariff = Column(String(50))
    start_date = Column(DateTime, default=datetime.datetime.utcnow)
    end_date = Column(DateTime)
    is_active = Column(Boolean, default=True)
    auto_renewal = Column(Boolean, default=False)
    join_month = Column(Integer)  # Месяц вступления (1-12)
    join_year = Column(Integer)   # Год вступления
    bonuses_sent = Column(Boolean, default=False)
    bonuses_shipping = Column(String(100))  # Способ доставки бонусов
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    user = relationship("User", back_populates="subscriptions")

class Payment(Base):
    __tablename__ = 'payments'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'))
    amount = Column(Integer)  # Итоговая сумма в копейках
    original_amount = Column(Integer)  # Сумма без скидки
    discount = Column(Integer, default=0)  # Скидка в копейках
    currency = Column(String(10), default='RUB')
    tariff = Column(String(50))
    promocode = Column(String(50))
    order_id = Column(String(100), unique=True, nullable=True, index=True)
    invoice_payload = Column(String(500))
    telegram_payment_charge_id = Column(String(255))
    provider_payment_charge_id = Column(String(255))
    status = Column(String(50), default='pending')  # pending, completed, failed, refunded
    receipt_sent = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    completed_at = Column(DateTime)
    notes = Column(Text)
    
    user = relationship("User", back_populates="payments")

class PromoUsage(Base):
    __tablename__ = 'promo_usages'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'))
    promocode = Column(String(50))
    discount_amount = Column(Integer)
    used_at = Column(DateTime, default=datetime.datetime.utcnow)
    payment_id = Column(Integer, ForeignKey('payments.id'))
    
    user = relationship("User", back_populates="promo_usages")
    payment = relationship("Payment")

class Meeting(Base):
    __tablename__ = 'meetings'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    date_time = Column(DateTime, nullable=False, index=True)
    duration = Column(Integer, default=90)
    zoom_link = Column(String(500))
    zoom_meeting_id = Column(String(100))
    zoom_password = Column(String(100))
    materials = Column(JSON, default=list)
    recording_url = Column(String(500))
    is_active = Column(Boolean, default=True)
    calendar_event_id = Column(String(100))
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

class FAQ(Base):
    __tablename__ = 'faq'
    
    id = Column(Integer, primary_key=True)
    question = Column(String(500), nullable=False)
    answer = Column(Text, nullable=False)
    category = Column(String(50))  # general, payment, technical
    order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Reminder(Base):
    __tablename__ = 'reminders'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'))
    meeting_id = Column(Integer, ForeignKey('meetings.id', ondelete='CASCADE'))
    reminder_type = Column(String(50))  # day_before, 15_min, monthly_7, monthly_last, ignore
    scheduled_time = Column(DateTime, index=True)
    sent = Column(Boolean, default=False)
    sent_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class AbandonedCart(Base):
    __tablename__ = 'abandoned_carts'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'))
    tariff = Column(String(50))
    promocode = Column(String(50))
    step = Column(String(50))  # На каком шаге остановился
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    reminded = Column(Boolean, default=False)
    reminded_at = Column(DateTime)
    converted = Column(Boolean, default=False)

class Metric(Base):
    __tablename__ = 'metrics'
    
    id = Column(Integer, primary_key=True)
    date = Column(DateTime, default=datetime.datetime.utcnow)
    metric_type = Column(String(50))  # registrations, payments, conversion, etc.
    value = Column(Integer)
    details = Column(JSON)

class AdminLog(Base):
    __tablename__ = 'admin_logs'
    
    id = Column(Integer, primary_key=True)
    admin_id = Column(Integer)
    action = Column(String(255))
    details = Column(JSON)
    performed_at = Column(DateTime, default=datetime.datetime.utcnow)

class Promocode(Base):
    __tablename__ = 'promocodes'
    
    id = Column(Integer, primary_key=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    discount_amount = Column(Integer, default=0)  # Скидка в копейках
    discount_percent = Column(Integer, default=0)  # Скидка в процентах
    tariff = Column(String(50))  # Для какого тарифа (если пусто - для всех)
    max_uses = Column(Integer, default=1)  # Максимальное количество использований
    used_count = Column(Integer, default=0)  # Сколько раз использован
    is_active = Column(Boolean, default=True)
    valid_from = Column(DateTime, default=datetime.datetime.utcnow)
    valid_to = Column(DateTime)
    description = Column(String(500))
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    created_by = Column(Integer)  # ID админа, создавшего промокод

class UserMessage(Base):
    __tablename__ = 'user_messages'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, ForeignKey('users.telegram_id', ondelete='CASCADE'))
    message_id = Column(BigInteger)  # ID сообщения в Telegram
    message_text = Column(Text)
    message_type = Column(String(20), default='text')  # 'text', 'photo', 'document', etc
    file_id = Column(String(500), nullable=True)  # Для медиафайлов
    file_caption = Column(Text, nullable=True)  # Подпись к медиа
    forwarded_to_admins = Column(Boolean, default=False)
    forwarded_message_id = Column(BigInteger, nullable=True)  # ID пересланного сообщения у админа
    admin_replied = Column(Boolean, default=False)
    admin_id = Column(BigInteger, nullable=True)  # ID админа, который ответил
    admin_reply = Column(Text, nullable=True)
    replied_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationship
    user = relationship("User", foreign_keys=[telegram_id], back_populates="messages")

class AdminReply(Base):
    __tablename__ = 'admin_replies'
    
    id = Column(Integer, primary_key=True)
    message_id = Column(Integer, ForeignKey('user_messages.id', ondelete='CASCADE'))
    admin_id = Column(BigInteger)
    reply_text = Column(Text)
    sent = Column(Boolean, default=False)
    sent_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationships
    user_message = relationship("UserMessage")

# ==================== УПРАВЛЕНИЕ СОЕДИНЕНИЯМИ ====================

# Глобальные переменные
_engine = None
_SessionFactory = None
_session_local = None

def init_db():
    """Инициализация базы данных с настройками пула соединений"""
    global _engine, _SessionFactory, _session_local
    
    from sqlalchemy.pool import QueuePool
    
    # Создаем engine с настройками пула
    _engine = create_engine(
        Config.DATABASE_URL,
        poolclass=QueuePool,
        pool_size=10,           # Размер пула
        max_overflow=20,        # Максимум дополнительных соединений
        pool_timeout=30,        # Таймаут ожидания соединения
        pool_recycle=3600,      # Пересоздавать соединения каждые 3600 секунд
        pool_pre_ping=True      # Проверять соединение перед использованием
    )
    
    # Создаем фабрику сессий
    _SessionFactory = sessionmaker(bind=_engine)
    
    # Создаем thread-local сессию
    _session_local = scoped_session(_SessionFactory)
    
    # Создаем таблицы
    Base.metadata.create_all(_engine)
    
    logger = logging.getLogger(__name__)
    logger.info("✅ База данных инициализирована с настройками пула")
    
    return _engine

def get_engine():
    """Получение engine"""
    global _engine
    if _engine is None:
        init_db()
    return _engine

def get_session(engine_param=None):
    """
    Получение новой сессии.
    
    Args:
        engine_param: Опционально - engine для создания сессии.
    
    Returns:
        SQLAlchemy сессия
    """
    if engine_param:
        # Создаем новую сессию для переданного engine
        Session = sessionmaker(bind=engine_param)
        return Session()
    else:
        # Используем глобальный engine
        if _engine is None:
            init_db()
        
        # Создаем новую сессию из фабрики
        return _SessionFactory()

def get_scoped_session():
    """Получение thread-local сессии (для использования в одном потоке)"""
    if _session_local is None:
        init_db()
    return _session_local()

def close_session(session):
    """Закрытие сессии"""
    try:
        if session:
            session.close()
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.warning(f"Ошибка при закрытии сессии: {e}")

def cleanup_session(session):
    """Очистка и закрытие сессии (безопасный способ)"""
    if session:
        try:
            session.rollback()  # Откатываем несохраненные изменения
        except:
            pass
        finally:
            session.close()

# Удобные алиасы
create_session = get_session
create_session_with_engine = get_session

def safe_db_operation(func):
    """Декоратор для безопасных операций с БД"""
    def wrapper(*args, **kwargs):
        session = None
        try:
            # Создаем сессию
            session = get_session()
            
            # Добавляем сессию в аргументы если функция ее ожидает
            if 'session' in func.__code__.co_varnames:
                kwargs['session'] = session
            
            # Выполняем функцию
            result = func(*args, **kwargs)
            
            # Коммитим если все ок
            if session:
                session.commit()
            
            return result
            
        except Exception as e:
            # Откатываем в случае ошибки
            if session:
                session.rollback()
            raise e
        finally:
            # Всегда закрываем сессию
            if session:
                cleanup_session(session)
    
    return wrapper

# Инициализируем логгер
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Автоматическая инициализация при импорте
try:
    init_db()
    logger.info("✅ Database module initialized")
except Exception as e:
    logger.error(f"❌ Error initializing database: {e}")