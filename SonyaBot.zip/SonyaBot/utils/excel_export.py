# utils/excel_export.py
import logging
import pandas as pd
from datetime import datetime, timedelta
from database import get_session, User, Payment, Subscription, PromoUsage, Promocode, Meeting
import os

logger = logging.getLogger(__name__)

def export_users_to_excel(session, output_path='exports/users_export.xlsx'):
    """Экспорт пользователей в Excel - ОБНОВЛЕН с новыми полями"""
    try:
        # Создаем директорию если ее нет
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        users = session.query(User).all()
        
        # Создаем DataFrame
        data = []
        for user in users:
            # Получаем активную подписку
            subscription = session.query(Subscription).filter_by(
                user_id=user.id,
                is_active=True
            ).order_by(Subscription.created_at.desc()).first()
            
            # Получаем последний платеж
            last_payment = session.query(Payment).filter_by(
                user_id=user.id,
                status='completed'
            ).order_by(Payment.completed_at.desc()).first()
            
            row = {
                'ID': user.id,
                'Telegram ID': user.telegram_id,
                'Username': user.username or '',
                'Имя': user.first_name or '',
                'Фамилия': user.last_name or '',
                'ФИО (для подарков)': user.full_name or '',  # НОВОЕ ПОЛЕ
                'Телефон': user.phone_number or '',
                'Email': user.email or '',
                'Город': user.city or '',  # НОВОЕ ПОЛЕ
                'Профессия': user.profession or '',  # НОВОЕ ПОЛЕ
                'Адрес для подарков': user.shipping_address or '',  # НОВОЕ ПОЛЕ
                'Дата регистрации': user.joined_at.strftime('%Y-%m-%d %H:%M') if user.joined_at else '',
                'Последняя активность': user.last_activity.strftime('%Y-%m-%d %H:%M') if user.last_activity else '',
                'Активен': 'Да' if user.is_active else 'Нет',
                'Согласие на политику': 'Да' if user.agreed_to_policy else 'Нет',
                'Дата согласия': user.agreed_at.strftime('%Y-%m-%d %H:%M') if user.agreed_at else '',
                
                # Информация о подписке
                'Тариф': subscription.tariff if subscription else 'Нет',
                'Начало подписки': subscription.start_date.strftime('%Y-%m-%d') if subscription else '',
                'Окончание подписки': subscription.end_date.strftime('%Y-%m-%d') if subscription else '',
                'Активна подписка': 'Да' if subscription and subscription.is_active else 'Нет',
                'Автопродление': 'Да' if subscription and subscription.auto_renewal else 'Нет',
                'Месяц вступления': subscription.join_month if subscription else '',
                'Год вступления': subscription.join_year if subscription else '',
                'Бонусы отправлены': 'Да' if subscription and subscription.bonuses_sent else 'Нет',
                'Способ доставки бонусов': subscription.bonuses_shipping if subscription else '',
                
                # Информация о платежах
                'Последний платеж': last_payment.amount/100 if last_payment else 0,
                'Дата последнего платежа': last_payment.completed_at.strftime('%Y-%m-%d %H:%M') if last_payment and last_payment.completed_at else '',
                'Промокод в последнем платеже': last_payment.promocode if last_payment else '',
                'Всего платежей': session.query(Payment).filter_by(user_id=user.id, status='completed').count(),
                'Общая сумма платежей': sum(p.amount for p in session.query(Payment).filter_by(user_id=user.id, status='completed').all())/100 if session.query(Payment).filter_by(user_id=user.id, status='completed').count() > 0 else 0,
                
                # Источник и заметки
                'Источник': user.source or '',
                'Заметки': user.notes or '',
            }
            data.append(row)
        
        df = pd.DataFrame(data)
        
        # Настраиваем ширину колонок
        column_widths = {
            'ID': 8,
            'Telegram ID': 12,
            'Username': 15,
            'Имя': 15,
            'Фамилия': 15,
            'ФИО (для подарков)': 25,
            'Телефон': 15,
            'Email': 25,
            'Город': 15,
            'Профессия': 20,
            'Адрес для подарков': 40,
            'Дата регистрации': 18,
            'Последняя активность': 18,
            'Активен': 8,
            'Согласие на политику': 8,
            'Дата согласия': 18,
            'Тариф': 12,
            'Начало подписки': 12,
            'Окончание подписки': 12,
            'Активна подписка': 8,
            'Автопродление': 8,
            'Месяц вступления': 10,
            'Год вступления': 10,
            'Бонусы отправлены': 8,
            'Способ доставки бонусов': 15,
            'Последний платеж': 12,
            'Дата последнего платежа': 18,
            'Промокод в последнем платеже': 20,
            'Всего платежей': 10,
            'Общая сумма платежей': 15,
            'Источник': 15,
            'Заметки': 30,
        }
        
        # Сохраняем в Excel с авто-шириной колонок
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Пользователи', index=False)
            
            # Получаем лист и настраиваем ширину колонок
            worksheet = writer.sheets['Пользователи']
            for i, column in enumerate(df.columns, 1):
                width = column_widths.get(column, 15)
                worksheet.column_dimensions[chr(64 + i)].width = width
            
            # Добавляем автофильтр
            worksheet.auto_filter.ref = worksheet.dimensions
        
        logger.info(f"✅ Экспорт пользователей завершен: {len(users)} записей, файл: {output_path}")
        return output_path
        
    except Exception as e:
        logger.error(f"❌ Ошибка при экспорте пользователей: {e}")
        raise

def export_payments_to_excel(session, output_path='exports/payments_export.xlsx'):
    """Экспорт платежей в Excel - ОБНОВЛЕН"""
    try:
        # Создаем директорию если ее нет
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        payments = session.query(Payment).order_by(Payment.created_at.desc()).all()
        
        # Создаем DataFrame
        data = []
        for payment in payments:
            user = payment.user
            
            # Получаем информацию о пользователе с новыми полями
            user_info = f"{user.first_name or ''} {user.last_name or ''}".strip()
            if not user_info:
                user_info = f"ID: {user.telegram_id}"
            
            row = {
                'ID платежа': payment.id,
                'ID пользователя': payment.user_id,
                'Пользователь': user_info,
                'Username': user.username or '',
                'Email пользователя': user.email or '',  # НОВОЕ ПОЛЕ
                'Город пользователя': user.city or '',  # НОВОЕ ПОЛЕ
                'Телефон': user.phone_number or '',
                'Сумма (руб)': payment.amount / 100,
                'Исходная сумма (руб)': payment.original_amount / 100 if payment.original_amount else payment.amount / 100,
                'Скидка (руб)': payment.discount / 100,
                'Валюта': payment.currency,
                'Тариф': payment.tariff or '',
                'Промокод': payment.promocode or '',
                'Статус': payment.status,
                'Order ID': payment.order_id or '',
                'Payment ID': payment.provider_payment_charge_id or '',
                'Чек отправлен': 'Да' if payment.receipt_sent else 'Нет',
                'Дата создания': payment.created_at.strftime('%Y-%m-%d %H:%M') if payment.created_at else '',
                'Дата завершения': payment.completed_at.strftime('%Y-%m-%d %H:%M') if payment.completed_at else '',
                'Заметки': payment.notes or '',
            }
            data.append(row)
        
        df = pd.DataFrame(data)
        
        # Настраиваем ширину колонок
        column_widths = {
            'ID платежа': 10,
            'ID пользователя': 12,
            'Пользователь': 20,
            'Username': 15,
            'Email пользователя': 25,
            'Город пользователя': 15,
            'Телефон': 15,
            'Сумма (руб)': 12,
            'Исходная сумма (руб)': 12,
            'Скидка (руб)': 12,
            'Валюта': 8,
            'Тариф': 12,
            'Промокод': 15,
            'Статус': 10,
            'Order ID': 20,
            'Payment ID': 20,
            'Чек отправлен': 10,
            'Дата создания': 18,
            'Дата завершения': 18,
            'Заметки': 25,
        }
        
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Платежи', index=False)
            
            worksheet = writer.sheets['Платежи']
            for i, column in enumerate(df.columns, 1):
                width = column_widths.get(column, 15)
                worksheet.column_dimensions[chr(64 + i)].width = width
            
            # Добавляем автофильтр
            worksheet.auto_filter.ref = worksheet.dimensions
        
        logger.info(f"✅ Экспорт платежей завершен: {len(payments)} записей, файл: {output_path}")
        return output_path
        
    except Exception as e:
        logger.error(f"❌ Ошибка при экспорте платежей: {e}")
        raise

def export_subscriptions_to_excel(session, output_path='exports/subscriptions_export.xlsx'):
    """Экспорт подписок в Excel - ОБНОВЛЕН"""
    try:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        subscriptions = session.query(Subscription).order_by(Subscription.created_at.desc()).all()
        
        data = []
        for sub in subscriptions:
            user = sub.user
            
            # Получаем информацию о пользователе с новыми полями
            user_info = f"{user.first_name or ''} {user.last_name or ''}".strip()
            if not user_info:
                user_info = f"ID: {user.telegram_id}"
            
            row = {
                'ID подписки': sub.id,
                'ID пользователя': sub.user_id,
                'Пользователь': user_info,
                'Username': user.username or '',
                'Email': user.email or '',  # НОВОЕ ПОЛЕ
                'Город': user.city or '',  # НОВОЕ ПОЛЕ
                'Профессия': user.profession or '',  # НОВОЕ ПОЛЕ
                'Телефон': user.phone_number or '',
                'ФИО для подарков': user.full_name or '',  # НОВОЕ ПОЛЕ
                'Адрес для подарков': user.shipping_address or '',  # НОВОЕ ПОЛЕ
                'Тариф': sub.tariff or '',
                'Дата начала': sub.start_date.strftime('%Y-%m-%d') if sub.start_date else '',
                'Дата окончания': sub.end_date.strftime('%Y-%m-%d') if sub.end_date else '',
                'Активна': 'Да' if sub.is_active else 'Нет',
                'Автопродление': 'Да' if sub.auto_renewal else 'Нет',
                'Месяц вступления': sub.join_month or '',
                'Год вступления': sub.join_year or '',
                'Бонусы отправлены': 'Да' if sub.bonuses_sent else 'Нет',
                'Способ доставки бонусов': sub.bonuses_shipping or '',
                'Дата создания': sub.created_at.strftime('%Y-%m-%d %H:%M') if sub.created_at else '',
            }
            data.append(row)
        
        df = pd.DataFrame(data)
        
        column_widths = {
            'ID подписки': 12,
            'ID пользователя': 12,
            'Пользователь': 20,
            'Username': 15,
            'Email': 25,
            'Город': 15,
            'Профессия': 20,
            'Телефон': 15,
            'ФИО для подарков': 25,
            'Адрес для подарков': 40,
            'Тариф': 15,
            'Дата начала': 12,
            'Дата окончания': 12,
            'Активна': 8,
            'Автопродление': 8,
            'Месяц вступления': 12,
            'Год вступления': 10,
            'Бонусы отправлены': 10,
            'Способ доставки бонусов': 20,
            'Дата создания': 18,
        }
        
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Подписки', index=False)
            
            worksheet = writer.sheets['Подписки']
            for i, column in enumerate(df.columns, 1):
                width = column_widths.get(column, 15)
                worksheet.column_dimensions[chr(64 + i)].width = width
            
            worksheet.auto_filter.ref = worksheet.dimensions
        
        logger.info(f"✅ Экспорт подписок завершен: {len(subscriptions)} записей, файл: {output_path}")
        return output_path
        
    except Exception as e:
        logger.error(f"❌ Ошибка при экспорте подписок: {e}")
        raise

def export_promocodes_to_excel(session, output_path='exports/promocodes_export.xlsx'):
    """Экспорт промокодов в Excel"""
    try:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        promocodes = session.query(Promocode).order_by(Promocode.created_at.desc()).all()
        
        data = []
        for promo in promocodes:
            # Получаем информацию об использовании
            usages = session.query(PromoUsage).filter_by(promocode=promo.code).all()
            users_who_used = []
            total_discount = 0
            
            for usage in usages:
                user = usage.user
                user_info = f"{user.first_name or ''} {user.last_name or ''}".strip()
                if user.username:
                    user_info += f" (@{user.username})"
                else:
                    user_info += f" (ID: {user.telegram_id})"
                users_who_used.append(user_info)
                total_discount += usage.discount_amount
            
            row = {
                'ID': promo.id,
                'Код': promo.code,
                'Скидка (руб)': promo.discount_amount / 100 if promo.discount_amount > 0 else 0,
                'Скидка (%)': promo.discount_percent if promo.discount_percent > 0 else 0,
                'Тариф': promo.tariff or 'Все',
                'Макс. использований': promo.max_uses,
                'Использовано': promo.used_count,
                'Осталось использований': promo.max_uses - promo.used_count,
                'Активен': 'Да' if promo.is_active else 'Нет',
                'Дата начала': promo.valid_from.strftime('%Y-%m-%d') if promo.valid_from else '',
                'Дата окончания': promo.valid_to.strftime('%Y-%m-%d') if promo.valid_to else '',
                'Создан': promo.created_at.strftime('%Y-%m-%d %H:%M') if promo.created_at else '',
                'Создатель (ID)': promo.created_by or '',
                'Описание': promo.description or '',
                'Общая скидка (руб)': total_discount / 100,
                'Использовали': ', '.join(users_who_used) if users_who_used else 'Никто'
            }
            data.append(row)
        
        df = pd.DataFrame(data)
        
        column_widths = {
            'ID': 8,
            'Код': 15,
            'Скидка (руб)': 12,
            'Скидка (%)': 10,
            'Тариф': 12,
            'Макс. использований': 12,
            'Использовано': 10,
            'Осталось использований': 12,
            'Активен': 8,
            'Дата начала': 12,
            'Дата окончания': 12,
            'Создан': 18,
            'Создатель (ID)': 12,
            'Описание': 25,
            'Общая скидка (руб)': 15,
            'Использовали': 40,
        }
        
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Промокоды', index=False)
            
            worksheet = writer.sheets['Промокоды']
            for i, column in enumerate(df.columns, 1):
                width = column_widths.get(column, 15)
                worksheet.column_dimensions[chr(64 + i)].width = width
            
            worksheet.auto_filter.ref = worksheet.dimensions
        
        logger.info(f"✅ Экспорт промокодов завершен: {len(promocodes)} записей, файл: {output_path}")
        return output_path
        
    except Exception as e:
        logger.error(f"❌ Ошибка при экспорте промокодов: {e}")
        raise

def export_meetings_to_excel(session, output_path='exports/meetings_export.xlsx'):
    """Экспорт встреч в Excel"""
    try:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        meetings = session.query(Meeting).order_by(Meeting.date_time.desc()).all()
        
        data = []
        for meeting in meetings:
            row = {
                'ID встречи': meeting.id,
                'Название': meeting.title,
                'Описание': meeting.description or '',
                'Дата и время': meeting.date_time.strftime('%Y-%m-%d %H:%M') if meeting.date_time else '',
                'Продолжительность (мин)': meeting.duration,
                'Zoom ссылка': meeting.zoom_link or '',
                'Zoom ID': meeting.zoom_meeting_id or '',
                'Zoom пароль': meeting.zoom_password or '',
                'Запись': meeting.recording_url or '',
                'Активна': 'Да' if meeting.is_active else 'Нет',
                'ID события календаря': meeting.calendar_event_id or '',
                'Создана': meeting.created_at.strftime('%Y-%m-%d %H:%M') if meeting.created_at else '',
                'Обновлена': meeting.updated_at.strftime('%Y-%m-%d %H:%M') if meeting.updated_at else '',
            }
            data.append(row)
        
        df = pd.DataFrame(data)
        
        column_widths = {
            'ID встречи': 10,
            'Название': 30,
            'Описание': 40,
            'Дата и время': 18,
            'Продолжительность (мин)': 15,
            'Zoom ссылка': 40,
            'Zoom ID': 15,
            'Zoom пароль': 12,
            'Запись': 40,
            'Активна': 8,
            'ID события календаря': 20,
            'Создана': 18,
            'Обновлена': 18,
        }
        
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Встречи', index=False)
            
            worksheet = writer.sheets['Встречи']
            for i, column in enumerate(df.columns, 1):
                width = column_widths.get(column, 15)
                worksheet.column_dimensions[chr(64 + i)].width = width
            
            worksheet.auto_filter.ref = worksheet.dimensions
        
        logger.info(f"✅ Экспорт встреч завершен: {len(meetings)} записей, файл: {output_path}")
        return output_path
        
    except Exception as e:
        logger.error(f"❌ Ошибка при экспорте встреч: {e}")
        raise

def export_full_report(session, output_path='exports/full_report.xlsx'):
    """Полный отчет со всеми данными в одном файле на разных листах"""
    try:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            # Лист с пользователями
            users = session.query(User).all()
            users_data = []
            for user in users:
                subscription = session.query(Subscription).filter_by(
                    user_id=user.id,
                    is_active=True
                ).order_by(Subscription.created_at.desc()).first()
                
                users_data.append({
                    'ID': user.id,
                    'Telegram ID': user.telegram_id,
                    'Username': user.username or '',
                    'Имя': user.first_name or '',
                    'Фамилия': user.last_name or '',
                    'ФИО (для подарков)': user.full_name or '',
                    'Телефон': user.phone_number or '',
                    'Email': user.email or '',
                    'Город': user.city or '',
                    'Профессия': user.profession or '',
                    'Адрес для подарков': user.shipping_address or '',
                    'Дата регистрации': user.joined_at.strftime('%Y-%m-%d') if user.joined_at else '',
                    'Тариф': subscription.tariff if subscription else 'Нет',
                    'Подписка активна': 'Да' if subscription else 'Нет',
                    'Дата окончания подписки': subscription.end_date.strftime('%Y-%m-%d') if subscription else '',
                })
            
            users_df = pd.DataFrame(users_data)
            users_df.to_excel(writer, sheet_name='Пользователи', index=False)
            
            # Настройка ширины колонок для пользователей
            users_worksheet = writer.sheets['Пользователи']
            users_column_widths = {
                'ID': 8, 'Telegram ID': 12, 'Username': 15, 'Имя': 15, 'Фамилия': 15,
                'ФИО (для подарков)': 25, 'Телефон': 15, 'Email': 25, 'Город': 15,
                'Профессия': 20, 'Адрес для подарков': 40, 'Дата регистрации': 15,
                'Тариф': 12, 'Подписка активна': 12, 'Дата окончания подписки': 15
            }
            for i, column in enumerate(users_df.columns, 1):
                width = users_column_widths.get(column, 15)
                users_worksheet.column_dimensions[chr(64 + i)].width = width
            users_worksheet.auto_filter.ref = users_worksheet.dimensions
            
            # Лист с платежами за последние 30 дней
            thirty_days_ago = datetime.now() - timedelta(days=30)
            recent_payments = session.query(Payment).filter(
                Payment.created_at >= thirty_days_ago,
                Payment.status == 'completed'
            ).order_by(Payment.created_at.desc()).all()
            
            payments_data = []
            for payment in recent_payments:
                user = payment.user
                payments_data.append({
                    'Дата': payment.completed_at.strftime('%Y-%m-%d') if payment.completed_at else '',
                    'Пользователь': f"{user.first_name or ''} {user.last_name or ''}".strip() or f"ID: {user.telegram_id}",
                    'Email': user.email or '',
                    'Тариф': payment.tariff or '',
                    'Сумма (руб)': payment.amount / 100,
                    'Скидка (руб)': payment.discount / 100,
                    'Промокод': payment.promocode or '',
                    'Order ID': payment.order_id or '',
                })
            
            payments_df = pd.DataFrame(payments_data)
            payments_df.to_excel(writer, sheet_name='Последние платежи', index=False)
            
            # Лист со статистикой
            total_users = session.query(User).count()
            active_subscriptions = session.query(Subscription).filter_by(is_active=True).count()
            recent_payments_count = len(recent_payments)
            recent_revenue = sum(p.amount for p in recent_payments) / 100 if recent_payments else 0
            
            # Распределение по тарифам
            tariffs = {}
            all_subscriptions = session.query(Subscription).filter_by(is_active=True).all()
            for sub in all_subscriptions:
                tariffs[sub.tariff] = tariffs.get(sub.tariff, 0) + 1
            
            stats_data = [{
                'Метрика': 'Всего пользователей',
                'Значение': total_users
            }, {
                'Метрика': 'Активных подписок',
                'Значение': active_subscriptions
            }, {
                'Метрика': 'Платежей за 30 дней',
                'Значение': recent_payments_count
            }, {
                'Метрика': 'Выручка за 30 дней (руб)',
                'Значение': recent_revenue
            }]
            
            for tariff, count in tariffs.items():
                stats_data.append({
                    'Метрика': f'Тариф: {tariff}',
                    'Значение': count
                })
            
            # Распределение по городам (первые 10)
            cities = {}
            all_users = session.query(User).filter(User.city.isnot(None)).all()
            for user in all_users:
                if user.city:
                    cities[user.city] = cities.get(user.city, 0) + 1
            
            sorted_cities = sorted(cities.items(), key=lambda x: x[1], reverse=True)[:10]
            for city, count in sorted_cities:
                stats_data.append({
                    'Метрика': f'Город: {city}',
                    'Значение': count
                })
            
            # Распределение по профессиям
            professions = {}
            for user in all_users:
                if user.profession:
                    professions[user.profession] = professions.get(user.profession, 0) + 1
            
            for profession, count in professions.items():
                stats_data.append({
                    'Метрика': f'Профессия: {profession}',
                    'Значение': count
                })
            
            stats_df = pd.DataFrame(stats_data)
            stats_df.to_excel(writer, sheet_name='Статистика', index=False)
            
            # Лист с годовыми подписками для отправки подарков
            yearly_subs = session.query(Subscription).filter_by(
                tariff='12_months',
                is_active=True,
                bonuses_sent=False
            ).all()
            
            gifts_data = []
            for sub in yearly_subs:
                user = sub.user
                gifts_data.append({
                    'ID пользователя': user.id,
                    'ФИО': user.full_name or '',
                    'Телефон': user.phone_number or '',
                    'Email': user.email or '',
                    'Адрес': user.shipping_address or '',
                    'Город': user.city or '',
                    'Дата начала подписки': sub.start_date.strftime('%Y-%m-%d') if sub.start_date else '',
                    'Дата окончания': sub.end_date.strftime('%Y-%m-%d') if sub.end_date else '',
                    'Статус отправки': sub.bonuses_shipping or 'ожидает отправки',
                })
            
            gifts_df = pd.DataFrame(gifts_data)
            gifts_df.to_excel(writer, sheet_name='Отправка подарков', index=False)
            
            # Настройка ширины колонок для подарков
            gifts_worksheet = writer.sheets['Отправка подарков']
            gifts_column_widths = {
                'ID пользователя': 12, 'ФИО': 25, 'Телефон': 15, 'Email': 25,
                'Адрес': 40, 'Город': 15, 'Дата начала подписки': 15,
                'Дата окончания': 15, 'Статус отправки': 20
            }
            for i, column in enumerate(gifts_df.columns, 1):
                width = gifts_column_widths.get(column, 15)
                gifts_worksheet.column_dimensions[chr(64 + i)].width = width
            gifts_worksheet.auto_filter.ref = gifts_worksheet.dimensions
            
            logger.info(f"✅ Полный отчет создан: файл {output_path}")
            return output_path
            
    except Exception as e:
        logger.error(f"❌ Ошибка при создании полного отчета: {e}")
        raise

async def handle_excel_export_request(session, export_type, user_id, bot):
    """Асинхронная обработка запроса на экспорт в Excel"""
    try:
        # Создаем имя файла с датой
        date_str = datetime.now().strftime('%Y%m%d_%H%M')
        
        if export_type == 'excel_users':
            filename = f"exports/users_export_{date_str}.xlsx"
            filepath = export_users_to_excel(session, filename)
            caption = f"📊 <b>Экспорт пользователей</b>\n\nФайл содержит информацию обо всех пользователях с новыми полями (город, профессия, ФИО, адрес для подарков)."
            
        elif export_type == 'excel_payments':
            filename = f"exports/payments_export_{date_str}.xlsx"
            filepath = export_payments_to_excel(session, filename)
            caption = f"💰 <b>Экспорт платежей</b>\n\nФайл содержит информацию обо всех платежах с email пользователей."
            
        elif export_type == 'excel_subscriptions':
            filename = f"exports/subscriptions_export_{date_str}.xlsx"
            filepath = export_subscriptions_to_excel(session, filename)
            caption = f"📅 <b>Экспорт подписок</b>\n\nФайл содержит информацию обо всех активных и неактивных подписках."
            
        elif export_type == 'excel_promocodes':
            filename = f"exports/promocodes_export_{date_str}.xlsx"
            filepath = export_promocodes_to_excel(session, filename)
            caption = f"🎫 <b>Экспорт промокодов</b>\n\nФайл содержит информацию обо всех промокодах и их использовании."
            
        elif export_type == 'excel_meetings':
            filename = f"exports/meetings_export_{date_str}.xlsx"
            filepath = export_meetings_to_excel(session, filename)
            caption = f"📅 <b>Экспорт встреч</b>\n\nФайл содержит информацию обо всех встречах."
            
        elif export_type == 'excel_full_report':
            filename = f"exports/full_report_{date_str}.xlsx"
            filepath = export_full_report(session, filename)
            caption = f"📈 <b>Полный отчет</b>\n\nФайл содержит:\n• Пользователей\n• Последние платежи\n• Статистику\n• Данные для отправки подарков\n\nС новыми полями: город, профессия, email, ФИО, адрес."
            
        else:
            raise ValueError(f"Неизвестный тип экспорта: {export_type}")
        
        # Отправляем файл пользователю
        with open(filepath, 'rb') as file:
            await bot.send_document(
                chat_id=user_id,
                document=file,
                caption=caption,
                parse_mode='HTML'
            )
        
        logger.info(f"✅ Файл экспорта отправлен пользователю {user_id}: {filepath}")
        return True
        
    except Exception as e:
        logger.error(f"❌ Ошибка при экспорте в Excel: {e}")
        raise