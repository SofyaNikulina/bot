# reports.py
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import pandas as pd
from io import BytesIO
from telegram import Update, InputFile, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from database import get_session, User, Payment, Subscription, Meeting, PromoUsage, AbandonedCart, Promocode
from config import Config
import json
# УДАЛЕН: from utils.excel_export import ExcelExporter

logger = logging.getLogger(__name__)

class ReportManager:
    """Менеджер отчетов для администраторов"""
    
    def __init__(self, engine):
        self.engine = engine
    
    async def generate_comprehensive_report(self, start_date: datetime = None, end_date: datetime = None) -> Dict:
        """Генерация полного отчета по вашим требованиям"""
        if not start_date:
            start_date = datetime.now() - timedelta(days=7)
        if not end_date:
            end_date = datetime.now()
        
        session = get_session(self.engine)
        
        try:
            # Собираем ВСЕ данные для отчета
            report_data = {
                'period': f"{start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}",
                
                # 1. ОБЩАЯ СТАТИСТИКА
                'general_stats': await self._get_comprehensive_general_stats(session, start_date, end_date),
                
                # 2. ФИНАНСЫ
                'financial_stats': await self._get_comprehensive_financial_stats(session, start_date, end_date),
                
                # 3. ПОДПИСКИ
                'subscription_stats': await self._get_comprehensive_subscription_stats(session, start_date, end_date),
                
                # 4. КОНВЕРСИЯ
                'conversion_stats': await self._get_comprehensive_conversion_stats(session, start_date, end_date),
                
                # 5. БРОШЕННЫЕ КОРЗИНЫ
                'abandoned_carts': await self._get_comprehensive_abandoned_carts(session, start_date, end_date),
                
                # 6. ПРОМОКОДЫ
                'promocode_stats': await self._get_comprehensive_promocode_stats(session, start_date, end_date),
                
                # 7. ВСТРЕЧИ
                'meeting_stats': await self._get_comprehensive_meeting_stats(session, start_date, end_date),
            }
            
            return report_data
            
        except Exception as e:
            logger.error(f"Ошибка генерации отчета: {e}")
            raise
        finally:
            session.close()
    
    async def _get_comprehensive_general_stats(self, session, start_date: datetime, end_date: datetime) -> Dict:
        """ОБЩАЯ СТАТИСТИКА по вашим требованиям"""
        stats = {}
        
        # Всего пользователей
        stats['total_users'] = session.query(User).count()
        
        # Новые пользователи за период
        stats['new_users'] = session.query(User).filter(
            User.joined_at >= start_date,
            User.joined_at <= end_date
        ).count()
        
        # Активные пользователи (были активны в последние 30 дней)
        month_ago = datetime.now() - timedelta(days=30)
        stats['active_users'] = session.query(User).filter(
            User.last_activity >= month_ago,
            User.is_active == True
        ).count()
        
        return stats
    
    async def _get_comprehensive_financial_stats(self, session, start_date: datetime, end_date: datetime) -> Dict:
        """ФИНАНСЫ по вашим требованиям"""
        stats = {}
        
        # Все платежи за период
        payments = session.query(Payment).filter(
            Payment.created_at >= start_date,
            Payment.created_at <= end_date,
            Payment.status == 'completed'
        ).all()
        
        stats['total_payments'] = len(payments)
        stats['total_revenue'] = sum(p.amount for p in payments) / 100  # в рублях
        
        # Средний чек
        stats['avg_check'] = stats['total_revenue'] / max(stats['total_payments'], 1)
        
        # Возвраты
        refunds = session.query(Payment).filter(
            Payment.created_at >= start_date,
            Payment.created_at <= end_date,
            Payment.status == 'refunded'
        ).count()
        
        stats['refunds'] = refunds
        
        return stats
    
    async def _get_comprehensive_subscription_stats(self, session, start_date: datetime, end_date: datetime) -> Dict:
        """ПОДПИСКИ по вашим требованиям"""
        stats = {}
        
        # Активные подписки (is_active = True)
        active_subs = session.query(Subscription).filter(
            Subscription.is_active == True
        ).all()
        
        stats['active_subscriptions'] = len(active_subs)
        
        # Новые подписки за период
        new_subs = session.query(Subscription).filter(
            Subscription.start_date >= start_date,
            Subscription.start_date <= end_date
        ).count()
        
        stats['new_subscriptions'] = new_subs
        
        # Заканчивающиеся подписки (в ближайшие 7 дней)
        week_later = datetime.now() + timedelta(days=7)
        ending_subs = session.query(Subscription).filter(
            Subscription.end_date <= week_later,
            Subscription.end_date >= datetime.now(),
            Subscription.is_active == True
        ).count()
        
        stats['ending_subscriptions'] = ending_subs
        
        # Отказы от продления (подписки, которые закончились и не продлены за период)
        expired_not_renewed = session.query(Subscription).filter(
            Subscription.end_date >= start_date,
            Subscription.end_date <= end_date,
            Subscription.is_active == False,
            Subscription.auto_renewal == False
        ).count()
        
        stats['expired_not_renewed'] = expired_not_renewed
        
        # Отписки (пользователи отменили подписку)
        cancelled_subs = session.query(Subscription).filter(
            Subscription.end_date >= datetime.now(),  # еще не закончилась
            Subscription.is_active == False  # но уже неактивна
        ).count()
        
        stats['cancelled_subscriptions'] = cancelled_subs
        
        # Распределение по тарифам
        tariff_dist = {}
        for sub in active_subs:
            tariff_dist[sub.tariff] = tariff_dist.get(sub.tariff, 0) + 1
        
        stats['tariff_distribution'] = tariff_dist
        
        return stats
    
    async def _get_comprehensive_conversion_stats(self, session, start_date: datetime, end_date: datetime) -> Dict:
        """КОНВЕРСИЯ по вашим требованиям"""
        stats = {}
        
        # Все пользователи за период
        all_users = session.query(User).filter(
            User.joined_at >= start_date,
            User.joined_at <= end_date
        ).count()
        
        stats['total_users_period'] = all_users
        
        # Пользователи с оплатой за период
        paid_users = session.query(User).join(Payment).filter(
            Payment.created_at >= start_date,
            Payment.created_at <= end_date,
            Payment.status == 'completed',
            User.joined_at >= start_date,
            User.joined_at <= end_date
        ).distinct().count()
        
        stats['paid_users'] = paid_users
        
        # Конверсия в оплату
        if all_users > 0:
            stats['conversion_rate'] = (paid_users / all_users) * 100
        else:
            stats['conversion_rate'] = 0
        
        return stats
    
    async def _get_comprehensive_abandoned_carts(self, session, start_date: datetime, end_date: datetime) -> Dict:
        """БРОШЕННЫЕ КОРЗИНЫ по вашим требованиям"""
        stats = {}
        
        # Все брошенные корзины за период
        carts = session.query(AbandonedCart).filter(
            AbandonedCart.created_at >= start_date,
            AbandonedCart.created_at <= end_date
        ).all()
        
        stats['total_carts'] = len(carts)
        
        # Конвертированные корзины
        converted = session.query(AbandonedCart).filter(
            AbandonedCart.converted == True,
            AbandonedCart.created_at >= start_date,
            AbandonedCart.created_at <= end_date
        ).count()
        
        stats['converted_carts'] = converted
        
        # Конверсия из корзин
        if len(carts) > 0:
            stats['cart_conversion_rate'] = (converted / len(carts)) * 100
        else:
            stats['cart_conversion_rate'] = 0
        
        return stats
    
    async def _get_comprehensive_promocode_stats(self, session, start_date: datetime, end_date: datetime) -> Dict:
        """ПРОМОКОДЫ по вашим требованиям"""
        stats = {}
        
        # Использованные промокоды за период
        promo_usages = session.query(PromoUsage).filter(
            PromoUsage.used_at >= start_date,
            PromoUsage.used_at <= end_date
        ).all()
        
        stats['used_promocodes'] = len(promo_usages)
        
        # Общая сумма скидок
        total_discount = sum(usage.discount_amount for usage in promo_usages) / 100  # в рублях
        stats['total_discount'] = total_discount
        
        # Активные промокоды
        active_promos = session.query(Promocode).filter(
            Promocode.is_active == True
        ).count()
        
        stats['active_promocodes'] = active_promos
        
        return stats
    
    async def _get_comprehensive_meeting_stats(self, session, start_date: datetime, end_date: datetime) -> Dict:
        """ВСТРЕЧИ по вашим требованиям"""
        stats = {}
        
        # Предстоящие встречи
        upcoming = session.query(Meeting).filter(
            Meeting.date_time >= datetime.now(),
            Meeting.is_active == True
        ).count()
        
        stats['upcoming_meetings'] = upcoming
        
        # Прошедшие встречи за период
        past_meetings = session.query(Meeting).filter(
            Meeting.date_time >= start_date,
            Meeting.date_time <= end_date,
            Meeting.date_time < datetime.now()
        ).count()
        
        stats['past_meetings'] = past_meetings
        
        return stats
    
    async def format_comprehensive_report_text(self, report_data: Dict) -> str:
        """Форматирование полного отчета в текстовый вид по вашим требованиям"""
        text = f"""📊 **ПОЛНЫЙ ОТЧЕТ «БЕСТУЖЕВКИ»**
📅 Период: {report_data['period']}

👥 **ОБЩАЯ СТАТИСТИКА:**
• Всего пользователей: {report_data['general_stats']['total_users']}
• Новых пользователей: {report_data['general_stats']['new_users']}
• Активных пользователей: {report_data['general_stats']['active_users']}

💰 **ФИНАНСЫ:**
• Всего оплат: {report_data['financial_stats']['total_payments']}
• Выручка: {report_data['financial_stats']['total_revenue']:,.0f} ₽
• Средний чек: {report_data['financial_stats']['avg_check']:,.0f} ₽
• Возвраты: {report_data['financial_stats']['refunds']}

📈 **ПОДПИСКИ:**
• Активных подписок: {report_data['subscription_stats']['active_subscriptions']}
• Новых подписок: {report_data['subscription_stats']['new_subscriptions']}
• Заканчивается через неделю: {report_data['subscription_stats']['ending_subscriptions']}
• Отказов от продления: {report_data['subscription_stats']['expired_not_renewed']}
• Отписки: {report_data['subscription_stats']['cancelled_subscriptions']}

🎯 **КОНВЕРСИЯ:**
• Конверсия в оплату: {report_data['conversion_stats']['conversion_rate']:.1f}%
• Всего пользователей: {report_data['conversion_stats']['total_users_period']}
• Оплативших: {report_data['conversion_stats']['paid_users']}

🛒 **БРОШЕННЫЕ КОРЗИНЫ:**
• Всего корзин: {report_data['abandoned_carts']['total_carts']}
• Конвертировано: {report_data['abandoned_carts']['converted_carts']}
• Конверсия из корзин: {report_data['abandoned_carts']['cart_conversion_rate']:.1f}%

🎫 **ПРОМОКОДЫ:**
• Использовано промокодов: {report_data['promocode_stats']['used_promocodes']}
• Сумма скидок: {report_data['promocode_stats']['total_discount']:,.0f} ₽
• Активных промокодов: {report_data['promocode_stats']['active_promocodes']}

📅 **ВСТРЕЧИ:**
• Предстоящих встреч: {report_data['meeting_stats']['upcoming_meetings']}
• Прошедших встреч: {report_data['meeting_stats']['past_meetings']}

---
📊 **РАСПРЕДЕЛЕНИЕ ПО ТАРИФАМ:**
"""
        
        # Добавляем распределение по тарифам
        tariff_names = {
            'creative': '✨ Творческий',
            '1_month': '📅 1 месяц',
            '3_months': '📅 3 месяца',
            '12_months': '📅 12 месяцев'
        }
        
        for tariff, count in report_data['subscription_stats']['tariff_distribution'].items():
            name = tariff_names.get(tariff, tariff)
            text += f"• {name}: {count}\n"
        
        return text
    
    async def create_detailed_excel_report(self, report_data: Dict) -> BytesIO:
        """Создание детального Excel отчета"""
        output = BytesIO()
        
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            workbook = writer.book
            
            # 1. Сводный лист
            summary_data = [
                ["Метрика", "Значение"],
                ["Период отчета", report_data['period']],
                ["Всего пользователей", report_data['general_stats']['total_users']],
                ["Новых пользователей", report_data['general_stats']['new_users']],
                ["Активных пользователей", report_data['general_stats']['active_users']],
                ["Всего оплат", report_data['financial_stats']['total_payments']],
                ["Выручка, руб", report_data['financial_stats']['total_revenue']],
                ["Средний чек, руб", report_data['financial_stats']['avg_check']],
                ["Возвраты", report_data['financial_stats']['refunds']],
                ["Активных подписок", report_data['subscription_stats']['active_subscriptions']],
                ["Новых подписок", report_data['subscription_stats']['new_subscriptions']],
                ["Заканчивается через неделю", report_data['subscription_stats']['ending_subscriptions']],
                ["Отказов от продления", report_data['subscription_stats']['expired_not_renewed']],
                ["Отписки", report_data['subscription_stats']['cancelled_subscriptions']],
                ["Конверсия в оплату, %", report_data['conversion_stats']['conversion_rate']],
                ["Оплативших пользователей", report_data['conversion_stats']['paid_users']],
                ["Всего брошенных корзин", report_data['abandoned_carts']['total_carts']],
                ["Конвертировано корзин", report_data['abandoned_carts']['converted_carts']],
                ["Конверсия из корзин, %", report_data['abandoned_carts']['cart_conversion_rate']],
                ["Использовано промокодов", report_data['promocode_stats']['used_promocodes']],
                ["Сумма скидок, руб", report_data['promocode_stats']['total_discount']],
                ["Активных промокодов", report_data['promocode_stats']['active_promocodes']],
                ["Предстоящих встреч", report_data['meeting_stats']['upcoming_meetings']],
                ["Прошедших встреч", report_data['meeting_stats']['past_meetings']]
            ]
            
            summary_df = pd.DataFrame(summary_data[1:], columns=summary_data[0])
            summary_df.to_excel(writer, sheet_name='Сводка', index=False)
            
            # 2. Распределение по тарифам
            tariff_data = []
            for tariff, count in report_data['subscription_stats']['tariff_distribution'].items():
                tariff_names = {
                    'creative': 'Творческий',
                    '1_month': '1 месяц',
                    '3_months': '3 месяца',
                    '12_months': '12 месяцев'
                }
                tariff_data.append([tariff_names.get(tariff, tariff), count])
            
            if tariff_data:
                tariff_df = pd.DataFrame(tariff_data, columns=['Тариф', 'Количество подписок'])
                tariff_df.to_excel(writer, sheet_name='Тарифы', index=False)
            
            # 3. Детали по пользователям (топ 50)
            session = get_session(self.engine)
            try:
                users = session.query(User).order_by(User.joined_at.desc()).limit(50).all()
                users_data = []
                for user in users:
                    # Используем ту же сессию для проверки подписки
                    has_sub = session.query(Subscription).filter(
                        Subscription.user_id == user.id,
                        Subscription.is_active == True
                    ).first() is not None
                    
                    users_data.append([
                        user.id,
                        f"{user.first_name or ''} {user.last_name or ''}".strip() or "Без имени",
                        user.username or "",
                        user.phone_number or "",
                        user.joined_at.strftime('%d.%m.%Y %H:%M'),
                        "Да" if has_sub else "Нет",
                        "Да" if user.is_active else "Нет"
                    ])
                
                if users_data:
                    users_df = pd.DataFrame(users_data, columns=[
                        'ID', 'Имя', 'Username', 'Телефон', 'Дата регистрации', 'Подписка', 'Активен'
                    ])
                    users_df.to_excel(writer, sheet_name='Пользователи', index=False)
            finally:
                session.close()
            
            # 4. Детали по платежам (топ 50)
            session = get_session(self.engine)
            try:
                payments = session.query(Payment).filter(
                    Payment.status == 'completed'
                ).order_by(Payment.created_at.desc()).limit(50).all()
                
                payments_data = []
                for payment in payments:
                    payments_data.append([
                        payment.id,
                        payment.user.telegram_id if payment.user else "",
                        payment.amount / 100,
                        payment.tariff,
                        payment.promocode or "",
                        payment.created_at.strftime('%d.%m.%Y %H:%M'),
                        payment.status
                    ])
                
                if payments_data:
                    payments_df = pd.DataFrame(payments_data, columns=[
                        'ID платежа', 'ID пользователя', 'Сумма, руб', 'Тариф', 'Промокод', 'Дата', 'Статус'
                    ])
                    payments_df.to_excel(writer, sheet_name='Платежи', index=False)
            finally:
                session.close()
            
            # Автоширина колонок
            for sheet_name in writer.sheets:
                worksheet = writer.sheets[sheet_name]
                for column in worksheet.columns:
                    max_length = 0
                    column_letter = column[0].column_letter
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length:
                                max_length = len(str(cell.value))
                        except:
                            pass
                    adjusted_width = min(max_length + 2, 50)
                    worksheet.column_dimensions[column_letter].width = adjusted_width
        
        output.seek(0)
        return output
    
    async def send_report_to_admin(self, context: ContextTypes.DEFAULT_TYPE, admin_id: int, 
                                  report_text: str, excel_file: BytesIO = None, 
                                  period_name: str = "период"):
        """Отправка отчета конкретному администратору"""
        try:
            # Отправляем текстовый отчет
            await context.bot.send_message(
                chat_id=admin_id,
                text=report_text,
                parse_mode='Markdown'
            )
            
            # Отправляем Excel файл, если есть
            if excel_file:
                filename = f"Отчет_Бестужевки_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
                await context.bot.send_document(
                    chat_id=admin_id,
                    document=InputFile(excel_file, filename=filename),
                    caption=f"📊 Детальный отчет за {period_name}"
                )
            
            logger.info(f"Отчет отправлен администратору {admin_id}")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка отправки отчета администратору {admin_id}: {e}")
            return False

# Функции для использования в боте
async def handle_admin_report_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик запроса отчета через админ-панель"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    
    if user.id not in Config.ADMIN_IDS:
        await query.message.edit_text("⛔ У вас нет прав для просмотра отчетов.")
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    # Если нажали "admin_reports" - показываем меню отчетов
    if query.data == 'admin_reports':
        from keyboards import get_admin_reports_keyboard
        await query.message.edit_text(
            "📊 **Отчеты и аналитика**\n\nВыберите тип отчета:",
            parse_mode='Markdown',
            reply_markup=get_admin_reports_keyboard()
        )
        return
    
    # Обработка Excel экспорта
    if query.data == 'admin_excel_export':
        # Показываем меню выбора типа Excel отчета
        from keyboards import get_excel_export_keyboard
        await query.message.edit_text(
            "📥 **Excel выгрузка данных**\n\n"
            "Выберите тип отчета для экспорта в Excel:\n\n"
            "• 📊 **Полный отчет** - все данные клуба\n"
            "• 👥 **Пользователи** - детальная информация о пользователях\n"
            "• 💰 **Платежи** - финансовые данные и статистика\n"
            "• 📅 **Подписки** - информация о подписках\n"
            "• 🎫 **Промокоды** - использование и эффективность промокодов",
            parse_mode='Markdown',
            reply_markup=get_excel_export_keyboard()
        )
        return
    
    # Обработка кастомных отчетов (custom_)
    if query.data.startswith('custom_'):
        await handle_custom_report(update, context, query.data)
        return
    
    # Обработка периодов (period_)
    if query.data.startswith('period_'):
        await handle_period_report(update, context, query.data)
        return
    
    # Отправляем сообщение о начале генерации отчета
    await query.message.edit_text("📊 Генерирую отчет... Это может занять несколько секунд.")
    
    report_manager = ReportManager(engine)
    
    # Определяем период отчета
    try:
        if query.data == 'admin_report_week':
            end_date = datetime.now()
            start_date = end_date - timedelta(days=7)
            period_name = "неделю"
        elif query.data == 'admin_report_month':
            end_date = datetime.now()
            start_date = end_date - timedelta(days=30)
            period_name = "месяц"
        elif query.data == 'admin_report_custom':
            # Для кастомного отчета показываем меню выбора периода
            from keyboards import get_custom_report_keyboard
            await query.message.edit_text(
                "📅 **Кастомный отчет**\n\n"
                "Выберите период для отчета:",
                parse_mode='Markdown',
                reply_markup=get_custom_report_keyboard()
            )
            return
        else:
            # Если неизвестный тип отчета, показываем меню
            from keyboards import get_admin_reports_keyboard
            await query.message.edit_text(
                "❌ Неизвестный тип отчета.\n\nВыберите тип отчета:",
                parse_mode='Markdown',
                reply_markup=get_admin_reports_keyboard()
            )
            return
        
        # Генерируем отчет
        report_data = await report_manager.generate_comprehensive_report(start_date, end_date)
        report_text = await report_manager.format_comprehensive_report_text(report_data)
        
        # Создаем Excel файл
        excel_file = await report_manager.create_detailed_excel_report(report_data)
        
        # Отправляем отчет
        success = await report_manager.send_report_to_admin(
            context, user.id, report_text, excel_file, period_name
        )
        
        if not success:
            await query.message.reply_text("❌ Не удалось отправить отчет. Попробуйте позже.")
        
    except Exception as e:
        logger.error(f"Ошибка генерации отчета: {e}", exc_info=True)
        await query.message.reply_text("❌ Произошла ошибка при генерации отчета.")

async def handle_custom_report(update: Update, context: ContextTypes.DEFAULT_TYPE, query_data: str):
    """Обработка кастомных отчетов"""
    query = update.callback_query
    user = query.from_user
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    report_manager = ReportManager(engine)
    
    # Определяем период для кастомного отчета
    try:
        if query_data == 'custom_today':
            start_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            end_date = datetime.now()
            period_name = "сегодня"
        elif query_data == 'custom_yesterday':
            yesterday = datetime.now() - timedelta(days=1)
            start_date = yesterday.replace(hour=0, minute=0, second=0, microsecond=0)
            end_date = yesterday.replace(hour=23, minute=59, second=59, microsecond=999999)
            period_name = "вчера"
        elif query_data == 'custom_period':
            # Показываем меню выбора периода
            from keyboards import get_report_period_keyboard
            await query.message.edit_text(
                "📅 **Выберите период для отчета:**",
                parse_mode='Markdown',
                reply_markup=get_report_period_keyboard()
            )
            return
        elif query_data == 'custom_by_tariff':
            # Отчет по тарифам
            await generate_tariff_report(update, context)
            return
        else:
            await query.message.edit_text("❌ Неизвестный тип кастомного отчета.")
            return
        
        await query.message.edit_text(f"📊 Генерирую отчет за {period_name}...")
        
        # Генерируем отчет
        report_data = await report_manager.generate_comprehensive_report(start_date, end_date)
        report_text = await report_manager.format_comprehensive_report_text(report_data)
        
        # Отправляем текстовый отчет
        await context.bot.send_message(
            chat_id=user.id,
            text=report_text,
            parse_mode='Markdown'
        )
        
        # Показываем меню снова
        from keyboards import get_custom_report_keyboard
        await query.message.reply_text(
            "✅ Отчет сгенерирован!\n\nВыберите следующий отчет:",
            reply_markup=get_custom_report_keyboard(),
            parse_mode='Markdown'
        )
        
    except Exception as e:
        logger.error(f"Ошибка генерации кастомного отчета: {e}", exc_info=True)
        await query.message.reply_text("❌ Произошла ошибка при генерации отчета.")

async def handle_period_report(update: Update, context: ContextTypes.DEFAULT_TYPE, query_data: str):
    """Обработка отчетов по периодам"""
    query = update.callback_query
    user = query.from_user
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    report_manager = ReportManager(engine)
    
    # Определяем период
    try:
        if query_data == 'period_today':
            start_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            end_date = datetime.now()
            period_name = "сегодня"
        elif query_data == 'period_yesterday':
            yesterday = datetime.now() - timedelta(days=1)
            start_date = yesterday.replace(hour=0, minute=0, second=0, microsecond=0)
            end_date = yesterday.replace(hour=23, minute=59, second=59, microsecond=999999)
            period_name = "вчера"
        elif query_data == 'period_week':
            end_date = datetime.now()
            start_date = end_date - timedelta(days=7)
            period_name = "неделю"
        elif query_data == 'period_month':
            end_date = datetime.now()
            start_date = end_date - timedelta(days=30)
            period_name = "месяц"
        elif query_data == 'period_this_month':
            now = datetime.now()
            start_date = datetime(now.year, now.month, 1)
            end_date = now
            period_name = "этот месяц"
        elif query_data == 'period_last_month':
            now = datetime.now()
            if now.month == 1:
                start_date = datetime(now.year - 1, 12, 1)
                end_date = datetime(now.year - 1, 12, 31, 23, 59, 59)
            else:
                start_date = datetime(now.year, now.month - 1, 1)
                # Последний день прошлого месяца
                import calendar
                last_day = calendar.monthrange(now.year, now.month - 1)[1]
                end_date = datetime(now.year, now.month - 1, last_day, 23, 59, 59)
            period_name = "прошлый месяц"
        else:
            await query.message.edit_text("❌ Неизвестный период.")
            return
        
        await query.message.edit_text(f"📊 Генерирую отчет за {period_name}...")
        
        # Генерируем отчет
        report_data = await report_manager.generate_comprehensive_report(start_date, end_date)
        report_text = await report_manager.format_comprehensive_report_text(report_data)
        
        # Создаем Excel файл
        excel_file = await report_manager.create_detailed_excel_report(report_data)
        
        # Отправляем отчет
        filename = f"Отчет_Бестужевки_{period_name}_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
        
        # Отправляем текстовый отчет
        await context.bot.send_message(
            chat_id=user.id,
            text=report_text,
            parse_mode='Markdown'
        )
        
        # Отправляем Excel файл
        await context.bot.send_document(
            chat_id=user.id,
            document=InputFile(excel_file, filename=filename),
            caption=f"📊 Детальный отчет за {period_name}"
        )
        
        # Показываем меню снова
        from keyboards import get_report_period_keyboard
        await query.message.reply_text(
            "✅ Отчет сгенерирован и отправлен!\n\nВыберите следующий период:",
            reply_markup=get_report_period_keyboard(),
            parse_mode='Markdown'
        )
        
    except Exception as e:
        logger.error(f"Ошибка генерации отчета за период: {e}", exc_info=True)
        await query.message.reply_text("❌ Произошла ошибка при генерации отчета.")

async def generate_tariff_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Генерация отчета по тарифам"""
    query = update.callback_query
    user = query.from_user
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    from sqlalchemy import func
    session = get_session(engine)
    
    try:
        # Получаем статистику по тарифам
        tariffs = ['creative', '1_month', '3_months', '12_months']
        tariff_stats = {}
        
        for tariff in tariffs:
            # Количество активных подписок
            active_subs = session.query(Subscription).filter(
                Subscription.tariff == tariff,
                Subscription.is_active == True
            ).count()
            
            # Выручка по тарифу
            revenue = session.query(func.sum(Payment.amount)).filter(
                Payment.tariff == tariff,
                Payment.status == 'completed'
            ).scalar() or 0
            
            # Количество платежей
            payments_count = session.query(Payment).filter(
                Payment.tariff == tariff,
                Payment.status == 'completed'
            ).count()
            
            tariff_stats[tariff] = {
                'active_subs': active_subs,
                'revenue': revenue / 100,  # в рублях
                'payments_count': payments_count
            }
        
        # Формируем отчет
        tariff_names = {
            'creative': '✨ Творческий',
            '1_month': '📅 1 месяц',
            '3_months': '📅 3 месяца',
            '12_months': '📅 12 месяцев'
        }
        
        report_text = "📊 **ОТЧЕТ ПО ТАРИФАМ**\n\n"
        
        for tariff, stats in tariff_stats.items():
            name = tariff_names.get(tariff, tariff)
            report_text += f"**{name}:**\n"
            report_text += f"• Активных подписок: {stats['active_subs']}\n"
            report_text += f"• Выручка: {stats['revenue']:,.0f} ₽\n"
            report_text += f"• Количество оплат: {stats['payments_count']}\n"
            if stats['payments_count'] > 0:
                avg_check = stats['revenue'] / stats['payments_count']
                report_text += f"• Средний чек: {avg_check:,.0f} ₽\n"
            report_text += "\n"
        
        # Отправляем отчет
        await context.bot.send_message(
            chat_id=user.id,
            text=report_text,
            parse_mode='Markdown'
        )
        
        await query.message.reply_text(
            "✅ Отчет по тарифам сгенерирован!",
            parse_mode='Markdown'
        )
        
    except Exception as e:
        logger.error(f"Ошибка генерации отчета по тарифам: {e}", exc_info=True)
        await query.message.reply_text("❌ Произошла ошибка при генерации отчета.")
    finally:
        session.close()

async def handle_excel_export(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик запросов Excel выгрузки - ПЕРЕПИСАНА"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    
    if user.id not in Config.ADMIN_IDS:
        await query.message.edit_text("⛔ У вас нет прав для экспорта данных.")
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    # Отправляем сообщение о начале генерации
    await query.message.edit_text("📊 Генерирую Excel файл... Это может занять несколько секунд.")
    
    session = None
    try:
        session = get_session(engine)
        
        # Создаем временный файл в памяти
        from io import BytesIO
        import pandas as pd
        
        if query.data == 'excel_full_report':
            # Полный отчет за последние 30 дней
            end_date = datetime.now()
            start_date = end_date - timedelta(days=30)
            
            # Используем функцию из excel_export.py
            from utils.excel_export import export_full_report
            filepath = export_full_report(session, f"exports/temp_full_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx")
            
            with open(filepath, 'rb') as f:
                excel_file = BytesIO(f.read())
            
            filename = f"Полный_отчет_Бестужевки_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
            caption = "📊 Полный отчет по клубу «Бестужевки»\nПериод: последние 30 дней"
            
        elif query.data == 'excel_users':
            # Используем функцию из excel_export.py
            from utils.excel_export import export_users_to_excel
            filepath = export_users_to_excel(session, f"exports/temp_users_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx")
            
            with open(filepath, 'rb') as f:
                excel_file = BytesIO(f.read())
            
            filename = f"Пользователи_Бестужевки_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
            caption = "👥 Отчет по пользователям клуба «Бестужевки»"
            
        elif query.data == 'excel_payments':
            # Отчет по платежам за последние 30 дней
            from utils.excel_export import export_payments_to_excel
            filepath = export_payments_to_excel(session, f"exports/temp_payments_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx")
            
            with open(filepath, 'rb') as f:
                excel_file = BytesIO(f.read())
            
            filename = f"Платежи_Бестужевки_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
            caption = "💰 Отчет по платежам клуба «Бестужевки»\nПериод: последние 30 дней"
            
        elif query.data == 'excel_subscriptions':
            from utils.excel_export import export_subscriptions_to_excel
            filepath = export_subscriptions_to_excel(session, f"exports/temp_subs_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx")
            
            with open(filepath, 'rb') as f:
                excel_file = BytesIO(f.read())
            
            filename = f"Подписки_Бестужевки_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
            caption = "📅 Отчет по подпискам клуба «Бестужевки»"
            
        elif query.data == 'excel_promocodes':
            # Отчет по промокодам
            from utils.excel_export import export_promocodes_to_excel
            filepath = export_promocodes_to_excel(session, f"exports/temp_promos_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx")
            
            with open(filepath, 'rb') as f:
                excel_file = BytesIO(f.read())
            
            filename = f"Промокоды_Бестужевки_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
            caption = "🎫 Отчет по промокодам клуба «Бестужевки»"
            
        else:
            await query.message.edit_text("❌ Неизвестный тип отчета.")
            return
        
        # Отправляем файл
        await context.bot.send_document(
            chat_id=user.id,
            document=InputFile(excel_file, filename=filename),
            caption=caption
        )
        
        # Показываем меню снова
        from keyboards import get_excel_export_keyboard
        await query.message.reply_text(
            "✅ Файл успешно сформирован и отправлен!\n\nВыберите следующий отчет:",
            reply_markup=get_excel_export_keyboard(),
            parse_mode='Markdown'
        )
        
        logger.info(f"Excel отчет отправлен администратору {user.id}: {query.data}")
        
    except Exception as e:
        logger.error(f"Ошибка генерации Excel отчета: {e}", exc_info=True)
        await query.message.reply_text("❌ Произошла ошибка при генерации отчета.")
    
    finally:
        if session:
            session.close()

async def send_daily_report_to_admins(context: ContextTypes.DEFAULT_TYPE):
    """Ежедневная автоматическая отправка отчета администраторам"""
    try:
        engine = context.bot_data.get('engine')
        if not engine:
            return
        
        report_manager = ReportManager(engine)
        
        # Генерируем отчет за последние 24 часа
        end_date = datetime.now()
        start_date = end_date - timedelta(days=1)
        
        report_data = await report_manager.generate_comprehensive_report(start_date, end_date)
        report_text = await report_manager.format_comprehensive_report_text(report_data)
        
        # Отправляем только текстовый отчет (без Excel для ежедневных)
        for admin_id in Config.ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=report_text,
                    parse_mode='Markdown'
                )
                logger.info(f"Ежедневный отчет отправлен администратору {admin_id}")
            except Exception as e:
                logger.error(f"Ошибка отправки ежедневного отчета администратору {admin_id}: {e}")
        
    except Exception as e:
        logger.error(f"Ошибка при отправке ежедневного отчета: {e}")

async def weekly_report_job(bot):
    """Еженедельная отправка отчета администраторам (для планировщика)"""
    try:
        # Создаем контекст для отчета
        class SimpleContext:
            def __init__(self, bot, engine):
                self.bot = bot
                self.bot_data = {'engine': engine}
        
        # Нужно получить engine из контекста или создать новый
        # Для простоты создаем engine если не передан
        from database import engine
        
        context = SimpleContext(bot, engine)
        await send_weekly_report_to_admins(context)
        
    except Exception as e:
        logger.error(f"Ошибка в weekly_report_job: {e}")

async def send_weekly_report_to_admins(context: ContextTypes.DEFAULT_TYPE):
    """Еженедельная автоматическая отправка отчета администраторам"""
    try:
        engine = context.bot_data.get('engine')
        if not engine:
            logger.error("❌ Engine не найден для еженедельного отчета")
            return
        
        report_manager = ReportManager(engine)
        
        # Генерируем отчет за последние 7 дней
        end_date = datetime.now()
        start_date = end_date - timedelta(days=7)
        
        report_data = await report_manager.generate_comprehensive_report(start_date, end_date)
        report_text = await report_manager.format_comprehensive_report_text(report_data)
        
        # Создаем Excel файл для еженедельного отчета
        excel_file = await report_manager.create_detailed_excel_report(report_data)
        
        # Отправляем отчет с Excel файлом
        for admin_id in Config.ADMIN_IDS:
            try:
                # Отправляем текстовый отчет
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=report_text,
                    parse_mode='Markdown'
                )
                
                # Отправляем Excel файл
                filename = f"Еженедельный_отчет_Бестужевки_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
                await context.bot.send_document(
                    chat_id=admin_id,
                    document=InputFile(excel_file, filename=filename),
                    caption=f"📊 Еженедельный отчет за период {start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}"
                )
                
                logger.info(f"Еженедельный отчет отправлен администратору {admin_id}")
            except Exception as e:
                logger.error(f"Ошибка отправки еженедельного отчета администратору {admin_id}: {e}")
        
    except Exception as e:
        logger.error(f"Ошибка при отправке еженедельного отчета: {e}")