# tinkoff_api.py - для Тинькофф API в БОЕВОМ режиме
import hashlib
import json
import logging
import requests
from config import Config
import time
import uuid

logger = logging.getLogger(__name__)

class TBankPayment:
    def __init__(self):
        self.terminal_id = Config.TINKOFF_TERMINAL_ID
        self.terminal_password = Config.TINKOFF_TERMINAL_PASSWORD
        
        # БОЕВОЙ URL Тинькофф
        self.base_url = "https://securepay.tinkoff.ru/v2/"
        
        logger.info(f"🔄 Инициализация Тинькофф API")
        logger.info(f"   Terminal ID: {self.terminal_id}")
        logger.info(f"   Режим: {'БОЕВОЙ' if not Config.TINKOFF_TEST_MODE else 'ТЕСТОВЫЙ'}")
        logger.info(f"   API URL: {self.base_url}")
        
    def _generate_token(self, data_dict):
        """Генерация токена для Тинькофф"""
        try:
            # Собираем параметры для токена
            params_list = []
            excluded_keys = ['DATA', 'Receipt', 'Token']
            
            for key, value in data_dict.items():
                if key not in excluded_keys:
                    str_value = "" if value is None else str(value)
                    params_list.append({key: str_value})
            
            # Добавляем пароль
            params_list.append({"Password": self.terminal_password})
            
            # Сортируем по алфавиту
            params_list.sort(key=lambda x: list(x.keys())[0])
            
            # Конкатенируем значения
            token_string = ""
            for param in params_list:
                token_string += list(param.values())[0]
            
            logger.debug(f"Параметры для токена: {len(params_list)} шт.")
            
            # Вычисляем SHA-256
            token_hash = hashlib.sha256(token_string.encode('utf-8')).hexdigest()
            return token_hash
            
        except Exception as e:
            logger.error(f"Ошибка генерации токена: {e}")
            raise
    
    def _build_receipt(self, amount, customer_data=None, taxation="osn"):
        """Построение чека для 54-ФЗ"""
        # Сумма в рублях (для чека нужна в копейках)
        amount_in_cents = int(amount * 100)
        
        # Email для отправки чека
        email = None
        if customer_data and isinstance(customer_data, dict):
            email = customer_data.get('email')
        
        receipt = {
            "Email": email if email and '@' in email else Config.CLUB_EMAIL,  # Email для чека
            "Phone": "",  # Телефон для СМС-чека (если нужен)
            "EmailCompany": Config.CLUB_EMAIL,  # Email компании
            "Taxation": taxation,  # Система налогообложения
            "Items": [
                {
                    "Name": "Подписка на участие в клубе «Бестужевки»",
                    "Price": amount_in_cents,  # Цена в копейках
                    "Quantity": 1,  # Количество
                    "Amount": amount_in_cents,  # Сумма в копейках
                    "PaymentMethod": "full_payment",  # Метод расчета
                    "PaymentObject": "service",  # Предмет расчета
                    "Tax": "none",  # Ставка НДС (none - без НДС)
                    "MeasurementUnit": "шт",  # Единица измерения
                }
            ]
        }
        
        logger.debug(f"Сформирован чек на сумму: {amount} руб")
        return receipt
    
    def create_payment(self, order_id, amount, description, customer_data=None):
        """Создание платежа в Тинькофф"""
        try:
            # Переводим в копейки
            amount_in_cents = int(amount * 100)
            
            # Минимальная сумма для боевого терминала - 100 копеек (1 рубль)
            if amount_in_cents < 100:
                logger.warning("Минимальная сумма для боевого терминала: 100 копеек (1 рубль)")
                return {
                    "success": False,
                    "error": "Минимальная сумма оплаты: 1 рубль"
                }
            
            # Основные данные запроса
            data = {
                "TerminalKey": self.terminal_id,
                "Amount": amount_in_cents,
                "OrderId": str(order_id),
                "Description": str(description)[:140],
                "Currency": 643,  # RUB
                "Recurrent": "N",
                "Language": "ru",
                "PayType": "O",
            }
            
            # Добавляем SuccessURL и FailURL если они заданы
            if Config.TINKOFF_SUCCESS_URL and Config.TINKOFF_SUCCESS_URL.strip():
                data["SuccessURL"] = Config.TINKOFF_SUCCESS_URL.strip()
                logger.debug(f"SuccessURL добавлен: {data['SuccessURL'][:50]}...")
            
            if Config.TINKOFF_FAIL_URL and Config.TINKOFF_FAIL_URL.strip():
                data["FailURL"] = Config.TINKOFF_FAIL_URL.strip()
                logger.debug(f"FailURL добавлен: {data['FailURL'][:50]}...")
            
            # ОБЯЗАТЕЛЬНО: Добавляем чек для 54-ФЗ
            receipt = self._build_receipt(amount, customer_data)
            data["Receipt"] = receipt
            
            # Добавляем данные клиента
            if customer_data and isinstance(customer_data, dict):
                data["DATA"] = {}
                if 'email' in customer_data and customer_data['email']:
                    email = str(customer_data['email'])[:100]
                    if '@' in email:
                        data["DATA"]["Email"] = email
                if 'phone' in customer_data and customer_data['phone']:
                    phone = str(customer_data['phone'])[:20]
                    if phone:
                        data["DATA"]["Phone"] = phone
            
            # Логируем данные для отладки (без чувствительной информации)
            logger.debug(f"📤 Данные для отправки в Тинькофф:")
            for key, value in data.items():
                if key in ['TerminalKey', 'Password', 'Token']:
                    logger.debug(f"   {key}: {'*' * len(str(value))}")
                elif key == 'Receipt':
                    logger.debug(f"   {key}: [чек для 54-ФЗ, {len(str(value))} символов]")
                elif key in ['SuccessURL', 'FailURL', 'NotificationURL']:
                    logger.debug(f"   {key}: {str(value)[:50]}...")
                else:
                    logger.debug(f"   {key}: {str(value)[:100] if len(str(value)) > 100 else value}")
            
            # Генерация токена
            token = self._generate_token(data)
            data["Token"] = token
            
            logger.info("📤 Создание платежа в Тинькофф:")
            logger.info(f"   Order ID: {order_id}")
            logger.info(f"   Amount: {amount} руб ({amount_in_cents} коп)")
            logger.info(f"   Description: {description[:50]}...")
            logger.info(f"   Чек 54-ФЗ: включен")
            
            # Отправка запроса
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            
            response = requests.post(
                f"{self.base_url}Init",
                json=data,
                headers=headers,
                timeout=30,
                verify=True
            )
            
            # Обработка ответа
            if response.status_code != 200:
                logger.error(f"HTTP ошибка {response.status_code}: {response.text[:200]}")
                return {
                    "success": False,
                    "error": f"HTTP ошибка {response.status_code}",
                    "http_status": response.status_code,
                    "response_text": response.text[:500]
                }
            
            result = response.json()
            logger.info(f"Ответ Тинькофф: Success={result.get('Success', False)}")
            
            if result.get("Success"):
                payment_url = result.get("PaymentURL", "")
                payment_id = result.get("PaymentId", "")
                
                logger.info(f"✅ Платеж создан!")
                logger.info(f"   Payment ID: {payment_id}")
                logger.info(f"   Payment URL: {payment_url[:80]}...")
                
                return {
                    "success": True,
                    "payment_id": payment_id,
                    "payment_url": payment_url,
                    "order_id": result.get("OrderId", ""),
                    "status": result.get("Status", ""),
                    "amount": amount,
                    "full_response": result
                }
            else:
                error_code = result.get("ErrorCode", "")
                error_message = result.get("Message", "Неизвестная ошибка")
                details = result.get("Details", "")
                
                logger.error(f"❌ Ошибка Тинькофф: {error_code} - {error_message}")
                if details:
                    logger.error(f"   Details: {details}")
                
                # Детальная диагностика
                diagnosis = self._get_error_diagnosis(error_code, details)
                if diagnosis:
                    logger.error(f"   Диагноз: {diagnosis}")
                
                # Возвращаем дополнительные данные для отладки
                debug_data = {
                    "success": False,
                    "error": error_message,
                    "error_code": error_code,
                    "details": details,
                    "diagnosis": diagnosis,
                    "full_response": result
                }
                
                # Для ошибки 309 показываем структуру чека
                if error_code == "309" and "receipt" in details.lower():
                    logger.error("   💡 Проблема с чеком 54-ФЗ. Проверьте:")
                    logger.error("      • Формат чека (обязательные поля)")
                    logger.error("      • Ставку НДС (Tax)")
                    logger.error("      • Email для отправки чека")
                    logger.error("      • Систему налогообложения (Taxation)")
                    debug_data["receipt_sample"] = {
                        "taxation": "osn",
                        "email": "client@example.com",
                        "items": [{
                            "name": "Услуга",
                            "price": 10000,
                            "quantity": 1,
                            "amount": 10000,
                            "tax": "none",
                            "payment_method": "full_payment",
                            "payment_object": "service"
                        }]
                    }
                
                return debug_data
                
        except requests.exceptions.Timeout:
            logger.error("Таймаут запроса к Тинькофф API")
            return {
                "success": False,
                "error": "Таймаут соединения"
            }
        except requests.exceptions.RequestException as e:
            logger.error(f"Сетевая ошибка: {e}")
            return {
                "success": False,
                "error": f"Сетевая ошибка: {str(e)}"
            }
        except Exception as e:
            logger.error(f"Неожиданная ошибка: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return {
                "success": False,
                "error": str(e)
            }
    
    def _get_error_diagnosis(self, error_code, details=""):
        """Диагностика ошибок Тинькофф"""
        diagnoses = {
            "5": "Терминал не активен. Активируйте в личном кабинете Тинькофф Бизнес.",
            "7": "Терминал заблокирован.",
            "102": "Недопустимая сумма платежа.",
            "204": "Неверный токен. Проверьте TerminalKey и Password.",
            "241": "Неверный формат Currency. Используйте 643 для RUB.",
            "309": f"Неверные параметры. {details}",
            "316": "Платеж с таким OrderId уже существует.",
            "9999": "Внутренняя ошибка системы Тинькофф.",
        }
        
        diagnosis = diagnoses.get(error_code, "")
        
        # Специальная обработка для ошибок чека
        if error_code == "309" and "receipt" in details.lower():
            diagnosis += "\nПроблема с чеком 54-ФЗ. Проверьте формат Receipt."
        
        return diagnosis
    
    # Остальные методы остаются без изменений...
    def check_payment_status(self, payment_id):
        """Проверка статуса платежа по PaymentId (ИСПРАВЛЕНО)"""
        try:
            # ВАЖНО: Для GetState требуется PaymentId, а не OrderId
            data = {
                "TerminalKey": self.terminal_id,
                "PaymentId": payment_id  # ИСПРАВЛЕНО: OrderId → PaymentId
            }
            
            token = self._generate_token(data)
            data["Token"] = token
            
            logger.debug(f"Проверка статуса платежа: PaymentId={payment_id}")
            
            response = requests.post(
                f"{self.base_url}GetState",
                json=data,
                timeout=30,
                headers={'Content-Type': 'application/json'}
            )
            
            if response.status_code != 200:
                logger.error(f"HTTP ошибка {response.status_code} при проверке статуса")
                return {
                    "success": False,
                    "error": f"HTTP ошибка {response.status_code}"
                }
            
            result = response.json()
            
            if result.get("Success"):
                status = result.get("Status", "UNKNOWN")
                amount = result.get("Amount", 0) / 100 if result.get("Amount") else 0
                
                logger.info(f"Статус платежа PaymentId={payment_id}: {status}, сумма: {amount} руб")
                
                # Добавляем более подробное логирование для отладки
                logger.debug(f"Полный ответ GetState: {result}")
                
                return {
                    "success": True,
                    "status": status,
                    "status_text": self._get_status_text(status),
                    "order_id": result.get("OrderId", ""),
                    "payment_id": result.get("PaymentId", ""),
                    "amount": amount,
                    "full_response": result
                }
            else:
                error_message = result.get("Message", "Неизвестная ошибка")
                error_code = result.get("ErrorCode", "")
                
                logger.error(f"Ошибка при проверке статуса: {error_code} - {error_message}")
                
                # Диагностика ошибок GetState
                diagnosis = self._get_getstate_error_diagnosis(error_code)
                if diagnosis:
                    logger.error(f"   Диагноз: {diagnosis}")
                
                return {
                    "success": False,
                    "error": error_message,
                    "error_code": error_code,
                    "diagnosis": diagnosis,
                    "full_response": result
                }
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Сетевая ошибка при проверке статуса: {e}")
            return {
                "success": False,
                "error": f"Сетевая ошибка: {str(e)}"
            }
        except Exception as e:
            logger.error(f"Неожиданная ошибка при проверке статуса: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return {
                "success": False,
                "error": str(e)
            }
    
    def _get_getstate_error_diagnosis(self, error_code):
        """Диагностика ошибок метода GetState"""
        diagnoses = {
            "1": "Неизвестная ошибка. Проверьте логи Тинькофф.",
            "5": "Терминал не активен.",
            "6": "Неверный номер заказа (OrderId) или номер платежа (PaymentId).",
            "7": "Терминал заблокирован.",
            "8": "Превышен лимит операций.",
            "104": "Не найден платеж с указанным PaymentId.",
            "105": "Неверный PaymentId.",
            "204": "Неверный токен. Проверьте TerminalKey и Password.",
            "300": "Истек срок оплаты платежа.",
        }
        return diagnoses.get(error_code, "")
    
    def check_payment_status_by_order_id(self, order_id):
        """Альтернативный метод проверки статуса по OrderId (если нужен)"""
        try:
            # Этот метод тоже можно использовать, но лучше по PaymentId
            data = {
                "TerminalKey": self.terminal_id,
                "OrderId": order_id
            }
            
            token = self._generate_token(data)
            data["Token"] = token
            
            logger.debug(f"Проверка статуса платежа по OrderId: {order_id}")
            
            response = requests.post(
                f"{self.base_url}GetState",
                json=data,
                timeout=30,
                headers={'Content-Type': 'application/json'}
            )
            
            if response.status_code != 200:
                logger.error(f"HTTP ошибка {response.status_code} при проверке статуса по OrderId")
                return {
                    "success": False,
                    "error": f"HTTP ошибка {response.status_code}"
                }
            
            result = response.json()
            
            if result.get("Success"):
                status = result.get("Status", "UNKNOWN")
                amount = result.get("Amount", 0) / 100 if result.get("Amount") else 0
                
                logger.info(f"Статус платежа OrderId={order_id}: {status}, сумма: {amount} руб")
                
                return {
                    "success": True,
                    "status": status,
                    "status_text": self._get_status_text(status),
                    "order_id": result.get("OrderId", ""),
                    "payment_id": result.get("PaymentId", ""),
                    "amount": amount,
                    "full_response": result
                }
            else:
                error_message = result.get("Message", "Неизвестная ошибка")
                logger.error(f"Ошибка при проверке статуса по OrderId: {error_message}")
                
                return {
                    "success": False,
                    "error": error_message,
                    "error_code": result.get("ErrorCode", ""),
                    "full_response": result
                }
            
        except Exception as e:
            logger.error(f"Неожиданная ошибка при проверке статуса по OrderId: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _get_status_text(self, status):
        """Текстовое описание статуса"""
        statuses = {
            "NEW": "Новый",
            "FORM_SHOWED": "Показана форма",
            "DEADLINE_EXPIRED": "Просрочен",
            "CANCELED": "Отменен",
            "PREAUTHORIZING": "Предавторизация",
            "AUTHORIZING": "Авторизация",
            "AUTHORIZED": "Авторизован",
            "CONFIRMING": "Подтверждение",
            "CONFIRMED": "Подтвержден",
            "REJECTED": "Отклонен",
            "REFUNDING": "Возврат",
            "REFUNDED": "Возвращен",
            "COMPLETED": "Завершен",
            "PARTIAL_REVERSED": "Частично реверсирован",
            "PARTIAL_REFUNDED": "Частично возвращен",
        }
        return statuses.get(status, status)
    
    def cancel_payment(self, payment_id):
        """Отмена платежа по PaymentId"""
        try:
            data = {
                "TerminalKey": self.terminal_id,
                "PaymentId": payment_id
            }
            
            token = self._generate_token(data)
            data["Token"] = token
            
            logger.info(f"Отмена платежа: PaymentId={payment_id}")
            
            response = requests.post(
                f"{self.base_url}Cancel",
                json=data,
                timeout=30,
                headers={'Content-Type': 'application/json'}
            )
            
            if response.status_code != 200:
                return {
                    "success": False,
                    "error": f"HTTP ошибка {response.status_code}"
                }
            
            result = response.json()
            
            if result.get("Success"):
                return {
                    "success": True,
                    "new_amount": result.get("NewAmount", 0) / 100,
                    "status": result.get("Status", ""),
                    "payment_id": result.get("PaymentId", "")
                }
            else:
                return {
                    "success": False,
                    "error": result.get("Message", "Неизвестная ошибка"),
                    "error_code": result.get("ErrorCode", "")
                }
            
        except Exception as e:
            logger.error(f"Ошибка отмены платежа: {e}")
            return None

# Создаем глобальный экземпляр
try:
    tbank = TBankPayment()
    if tbank.terminal_id and tbank.terminal_password:
        logger.info("✅ Тинькофф API инициализирован")
        logger.info(f"   Terminal: {tbank.terminal_id[:10]}...")
        logger.info(f"   API URL: {tbank.base_url}")
        logger.info(f"   Чек 54-ФЗ: поддерживается")
    else:
        logger.error("❌ Не заданы данные Тинькофф")
        tbank = None
except Exception as e:
    logger.error(f"❌ Ошибка инициализации Тинькофф API: {e}")
    tbank = None