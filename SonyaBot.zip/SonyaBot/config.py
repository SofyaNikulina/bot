import os
import logging
from datetime import time, timedelta
from dotenv import load_dotenv

# Настраиваем логирование для config
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

class Config:
    # ==================== ОСНОВНЫЕ НАСТРОЙКИ ====================
    BOT_TOKEN = os.getenv('BOT_TOKEN')
    PAYMENTS_PROVIDER_TOKEN = os.getenv('PAYMENTS_PROVIDER_TOKEN')
    DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///bestuzhevki.db')
    
    # ==================== АДМИНИСТРАТОРЫ ====================
    ADMIN_IDS = [int(id.strip()) for id in os.getenv('ADMIN_IDS', '').split(',') if id.strip()]
    ADMIN_USERNAMES = [username.strip() for username in os.getenv('ADMIN_USERNAMES', '').split(',') if username.strip()]
    
    # ==================== КЛУБ ====================
    CLUB_NAME = "Бестужевки"
    CLUB_EMAIL = "skrepkaclub@yandex.ru"
    CLUB_CHAT_LINKS = {
        '1_month': os.getenv('CLUB_CHAT_LINK_1_MONTH', 'https://t.me/+V37aK2CAOA1jNmEy'),  # чат для 1 месяца
        '12_months': os.getenv('CLUB_CHAT_LINK_12_MONTHS', 'https://t.me/+h6fqPpfMyDtmYjFi'),  # чат для 12 месяцев
    }
    CITIES = ['Москва', 'Санкт-Петербург']
    PROFESSIONS = {
    'entrepreneur': 'Предпринимательница',
    'manager': 'Работаю на линейной должности (менеджер)',
    'executive': 'Работаю на управляющей позиции',
    'self_employed': 'Самозанятая',
    'student': 'Учусь / студентка',
    'not_working': 'Не работаю',
    'maternity': 'В декрете'
}

    
    # ==================== ССЫЛКИ ====================
    PRIVACY_POLICY_URL = os.getenv('PRIVACY_POLICY_URL', 'https://docs.google.com/document/d/1iu7icXKeUAnr0alINYb_2U6jut0C22BX1ZsyaSCFfAg/edit?tab=t.0')
    PROGRAM_URL = os.getenv('PROGRAM_URL', 'https://docs.google.com/...')
    
    # ==================== ТИНЬКОФФ ОПЛАТА ====================
    TINKOFF_TERMINAL_ID = os.getenv('TINKOFF_TERMINAL_ID', '')
    TINKOFF_TERMINAL_PASSWORD = os.getenv('TINKOFF_TERMINAL_PASSWORD', '')
    TINKOFF_API_URL = "https://securepay.tinkoff.ru/v2/"
    
    # Режим работы (true - тестовый, false - боевой)
    TINKOFF_TEST_MODE = os.getenv('TINKOFF_TEST_MODE', 'false').lower() == 'true'
    
    # URL для уведомлений (опционально, если настроите вебхук)
    TINKOFF_NOTIFICATION_URL = os.getenv('TINKOFF_NOTIFICATION_URL', '')
    
    # URL для редиректа после оплаты (ваш бот)
    TINKOFF_SUCCESS_URL = os.getenv('TINKOFF_SUCCESS_URL', 'https://t.me/bestuzhevka_bot?start=payment_success')
    TINKOFF_FAIL_URL = os.getenv('TINKOFF_FAIL_URL', 'https://t.me/bestuzhevka_bot?start=payment_failed')
    
    # ==================== ZOOM ====================
    ZOOM_ACCOUNT_ID = os.getenv('ZOOM_ACCOUNT_ID')
    ZOOM_CLIENT_ID = os.getenv('ZOOM_CLIENT_ID')
    ZOOM_CLIENT_SECRET = os.getenv('ZOOM_CLIENT_SECRET')
    ZOOM_API_KEY = os.getenv('ZOOM_API_KEY')  # Для JWT (старый метод)
    ZOOM_API_SECRET = os.getenv('ZOOM_API_SECRET')  # Для JWT (старый метод)
    ZOOM_ENABLED = bool(ZOOM_ACCOUNT_ID and ZOOM_CLIENT_ID and ZOOM_CLIENT_SECRET) or bool(ZOOM_API_KEY and ZOOM_API_SECRET)
    
    # ==================== ТАРИФЫ (в копейках) ====================
    TARIFFS = {
        'creative': {  # тестовый тариф
            'price': 1000,  # 10 рублей
            'label': 'Творческий - 10 ₽',
            'description': 'Тестовое участие на 1 день',
            'duration_days': 1,  # 1 день
            'promo_codes': []
        },
        '1_month': {
            'price': 500000,  # 5 000 рублей
            'label': '1 месяц - 5000 ₽',
            'description': 'Познакомиться с форматом',
            'duration_days': 30,
            'promo_codes': []
        },
        '3_months': {
            'price': 1000000,  # 10 000 рублей
            'label': '3 месяца - 10000 ₽ (вместо 15000 ₽)',
            'description': 'Оптимальный вариант',
            'duration_days': 90,
            'promo_codes': []
        },
        '12_months': {
            'price': 4000000,  # 40 000 рублей
            'label': '12 месяцев - 40 000 ₽ (вместо 60000 ₽)',
            'description': 'Самый выгодный формат + бонусы',
            'duration_days': 365,
            'bonuses': ['Рабочая тетрадь А4', 'Наклейки'],
            'promo_codes': []
        }
    }
    
    # ==================== ПРОМОКОДЫ ====================
    # Убрали статичные промокоды - теперь они только в БД
    PROMOCODES = {}  # Оставляем пустым, промокоды теперь в базе данных
    
    # ==================== НАПОМИНАНИЯ ====================
    REMINDERS = {
        'day_before': {'time': time(18, 0), 'active': True},  # 18:00 за день
        '15_min_before': {'active': True},
        'ignore_next_day': {'time_range': (18, 21), 'active': True},  # 18:00-21:00
        'monthly_7_days': {'active': True},  # За 7 дней до конца месяца
        'monthly_last_day': {'active': True},  # В последний день месяца
    }
    
    # ==================== ФОРМАТ ВСТРЕЧ ====================
    MEETING_SETTINGS = {
        'default_duration': 90,  # минут
        'default_time': time(19, 0),  # 19:00
        'recording_available_after': 24,  # часов
        'new_members_join_day': 1,  # 1-го числа каждого месяца
        'registration_open_days': 7,  # За 7 дней до конца месяца
    }
    
    # ==================== БОНУСЫ ====================
    BONUSES = {
        '12_months': {
            'items': ['Рабочая тетрадь А4', 'Наклейки'],
            'shipping': ['СДЭК', 'Почта России', 'Яндекс Доставка']
        }
    }
    
    # ==================== ЛОГИРОВАНИЕ ====================
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'DEBUG')
    LOG_FILE = 'logs/bot.log'
    
    # ==================== БЕЗОПАСНОСТЬ ====================
    MAX_MESSAGE_LENGTH = 4096
    REQUEST_TIMEOUT = 30
    MAX_RETRIES = 3
    
    @classmethod
    def validate(cls):
        """Проверка конфигурации (разделена на ошибки и предупреждения)"""
        critical_errors = []   # Блокируют запуск бота
        warnings = []          # Информируют, но позволяют работать
        
        # --- КРИТИЧЕСКИЕ ПРОВЕРКИ (бот не запустится) ---
        if not cls.BOT_TOKEN:
            critical_errors.append("[CRITICAL] BOT_TOKEN не установлен")
        
        # Проверяем хотя бы один способ оплаты
        has_telegram_payments = cls.PAYMENTS_PROVIDER_TOKEN and cls.PAYMENTS_PROVIDER_TOKEN != 'ваш_платежный_токен'
        has_tinkoff_payments = cls.TINKOFF_TERMINAL_ID and cls.TINKOFF_TERMINAL_PASSWORD
        
        if not has_telegram_payments and not has_tinkoff_payments:
            critical_errors.append("[CRITICAL] Не настроены способы оплаты. Установите PAYMENTS_PROVIDER_TOKEN или TINKOFF_TERMINAL_ID и TINKOFF_TERMINAL_PASSWORD")
        elif not has_telegram_payments:
            warnings.append("[INFO] Telegram Payments не настроены, будет использоваться Тинькофф")
        elif not has_tinkoff_payments:
            warnings.append("[INFO] Тинькофф оплата не настроена, будет использоваться Telegram Payments")
        else:
            logger.info("[INFO] Настроены оба способа оплаты: Telegram Payments и Тинькофф")

        if not cls.TINKOFF_TERMINAL_ID or not cls.TINKOFF_TERMINAL_PASSWORD:
            critical_errors.append("[CRITICAL] Не настроены данные Тинькофф (терминал и пароль)")
        else:
            logger.info(f"[INFO] Тинькофф оплата настроена (терминал: {cls.TINKOFF_TERMINAL_ID})")
        
        # --- ПРЕДУПРЕЖДЕНИЯ (бот запустится, но с ограничениями) ---
        if not cls.ADMIN_IDS:
            warnings.append("[WARNING] ADMIN_IDS не установлены - административные функции недоступны")
        
        if not cls.CLUB_CHAT_LINKS['1_month'] or cls.CLUB_CHAT_LINKS['1_month'] == 'https://t.me/+Fvpnyt-TcvhmODYy':
            warnings.append("[WARNING] CLUB_CHAT_LINK не обновлен или имеет значение по умолчанию")
        
        if not cls.PRIVACY_POLICY_URL or '...' in cls.PRIVACY_POLICY_URL:
            warnings.append("[WARNING] PRIVACY_POLICY_URL не обновлен или имеет значение по умолчанию")
        
        if not cls.PROGRAM_URL or '...' in cls.PROGRAM_URL:
            warnings.append("[WARNING] PROGRAM_URL не обновлен или имеет значение по умолчанию")

        if not cls.ADMIN_IDS:
            warnings.append("[WARNING] ADMIN_IDS не установлены")
        
        # Проверка тестового режима Тинькофф
        if has_tinkoff_payments and cls.TINKOFF_TEST_MODE:
            warnings.append("[INFO] Тинькофф работает в ТЕСТОВОМ режиме. Для продакшена установите TINKOFF_TEST_MODE=false")
        else:
            logger.info("[INFO] Тинькофф работает в БОЕВОМ режиме")
        
        # Проверка настроек Zoom
        if cls.ZOOM_ENABLED:
            if cls.ZOOM_API_KEY and cls.ZOOM_API_SECRET:
                logger.info("[INFO] Zoom API настроен (JWT метод)")
            elif cls.ZOOM_ACCOUNT_ID and cls.ZOOM_CLIENT_ID and cls.ZOOM_CLIENT_SECRET:
                logger.info("[INFO] Zoom API настроен (OAuth метод)")
        else:
            warnings.append("[INFO] Zoom API не настроен. Автоматическое создание встреч недоступно")
        
        # --- ВЫВОД РЕЗУЛЬТАТОВ ---
        if critical_errors:
            print("\n" + "="*60)
            print("КОНФИГУРАЦИЯ НЕ ПРОШЛА ПРОВЕРКУ:")
            print("="*60)
            for error in critical_errors:
                print(f"• {error}")
            print("="*60 + "\n")
            return False
        
        # Если есть только предупреждения - выводим их, но запускаем бота
        if warnings:
            print("\n" + "="*60)
            print("ПРЕДУПРЕЖДЕНИЯ КОНФИГУРАЦИИ (бот будет запущен):")
            print("="*60)
            for warning in warnings:
                print(f"• {warning}")
            print("="*60 + "\n")
        
        return True
