# test_tbank_api.py
import sys
import json
import time
import logging

# Настройка логирования для видимости отладочных сообщений
logging.basicConfig(level=logging.INFO)

sys.path.append('.')

try:
    from tinkoff_api import tbank
except ImportError as e:
    print(f"❌ Ошибка импорта: {e}")
    sys.exit(1)

print("=" * 60)
print("ТЕСТ ТИНЬКОФФ API (исправленный)")
print("=" * 60)

if tbank is None:
    print("❌ API не инициализирован")
    sys.exit(1)

print(f"✅ API инициализирован")
print(f"   Terminal ID: {tbank.terminal_id}")
print(f"   API URL: {tbank.base_url}")

# Тестовый запрос
print("\n🚀 Отправка тестового запроса...")
result = tbank.create_payment(
    order_id=f"test_{int(time.time())}",
    amount=10.00,  # 10 рублей
    description="Тестовый платеж через Тинькофф API"
)

print(f"\n📨 Результат:")
print(json.dumps(result, indent=2, ensure_ascii=False))

if result.get("success"):
    print(f"\n✅ УСПЕХ! Ссылка для оплаты: {result.get('payment_url')}")
else:
    print(f"\n❌ ОШИБКА: {result.get('error', 'Неизвестная ошибка')}")
    if result.get('error_code'):
        print(f"   Код ошибки: {result.get('error_code')}")
    if result.get('diagnosis'):
        print(f"   Диагноз: {result.get('diagnosis')}")