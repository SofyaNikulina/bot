# scheduler.py - ИСПРАВЛЕННЫЙ с правильным timezone
import logging
from datetime import datetime, timedelta
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.date import DateTrigger
from database import get_session, User, Subscription, Meeting, Reminder
from config import Config
import pytz

logger = logging.getLogger(__name__)

class SchedulerManager:
    def __init__(self, bot, engine):
        self.bot = bot
        self.engine = engine
        # СОЗДАЕМ планировщик с правильным timezone СРАЗУ
        moscow_tz = pytz.timezone('Europe/Moscow')
        self.scheduler = AsyncIOScheduler(timezone=moscow_tz)
        self.context = None  # Для хранения context
        
    def set_context(self, context):
        """Установка контекста для отчетов"""
        self.context = context
        
    def start(self):
        """Запуск планировщика с правильным расписанием"""
        try:
            # Устанавливаем часовой пояс для планировщика
            moscow_tz = pytz.timezone('Europe/Moscow')
            now = datetime.now(moscow_tz)
            logger.info(f"🕐 Текущее время в Москве: {now.strftime('%Y-%m-%d %H:%M:%S')}")
            logger.info(f"🕐 Часовой пояс планировщика: Europe/Moscow")
            
            # 1. Ежедневные напоминания в 9:00 (за 24 часа)
            self.scheduler.add_job(
                self.check_daily_reminders,
                CronTrigger(hour=9, minute=0, timezone=moscow_tz),
                id='daily_reminders_9am',
                replace_existing=True
            )
            
            # 2. Проверка 15-минутных напоминаний - КАЖДУЮ МИНУТУ для надежности
            self.scheduler.add_job(
                self.check_15_min_reminders,
                CronTrigger(minute='*', timezone=moscow_tz),  # Каждую минуту!
                id='15_min_reminders',
                replace_existing=True
            )
            
            # 3. Проверка "прямо сейчас" трансляции - КАЖДЫЕ 5 МИНУТ
            self.scheduler.add_job(
                self.check_live_streams,
                CronTrigger(minute='*/5', timezone=moscow_tz),
                id='live_stream_check',
                replace_existing=True
            )
            
            # 4. Проверка подписок каждый день в 10:00
            self.scheduler.add_job(
                self.check_subscriptions,
                CronTrigger(hour=10, minute=0, timezone=moscow_tz),
                id='check_subscriptions',
                replace_existing=True
            )
            
            # 5. Проверка игнора каждый день в 18:00
            self.scheduler.add_job(
                self.check_ignore_reminders,
                CronTrigger(hour=18, minute=0, timezone=moscow_tz),
                id='ignore_reminders',
                replace_existing=True
            )
            
            # 6. Напоминание за 7 дней до конца месяца (25 число)
            self.scheduler.add_job(
                self.check_monthly_reminders,
                CronTrigger(day=25, hour=12, minute=0, timezone=moscow_tz),
                id='monthly_7_days',
                replace_existing=True
            )
            
            # 7. Напоминание в последний день месяца
            self.scheduler.add_job(
                self.check_last_day_reminders,
                CronTrigger(day='last', hour=12, minute=0, timezone=moscow_tz),
                id='monthly_last_day',
                replace_existing=True
            )
            
            # 8. Немедленный тест при запуске (используем trigger 'date' с pytz timezone)
            run_date = datetime.now(moscow_tz) + timedelta(seconds=10)
            # Преобразуем в timezone-aware datetime для DateTrigger
            run_date_tz = moscow_tz.localize(run_date.replace(tzinfo=None)) if run_date.tzinfo is None else run_date
            
            self.scheduler.add_job(
                self.run_immediate_test,
                DateTrigger(run_date=run_date_tz),
                id='immediate_test',
                replace_existing=True
            )
            
            self.scheduler.start()
            
            logger.info("✅ Планировщик запущен")
            logger.info("   📅 Ежедневные напоминания: 9:00")
            logger.info("   ⏰ 15-минутные напоминания: КАЖДУЮ МИНУТУ")
            logger.info("   🎥 Проверка живых трансляций: каждые 5 минут")
            logger.info("   📊 Проверка подписок: 10:00")
            logger.info("   🤔 Проверка 'игнора': 18:00")
            logger.info("   📆 Месячные напоминания: 25 число и последний день")
            logger.info("   🧪 Тест: через 10 сек после старта")
            
            # Логируем список всех задач
            jobs = self.scheduler.get_jobs()
            logger.info(f"📋 Всего задач в планировщике: {len(jobs)}")
            for job in jobs:
                next_run = job.next_run_time.astimezone(moscow_tz) if job.next_run_time else "N/A"
                logger.info(f"   • {job.id}: следующее выполнение - {next_run}")
            
        except Exception as e:
            logger.error(f"❌ Ошибка запуска планировщика: {e}", exc_info=True)
    
    async def run_immediate_test(self):
        """Немедленный тест при запуске"""
        try:
            logger.info("🧪 === НЕМЕДЛЕННЫЙ ТЕСТ ПЛАНИРОВЩИКА ===")
            
            # 1. Проверяем 15-минутные напоминания
            logger.info("🔍 Тест 1: Проверка 15-минутных напоминаний")
            await self.check_15_min_reminders()
            
            # 2. Проверяем ежедневные напоминания
            logger.info("🔍 Тест 2: Проверка ежедневных напоминаний")
            await self.check_daily_reminders()
            
            # 3. Проверяем текущие трансляции
            logger.info("🔍 Тест 3: Проверка текущих трансляций")
            await self.check_live_streams()
            
            logger.info("✅ === НЕМЕДЛЕННЫЙ ТЕСТ ЗАВЕРШЕН ===")
            
        except Exception as e:
            logger.error(f"❌ Ошибка в немедленном тесте: {e}", exc_info=True)
    
    async def check_daily_reminders(self):
        """Проверка ежедневных напоминаний (за 24 часа)"""
        logger.info("📅 === ПРОВЕРКА ЕЖЕДНЕВНЫХ НАПОМИНАНИЙ ===")
        
        session = get_session(self.engine)
        
        try:
            # Находим встречи на ЗАВТРА
            now = datetime.now()
            tomorrow = now + timedelta(days=1)
            
            # Начало и конец завтрашнего дня
            start_of_tomorrow = datetime(tomorrow.year, tomorrow.month, tomorrow.day, 0, 0, 0)
            end_of_tomorrow = datetime(tomorrow.year, tomorrow.month, tomorrow.day, 23, 59, 59)
            
            logger.info(f"🔍 Ищу встречи на завтра: {start_of_tomorrow.strftime('%d.%m.%Y')}")
            logger.info(f"🔍 Временной диапазон: {start_of_tomorrow.strftime('%H:%M')} - {end_of_tomorrow.strftime('%H:%M')}")
            
            meetings = session.query(Meeting).filter(
                Meeting.date_time >= start_of_tomorrow,
                Meeting.date_time <= end_of_tomorrow,
                Meeting.is_active == True
            ).all()
            
            logger.info(f"📊 Найдено встреч на завтра: {len(meetings)}")
            
            for meeting in meetings:
                logger.info(f"🎯 ВСТРЕЧА: '{meeting.title}'")
                logger.info(f"   📅 Дата: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}")
                logger.info(f"   ⏱️ Длительность: {meeting.duration} мин")
                logger.info(f"   🔗 Zoom ссылка: {'✅ ЕСТЬ' if meeting.zoom_link else '❌ НЕТ'}")
                
                # Проверяем, отправляли ли уже напоминание
                existing_reminder = session.query(Reminder).filter_by(
                    meeting_id=meeting.id,
                    reminder_type='day_before'
                ).first()
                
                if existing_reminder:
                    logger.info(f"   ⚠️ Ежедневное напоминание УЖЕ отправлено в {existing_reminder.sent_at}")
                else:
                    logger.info(f"   🚀 ОТПРАВЛЯЮ ежедневное напоминание...")
                    await self.send_day_reminder(meeting, session)
            
            if not meetings:
                logger.info("📭 Нет встреч на завтра")
                
        except Exception as e:
            logger.error(f"❌ Ошибка в check_daily_reminders: {e}", exc_info=True)
        finally:
            session.close()
            logger.info("📅 === ПРОВЕРКА ЕЖЕДНЕВНЫХ НАПОМИНАНИЙ ЗАВЕРШЕНА ===")
    
    async def send_day_reminder(self, meeting, session):
        """Отправка напоминания за день"""
        try:
            # Находим ВСЕХ активных подписчиков
            subscribers = session.query(User).join(Subscription).filter(
                Subscription.is_active == True,
                Subscription.end_date >= datetime.now()
            ).all()
            
            logger.info(f"👥 Найдено активных подписчиков: {len(subscribers)}")
            
            sent_count = 0
            error_count = 0
            
            # Формируем текст сообщения
            text = f"""📅 **Напоминаем 🤍**

Уже завтра состоится встреча клуба «Бестужевки».

**Тема:** {meeting.title}
**Время:** {meeting.date_time.strftime('%d.%m.%Y в %H:%M')}
**Продолжительность:** {meeting.duration} минут
**Формат:** Zoom

Ссылка появится здесь за 15 минут до начала эфира."""
            
            for user in subscribers:
                try:
                    # Проверяем настройки пользователя
                    settings = user.settings or {}
                    if not settings.get('reminders', True):
                        logger.debug(f"   ⚠️ Пользователь {user.id} отключил напоминания")
                        continue
                    
                    await self.bot.send_message(
                        chat_id=user.telegram_id,
                        text=text,
                        parse_mode='Markdown'
                    )
                    sent_count += 1
                    
                    # Создаем запись о напоминании
                    reminder = Reminder(
                        user_id=user.id,
                        meeting_id=meeting.id,
                        reminder_type='day_before',
                        scheduled_time=datetime.now(),
                        sent=True,
                        sent_at=datetime.now()
                    )
                    session.add(reminder)
                    
                    logger.debug(f"   ✅ Отправлено пользователю {user.id}")
                    
                except Exception as e:
                    error_count += 1
                    logger.error(f"   ❌ Ошибка отправки пользователю {user.id}: {e}")
            
            # Уведомляем админов
            await self.notify_admins_about_reminder(meeting, 'day_before', sent_count, error_count)
            
            logger.info(f"📤 ИТОГО отправлено: {sent_count}, ошибок: {error_count}")
            session.commit()
            
        except Exception as e:
            logger.error(f"❌ Ошибка в send_day_reminder: {e}", exc_info=True)
    
    async def check_15_min_reminders(self):
        """Проверка 15-минутных напоминаний - КАЖДУЮ МИНУТУ"""
        logger.info("⏰ === ПРОВЕРКА 15-МИНУТНЫХ НАПОМИНАНИЙ ===")
        
        session = get_session(self.engine)
        
        try:
            now = datetime.now()
            # Ищем встречи, которые начнутся через 15 минут (± 1 минута для точности)
            target_time = now + timedelta(minutes=15)
            time_window_start = target_time - timedelta(minutes=1)
            time_window_end = target_time + timedelta(minutes=1)
            
            logger.info(f"🔍 Текущее время: {now.strftime('%H:%M:%S')}")
            logger.info(f"🔍 Ищу встречи, которые начнутся в: {target_time.strftime('%H:%M')}")
            logger.info(f"🔍 Окно поиска: {time_window_start.strftime('%H:%M:%S')} - {time_window_end.strftime('%H:%M:%S')}")
            
            meetings = session.query(Meeting).filter(
                Meeting.date_time >= time_window_start,
                Meeting.date_time <= time_window_end,
                Meeting.is_active == True
            ).all()
            
            logger.info(f"📊 Найдено встреч через 15 минут: {len(meetings)}")
            
            for meeting in meetings:
                minutes_diff = int((meeting.date_time - now).total_seconds() / 60)
                logger.info(f"🎯 ВСТРЕЧА: '{meeting.title}'")
                logger.info(f"   📅 Дата: {meeting.date_time.strftime('%d.%m.%Y %H:%M:%S')}")
                logger.info(f"   ⏱️ Начнется через: {minutes_diff} минут")
                logger.info(f"   🔗 Zoom ссылка: {'✅ ЕСТЬ' if meeting.zoom_link else '❌ НЕТ'}")
                if meeting.zoom_link:
                    logger.info(f"   🔑 Пароль: {meeting.zoom_password or 'не требуется'}")
                
                # Проверяем, отправляли ли уже напоминание
                existing_reminder = session.query(Reminder).filter_by(
                    meeting_id=meeting.id,
                    reminder_type='15_min_before'
                ).first()
                
                if existing_reminder:
                    logger.info(f"   ⚠️ 15-минутное напоминание УЖЕ отправлено в {existing_reminder.sent_at}")
                else:
                    logger.info(f"   🚀 ОТПРАВЛЯЮ 15-минутное напоминание...")
                    await self.send_15_min_reminder(meeting, session)
            
            if not meetings:
                logger.info("📭 Нет встреч через 15 минут")
                
        except Exception as e:
            logger.error(f"❌ Ошибка в check_15_min_reminders: {e}", exc_info=True)
        finally:
            session.close()
            logger.info("⏰ === ПРОВЕРКА 15-МИНУТНЫХ НАПОМИНАНИЙ ЗАВЕРШЕНА ===")
    
    async def send_15_min_reminder(self, meeting, session):
        """Отправка напоминания за 15 минут"""
        try:
            # Находим ВСЕХ активных подписчиков
            subscribers = session.query(User).join(Subscription).filter(
                Subscription.is_active == True,
                Subscription.end_date >= datetime.now()
            ).all()
            
            logger.info(f"👥 Найдено активных подписчиков для 15-минутного напоминания: {len(subscribers)}")
            
            sent_count = 0
            error_count = 0
            
            # Формируем текст сообщения
            if not meeting.zoom_link:
                text = f"""⏰ **Встречаемся совсем скоро 🤍**

Через 15 мин начинается лекция клуба «Бестужевки».

**Тема:** {meeting.title}
**Время:** {meeting.date_time.strftime('%H:%M')}

Ссылка будет отправлена в ближайшее время.

Ждём вас!"""
            else:
                text = f"""⏰ **Встречаемся совсем скоро 🤍**

Через 15 мин начинается лекция клуба «Бестужевки».

**Тема:** {meeting.title}
**Время:** {meeting.date_time.strftime('%H:%M')}
**Ссылка:** {meeting.zoom_link}
**Пароль:** {meeting.zoom_password or 'не требуется'}

Ждём вас!"""
            
            for user in subscribers:
                try:
                    # Проверяем настройки пользователя
                    settings = user.settings or {}
                    if not settings.get('reminders', True):
                        logger.debug(f"   ⚠️ Пользователь {user.id} отключил напоминания")
                        continue
                    
                    await self.bot.send_message(
                        chat_id=user.telegram_id,
                        text=text,
                        parse_mode='Markdown'
                    )
                    sent_count += 1
                    
                    # Создаем запись о напоминании
                    reminder = Reminder(
                        user_id=user.id,
                        meeting_id=meeting.id,
                        reminder_type='15_min_before',
                        scheduled_time=datetime.now(),
                        sent=True,
                        sent_at=datetime.now()
                    )
                    session.add(reminder)
                    
                    logger.debug(f"   ✅ Отправлено пользователю {user.id}")
                    
                except Exception as e:
                    error_count += 1
                    logger.error(f"   ❌ Ошибка отправки пользователю {user.id}: {e}")
            
            # Уведомляем админов
            await self.notify_admins_about_reminder(meeting, '15_min_before', sent_count, error_count)
            
            logger.info(f"📤 ИТОГО отправлено: {sent_count}, ошибок: {error_count}")
            session.commit()
            
        except Exception as e:
            logger.error(f"❌ Ошибка в send_15_min_reminder: {e}", exc_info=True)
    
    async def check_live_streams(self):
        """Проверка встреч, которые начались прямо сейчас"""
        logger.info("🎥 === ПРОВЕРКА ТЕКУЩИХ ТРАНСЛЯЦИЙ ===")
        
        session = get_session(self.engine)
        
        try:
            now = datetime.now()
            # Ищем встречи, которые начались в последние 5 минут
            time_window_start = now - timedelta(minutes=5)
            
            logger.info(f"🔍 Текущее время: {now.strftime('%H:%M:%S')}")
            logger.info(f"🔍 Ищу встречи, начавшиеся с: {time_window_start.strftime('%H:%M:%S')}")
            
            meetings = session.query(Meeting).filter(
                Meeting.date_time >= time_window_start,
                Meeting.date_time <= now,
                Meeting.is_active == True,
                Meeting.zoom_link.isnot(None)  # Только с Zoom ссылкой
            ).all()
            
            logger.info(f"📊 Найдено начавшихся встреч с Zoom: {len(meetings)}")
            
            for meeting in meetings:
                minutes_ago = int((now - meeting.date_time).total_seconds() / 60)
                logger.info(f"🎯 ТРАНСЛЯЦИЯ: '{meeting.title}'")
                logger.info(f"   📅 Началась: {meeting.date_time.strftime('%H:%M:%S')}")
                logger.info(f"   ⏱️ Минут назад: {minutes_ago}")
                logger.info(f"   🔗 Zoom: {meeting.zoom_link[:50]}...")
                logger.info(f"   🔑 Пароль: {meeting.zoom_password or 'не требуется'}")
                
                # Проверяем, отправляли ли уже уведомление
                existing_reminder = session.query(Reminder).filter_by(
                    meeting_id=meeting.id,
                    reminder_type='during_stream'
                ).first()
                
                if existing_reminder:
                    logger.info(f"   ⚠️ Уведомление о трансляции УЖЕ отправлено в {existing_reminder.sent_at}")
                else:
                    logger.info(f"   🚀 ОТПРАВЛЯЮ уведомление о начале трансляции...")
                    await self.send_zoom_during_stream(meeting, session)
            
            if not meetings:
                logger.info("📭 Нет активных трансляций")
                
        except Exception as e:
            logger.error(f"❌ Ошибка в check_live_streams: {e}", exc_info=True)
        finally:
            session.close()
            logger.info("🎥 === ПРОВЕРКА ТЕКУЩИХ ТРАНСЛЯЦИЙ ЗАВЕРШЕНА ===")
    
    async def send_zoom_during_stream(self, meeting, session):
        """Отправка Zoom ссылки во время трансляции"""
        try:
            # Находим ВСЕХ активных подписчиков
            subscribers = session.query(User).join(Subscription).filter(
                Subscription.is_active == True,
                Subscription.end_date >= datetime.now()
            ).all()
            
            logger.info(f"👥 Найдено подписчиков для уведомления о трансляции: {len(subscribers)}")
            
            sent_count = 0
            error_count = 0
            
            # Формируем текст сообщения
            text = f"""🎥 **Трансляция началась!**

**Тема:** {meeting.title}
**Ссылка для входа:** {meeting.zoom_link}
**Пароль:** {meeting.zoom_password or 'не требуется'}

Присоединяйтесь к встрече!"""
            
            for user in subscribers:
                try:
                    # Проверяем настройки пользователя
                    settings = user.settings or {}
                    if not settings.get('reminders', True):
                        logger.debug(f"   ⚠️ Пользователь {user.id} отключил напоминания")
                        continue
                    
                    await self.bot.send_message(
                        chat_id=user.telegram_id,
                        text=text,
                        parse_mode='Markdown'
                    )
                    sent_count += 1
                    
                    # Создаем запись о напоминании
                    reminder = Reminder(
                        user_id=user.id,
                        meeting_id=meeting.id,
                        reminder_type='during_stream',
                        scheduled_time=datetime.now(),
                        sent=True,
                        sent_at=datetime.now()
                    )
                    session.add(reminder)
                    
                    logger.debug(f"   ✅ Отправлено пользователю {user.id}")
                    
                except Exception as e:
                    error_count += 1
                    logger.error(f"   ❌ Ошибка отправки пользователю {user.id}: {e}")
            
            # Уведомляем админов
            await self.notify_admins_about_stream(meeting, sent_count, error_count)
            
            logger.info(f"📤 ИТОГО отправлено: {sent_count}, ошибок: {error_count}")
            session.commit()
            
        except Exception as e:
            logger.error(f"❌ Ошибка в send_zoom_during_stream: {e}", exc_info=True)
    
    async def check_subscriptions(self):
        """Проверка подписок"""
        logger.info("🔔 Проверка подписок")
        
        session = get_session(self.engine)
        
        try:
            week_later = datetime.now() + timedelta(days=7)
            subscriptions = session.query(Subscription).filter(
                Subscription.end_date <= week_later,
                Subscription.end_date >= datetime.now(),
                Subscription.is_active == True
            ).all()
            
            logger.info(f"📊 Подписок, заканчивающихся через 7 дней: {len(subscriptions)}")
            
            for subscription in subscriptions:
                await self.send_subscription_reminder(subscription, session)
                
        except Exception as e:
            logger.error(f"Ошибка в check_subscriptions: {e}")
        finally:
            session.close()
    
    async def send_subscription_reminder(self, subscription, session):
        """Напоминание об окончании подписки"""
        try:
            user = subscription.user
            days_left = (subscription.end_date - datetime.now()).days
            
            settings = user.settings or {}
            if not settings.get('notifications', True):
                return
            
            text = f"""⏳ **Напоминание о подписке**

Ваша подписка заканчивается через {days_left} дней.

Хотите продлить подписку?"""
            
            try:
                await self.bot.send_message(
                    chat_id=user.telegram_id,
                    text=text,
                    parse_mode='Markdown'
                )
                logger.info(f"📤 Напоминание о подписке отправлено пользователю {user.id}")
                
                await self.notify_admins_about_subscription_reminder(user, days_left)
                
            except Exception as e:
                logger.error(f"❌ Ошибка отправки пользователю {user.id}: {e}")
            
        except Exception as e:
            logger.error(f"❌ Ошибка в send_subscription_reminder: {e}")
    
    async def check_ignore_reminders(self):
        """Проверка игнора"""
        logger.info("🔔 Проверка 'игнора'")
        
        session = get_session(self.engine)
        
        try:
            yesterday = datetime.now() - timedelta(days=1)
            
            users = session.query(User).filter(
                User.agreed_to_policy == True,
                User.phone_number == None,
                User.joined_at <= yesterday.replace(hour=18, minute=0, second=0)
            ).all()
            
            logger.info(f"📊 Пользователей с незавершенной регистрацией: {len(users)}")
            
            for user in users:
                await self.send_ignore_reminder(user, session)
                
        except Exception as e:
            logger.error(f"Ошибка в check_ignore_reminders: {e}")
        finally:
            session.close()
    
    async def send_ignore_reminder(self, user, session):
        """Отправка напоминания об игноре"""
        try:
            settings = user.settings or {}
            if not settings.get('notifications', True):
                return
            
            text = """🤍 **Привет!**

Мы заметили, что ты начала регистрацию в клубе «Бестужевки», но не завершила её.

Хочешь продолжить регистрацию и получить доступ ко всем возможностям клуба?

Просто нажми /start и заверши регистрацию!"""
            
            try:
                await self.bot.send_message(
                    chat_id=user.telegram_id,
                    text=text,
                    parse_mode='Markdown'
                )
                logger.info(f"📤 Напоминание об 'игноре' отправлено пользователю {user.id}")
            except Exception as e:
                logger.error(f"❌ Ошибка отправки пользователю {user.id}: {e}")
            
        except Exception as e:
            logger.error(f"❌ Ошибка в send_ignore_reminder: {e}")
    
    async def check_monthly_reminders(self):
        """Напоминание за 7 дней до конца месяца"""
        logger.info("🔔 Месячное напоминание (за 7 дней до конца месяца)")
        
        session = get_session(self.engine)
        
        try:
            users = session.query(User).filter(
                User.agreed_to_policy == True,
                User.phone_number.isnot(None)
            ).outerjoin(Subscription).filter(
                (Subscription.id == None) |
                (Subscription.is_active == False) |
                (Subscription.end_date < datetime.now())
            ).distinct().all()
            
            logger.info(f"📊 Потенциальных участников для месячного напоминания: {len(users)}")
            
            for user in users:
                await self.send_monthly_reminder(user, session, '7_days')
                
        except Exception as e:
            logger.error(f"Ошибка в check_monthly_reminders: {e}")
        finally:
            session.close()
    
    async def check_last_day_reminders(self):
        """Напоминание в последний день месяца"""
        logger.info("🔔 Месячное напоминание (последний день месяца)")
        
        session = get_session(self.engine)
        
        try:
            users = session.query(User).filter(
                User.agreed_to_policy == True,
                User.phone_number.isnot(None)
            ).outerjoin(Subscription).filter(
                (Subscription.id == None) |
                (Subscription.is_active == False) |
                (Subscription.end_date < datetime.now())
            ).distinct().all()
            
            logger.info(f"📊 Потенциальных участников для напоминания в последний день: {len(users)}")
            
            for user in users:
                await self.send_monthly_reminder(user, session, 'last_day')
                
        except Exception as e:
            logger.error(f"Ошибка в check_last_day_reminders: {e}")
        finally:
            session.close()
    
    async def send_monthly_reminder(self, user, session, reminder_type):
        """Напоминание о записи в клуб"""
        try:
            settings = user.settings or {}
            if not settings.get('notifications', True):
                return


'''
        # ВРЕМЕННО ЗАКОММЕНТИРОВАНО
            
            if reminder_type == '7_days':
                text = """🗓️ **Привет!**

Ты уже интересовалась клубом «Бестужевки», у нас хорошая новость: открыта запись на следующий месяц. 

В течение 7 дней у тебя есть возможность присоединиться к клубу по специальным условиям для новых участниц.

Используй команду /start, чтобы увидеть доступные тарифы!"""
            else:
                text = """⏰ **Здравствуй!**

Напоминаем, что сегодня последний день вступления в клуб «Бестужевки» в этом месяце. 

В следующий раз запись откроется через месяц. Не упусти шанс присоединиться сейчас!

Ждём тебя! Используй /start для выбора тарифа."""
            
            try:
                await self.bot.send_message(
                    chat_id=user.telegram_id,
                    text=text,
                    parse_mode='Markdown'
                )
                logger.info(f"📤 Месячное напоминание ({reminder_type}) отправлено пользователю {user.id}")
            except Exception as e:
                logger.error(f"❌ Ошибка отправки пользователю {user.id}: {e}")
            '''

        except Exception as e:
            logger.error(f"❌ Ошибка в send_monthly_reminder: {e}")
    
    async def notify_admins_about_stream(self, meeting, sent_count, error_count):
        """Уведомление админов о начале трансляции"""
        try:
            for admin_id in Config.ADMIN_IDS:
                try:
                    text = f"""📊 **Уведомление от бота**

🎥 **Началась трансляция:**
• Тема: {meeting.title}
• Время: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
• Отправлено пользователям: {sent_count}
• Ошибок отправки: {error_count}

✅ Система уведомлений работает."""
                    
                    await self.bot.send_message(
                        chat_id=admin_id,
                        text=text,
                        parse_mode='Markdown'
                    )
                except Exception as e:
                    logger.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
        except Exception as e:
            logger.error(f"Ошибка в notify_admins_about_stream: {e}")
    
    async def notify_admins_about_reminder(self, meeting, reminder_type, sent_count, error_count):
        """Уведомление админов о напоминаниях"""
        try:
            reminder_names = {
                'day_before': 'За 24 часа',
                '15_min_before': 'За 15 минут',
                'during_stream': 'Во время трансляции'
            }
            
            reminder_name = reminder_names.get(reminder_type, reminder_type)
            
            for admin_id in Config.ADMIN_IDS:
                try:
                    text = f"""📊 **Уведомление от бота**

⏰ **Отправлено напоминание ({reminder_name}):**
• Тема: {meeting.title}
• Время: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
• Отправлено пользователям: {sent_count}
• Ошибок отправки: {error_count}

✅ Система уведомлений работает."""
                    
                    await self.bot.send_message(
                        chat_id=admin_id,
                        text=text,
                        parse_mode='Markdown'
                    )
                except Exception as e:
                    logger.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
        except Exception as e:
            logger.error(f"Ошибка в notify_admins_about_reminder: {e}")
    
    async def notify_admins_about_subscription_reminder(self, user, days_left):
        """Уведомление админов о напоминаниях о подписках"""
        try:
            for admin_id in Config.ADMIN_IDS:
                try:
                    text = f"""📊 **Уведомление от бота**

⏰ **Отправлено напоминание о подписке:**
• Пользователь: {user.first_name or 'Без имени'} (@{user.username or 'нет'})
• ID: {user.id}
• Осталось дней: {days_left}

✅ Напоминание отправлено."""
                    
                    await self.bot.send_message(
                        chat_id=admin_id,
                        text=text,
                        parse_mode='Markdown'
                    )
                except Exception as e:
                    logger.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
        except Exception as e:
            logger.error(f"Ошибка в notify_admins_about_subscription_reminder: {e}")

def setup_scheduler(application, engine):
    """Настройка планировщика"""
    try:
        scheduler = SchedulerManager(application.bot, engine)
        
        class SimpleContext:
            def __init__(self, bot, engine):
                self.bot = bot
                self.bot_data = {'engine': engine}
        
        scheduler.context = SimpleContext(application.bot, engine)
        
        scheduler.start()
        logger.info("✅ Планировщик успешно настроен")
        return scheduler
    except Exception as e:
        logger.error(f"❌ Ошибка настройки планировщика: {e}")
        return None
