# keyboards.py
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from config import Config

def get_privacy_keyboard():
    """Клавиатура для политики конфиденциальности"""
    keyboard = [
        [
            InlineKeyboardButton("📄 Ознакомиться с политикой", 
                               url=Config.PRIVACY_POLICY_URL),
        ],
        [
            InlineKeyboardButton("✅ Я согласна и готова продолжить", 
                               callback_data='agree_policy')
        ]
    ]
    return InlineKeyboardMarkup(keyboard)


def get_phone_request_keyboard():
    """Инлайн-кнопка для перехода к запросу телефона"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📱 Поделиться номером", callback_data="request_phone_contact")]
    ])

def get_privacy_consent_keyboard():
    """Клавиатура для согласия на обработку персональных данных"""
    keyboard = [
        [
            InlineKeyboardButton("📄 Политика конфиденциальности", 
                               url="https://docs.google.com/document/d/1iu7icXKeUAnr0alINYb_2U6jut0C22BX1ZsyaSCFfAg/edit?tab=t.0"),
        ],
        [
            InlineKeyboardButton("📋 Согласие на обработку ПД", 
                               url="https://clck.ru/3RNQXa"),
        ],
        [
            InlineKeyboardButton("✅ Даю согласие", 
                               callback_data='agree_policy'),
            InlineKeyboardButton("❌ Не даю согласие", 
                               callback_data='decline_policy')
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_main_menu_keyboard(is_admin=False):
    """Главное меню (сэндвич)"""
    keyboard = [
        [InlineKeyboardButton("💙 О клубе", callback_data='about_club')],
        [InlineKeyboardButton("📅 Формат и расписание", callback_data='format_schedule')],
        [InlineKeyboardButton("💰 Тарифы", callback_data='tariffs')],
        [InlineKeyboardButton("👨‍🏫 Спикеры", callback_data='speakers')],
        [InlineKeyboardButton("📅 Программа", callback_data='programm')],
        [InlineKeyboardButton("❓ FAQ", callback_data='faq')],
        [InlineKeyboardButton("✍️ Написать менеджеру", callback_data='contact_manager')]
    ]
    
    # Добавляем админ-панель если пользователь админ
    if is_admin:
        keyboard.append([InlineKeyboardButton("👨‍💼 Админ-панель", callback_data='admin_panel')])
    
    return InlineKeyboardMarkup(keyboard)

def get_speakers_keyboard():
    """Клавиатура для раздела Спикеры"""
    keyboard = [
        [InlineKeyboardButton("🏛️ Мария Емельяненкова - История России", callback_data='speaker_history')],
        [InlineKeyboardButton("👑 Екатерина Сартакова - Этикет", callback_data='speaker_etiquette')],
        [InlineKeyboardButton("🚀 Денис Коротыч - Философия предпринимательства", callback_data='speaker_philosophy_entrepreneurship')],
        [InlineKeyboardButton("🖼️ Ольга Чуворкина- История искусств", callback_data='speaker_art_history')],
        [InlineKeyboardButton("🖼️ Мария Мороз - История искусств", callback_data='speaker_art_history2')],
        [InlineKeyboardButton("◀️ Назад в меню", callback_data='back_to_main')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_speaker_detail_keyboard():
    """Клавиатура для детальной информации о спикере"""
    keyboard = [
        [
            InlineKeyboardButton("⬅️ Назад к спикерам", callback_data="back_to_speakers"),
            InlineKeyboardButton("🏠 В главное меню", callback_data="back_to_main"),
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

# ========== КЛАВИАТУРЫ ДЛЯ ПРОГРАММ ==========

def get_programs_keyboard():
    """Клавиатура для раздела Программы"""
    keyboard = [
        [InlineKeyboardButton("🏛️ Программа по Философии", callback_data='program_philosophy')],
        [InlineKeyboardButton("👑 Программа по Этикету", callback_data='program_etiquette')],
        [InlineKeyboardButton("🖼️ Программа по Истории Искусства", callback_data='program_art')],
        [InlineKeyboardButton("🇷🇺 Программа по Истории России", callback_data='program_history')],
        [InlineKeyboardButton("◀️ Назад в меню", callback_data='back_to_main')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_back_to_programs_keyboard():
    """Кнопка Назад к программам"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("◀️ Назад к программам", callback_data='programm')]
    ])

def get_tariffs_keyboard():
    """Клавиатура выбора тарифа"""
    keyboard = [
        [InlineKeyboardButton("✨ 1 месяц - 5000 ₽", callback_data='tariff_1_month')],
        [InlineKeyboardButton("✨ 12 месяцев - 40000 ₽", callback_data='tariff_12_months')],
        [InlineKeyboardButton("◀️ Назад", callback_data='back_to_main')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_payment_keyboard(tariff, promocode_applied=False, promocode=None):
    """Клавиатура для оплаты с промокодом"""
    keyboard = []
    
    if promocode_applied and promocode:
        keyboard.append([
            InlineKeyboardButton(f"🎫 Промокод: {promocode}", callback_data='remove_promocode')
        ])
    else:
        keyboard.append([
            InlineKeyboardButton("🎫 Ввести промокод", callback_data='enter_promocode')
        ])
    
    keyboard.append([
        InlineKeyboardButton("💳 Оплатить", callback_data=f'pay_{tariff}')
    ])
    
    keyboard.append([
        InlineKeyboardButton("◀️ Назад к тарифы", callback_data='back_to_tariffs')
    ])
    
    return InlineKeyboardMarkup(keyboard)

def get_faq_keyboard():
    """Клавиатура FAQ"""
    keyboard = [
        [InlineKeyboardButton("📅 Как часто выходят лекции?", callback_data='faq_frequency')],
        [InlineKeyboardButton("💻 Где проходит обучение?", callback_data='faq_platform')],
        [InlineKeyboardButton("🎥 Можно ли смотреть в записи?", callback_data='faq_recording')],
        [InlineKeyboardButton("📚 Будут ли домашние задания?", callback_data='faq_homework')],
        [InlineKeyboardButton("🗓️ Когда можно присоединиться?", callback_data='faq_join_time')],
        [InlineKeyboardButton("💳 Можно ли оплатить в рассрочку?", callback_data='faq_installment')],
        [InlineKeyboardButton("📦 Как получить бонусы?", callback_data='faq_bonuses')],
        [InlineKeyboardButton("✍️ Написать менеджеру", callback_data='contact_manager')],
        [InlineKeyboardButton("◀️ Назад", callback_data='back_to_main')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_back_keyboard(target='main'):
    """Кнопка Назад - РАСШИРЕНА для поддержки всех разделов"""
    back_mapping = {
        # Основные разделы
        'main': ('◀️ Назад в меню', 'back_to_main'),
        'tariffs': ('◀️ Назад к тарифам', 'back_to_tariffs'),
        'tariff_selection': ('◀️ Назад к выбору тарифа', 'back_to_tariffs'),
        'speakers': ('⬅️ Назад к спикерам', 'back_to_speakers'),
        'faq': ('◀️ Назад к FAQ', 'back_to_faq'),
        'programs': ('◀️ Назад к программам', 'programm'),  # ДОБАВЛЕНО
        
        # Админка
        'admin': ('◀️ Назад в админку', 'admin_back'),
        'admin_reports': ('◀️ Назад к отчетам', 'admin_reports'),
        'admin_stats': ('◀️ Назад к статистике', 'admin_stats'),
        'meetings_list': ('◀️ Назад к списку встреч', 'meetings_list'),
    }
    
    # Если target есть в маппинге, используем его
    if target in back_mapping:
        button_text, callback_data = back_mapping[target]
    else:
        # Для неизвестных целей используем общий fallback
        button_text = "◀️ Назад"
        callback_data = f'back_to_{target}'
    
    keyboard = [[InlineKeyboardButton(button_text, callback_data=callback_data)]]
    return InlineKeyboardMarkup(keyboard)

def get_after_payment_keyboard():
    """Клавиатура после оплата"""
    keyboard = [
        [InlineKeyboardButton("💬 Вступить в чат клуба", url=Config.CLUB_CHAT_LINK)],
        [InlineKeyboardButton("📅 Добавить в календарь", callback_data='add_to_calendar')],
        [InlineKeyboardButton("📚 Материалы", callback_data='materials')]
    ]
    return InlineKeyboardMarkup(keyboard)
    
def get_admin_reports_keyboard():
    """Клавиатура отчетов для админов - ОБНОВЛЕНА"""
    keyboard = [
        [InlineKeyboardButton("📊 Отчет за неделю", callback_data='admin_report_week')],
        [InlineKeyboardButton("📈 Отчет за месяц", callback_data='admin_report_month')],
        [InlineKeyboardButton("📅 Кастомный отчет", callback_data='admin_report_custom')],
        [InlineKeyboardButton("📥 Excel выгрузка", callback_data='admin_excel_export')],
        [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_admin_keyboard():
    """Админ-панель"""
    keyboard = [
        [InlineKeyboardButton("📊 Статистика", callback_data='admin_stats')],
        [InlineKeyboardButton("📈 Отчеты", callback_data='admin_reports')],
        [InlineKeyboardButton("👥 Пользователи", callback_data='admin_users')],
        [InlineKeyboardButton("📅 Встречи", callback_data='admin_meetings')],
        [InlineKeyboardButton("💰 Платежи", callback_data='admin_payments')],
        [InlineKeyboardButton("🎫 Промокоды", callback_data='admin_promocodes')],
        [InlineKeyboardButton("📢 Рассылка", callback_data='admin_broadcast')],
        [InlineKeyboardButton("❓ FAQ (управление)", callback_data='admin_faq')],
        [InlineKeyboardButton("📈 Метрики", callback_data='admin_metrics')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_yes_no_keyboard():
    """Клавиатура Да/Нет"""
    keyboard = [
        [InlineKeyboardButton("✅ Да", callback_data='yes'), 
         InlineKeyboardButton("❌ Нет", callback_data='no')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_phone_keyboard():
    """Клавиатура для получения номера телефона (ReplyKeyboardMarkup)"""
    keyboard = [[KeyboardButton("📱 Поделиться номером", request_contact=True)]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)

def get_meetings_management_keyboard():
    """Клавиатура для управления встречами"""
    keyboard = [
        [InlineKeyboardButton("➕ Создать встречу", callback_data='create_meeting')],
        [InlineKeyboardButton("📋 Список встреч", callback_data='meetings_list')],
        [InlineKeyboardButton("✏️ Редактировать встречу", callback_data='edit_meeting_menu')],
        [InlineKeyboardButton("❌ Удалить встречу", callback_data='delete_meeting_menu')],
        [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_meetings_list_keyboard():
    """Клавиатура для списка встреч (базовая)"""
    keyboard = [
        [InlineKeyboardButton("➕ Создать встречу", callback_data='create_meeting')],
        [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_meetings_list_with_options_keyboard():
    """Клавиатура для списка встреч с дополнительными опциями"""
    keyboard = [
        [InlineKeyboardButton("➕ Создать встречу", callback_data='create_meeting')],
        [InlineKeyboardButton("✏️ Редактировать", callback_data='edit_meeting_menu')],
        [InlineKeyboardButton("❌ Удалить", callback_data='delete_meeting_menu')],
        [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_edit_meeting_keyboard():
    """Клавиатура для редактирования встречи"""
    keyboard = [
        [InlineKeyboardButton("🏷️ Изменить название", callback_data='edit_meeting_title')],
        [InlineKeyboardButton("📅 Изменить дату/время", callback_data='edit_meeting_date')],
        [InlineKeyboardButton("⏱️ Изменить продолжительность", callback_data='edit_meeting_duration')],
        [InlineKeyboardButton("📝 Изменить описание", callback_data='edit_meeting_description')],
        [InlineKeyboardButton("🔗 Изменить Zoom ссылку", callback_data='edit_meeting_zoom')],
        [InlineKeyboardButton("✅ Активировать/Деактивировать", callback_data='edit_meeting_status')],
        [InlineKeyboardButton("◀️ Назад к списку", callback_data='meetings_list')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_delete_confirmation_keyboard(meeting_id=None):
    """Клавиатура для подтверждения удаления встречи"""
    if meeting_id:
        keyboard = [
            [
                InlineKeyboardButton("✅ Да, удалить", callback_data=f'confirm_delete_{meeting_id}'),
                InlineKeyboardButton("❌ Нет, отменить", callback_data='meetings_list')
            ]
        ]
    else:
        keyboard = [
            [InlineKeyboardButton("❌ Отмена удаления", callback_data='meetings_list')]
        ]
    return InlineKeyboardMarkup(keyboard)

def get_cancel_keyboard(target='meetings_list'):
    """Клавиатура с кнопкой отмены"""
    if target == 'admin_back':
        button_text = "◀️ Назад в админку"
    elif target == 'meetings_list':
        button_text = "◀️ Назад к списку"
    else:
        button_text = "❌ Отмена"
    
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(button_text, callback_data=target)]
    ])

def get_meeting_selection_keyboard(meetings, action_prefix='select_'):
    """Динамическая клавиатура для выбора встречи"""
    keyboard = []
    
    for meeting in meetings[:10]:  # Ограничиваем 10 встречами
        # Форматируем текст для кнопки
        date_str = meeting.date_time.strftime('%d.%m %H:%M')
        button_text = f"📅 {date_str} - {meeting.title[:20]}..."
        if len(meeting.title) > 20:
            button_text = f"📅 {date_str} - {meeting.title[:20]}..."
        else:
            button_text = f"📅 {date_str} - {meeting.title}"
        
        keyboard.append([
            InlineKeyboardButton(button_text, callback_data=f'{action_prefix}{meeting.id}')
        ])
    
    keyboard.append([InlineKeyboardButton("◀️ Назад к списку", callback_data='meetings_list')])
    
    return InlineKeyboardMarkup(keyboard)

def get_meeting_detail_keyboard(meeting_id):
    """Клавиатура для детального просмотра встречи"""
    keyboard = [
        [
            InlineKeyboardButton("✏️ Редактировать", callback_data=f'edit_{meeting_id}'),
            InlineKeyboardButton("❌ Удалить", callback_data=f'delete_{meeting_id}')
        ],
        [InlineKeyboardButton("🔗 Добавить/Изменить Zoom", callback_data=f'add_zoom_{meeting_id}')],
        [InlineKeyboardButton("◀️ Назад к списку", callback_data='meetings_list')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_admin_back_keyboard():
    """Просто кнопка Назад в админку"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
    ])

def get_status_change_keyboard(meeting_id):
    """Клавиатура для изменения статуса встречи"""
    keyboard = [
        [
            InlineKeyboardButton("✅ Активировать", callback_data=f'change_status_active_{meeting_id}'),
            InlineKeyboardButton("⏸️ Деактивировать", callback_data=f'change_status_inactive_{meeting_id}')
        ],
        [InlineKeyboardButton("❌ Отмена", callback_data=f'edit_{meeting_id}')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_excel_export_keyboard():
    """Клавиатура для выбора типа Excel выгрузки"""
    keyboard = [
        [InlineKeyboardButton("📊 Полный отчет", callback_data='excel_full_report')],
        [InlineKeyboardButton("👥 Пользователи", callback_data='excel_users')],
        [InlineKeyboardButton("💰 Платежи", callback_data='excel_payments')],
        [InlineKeyboardButton("📅 Подписки", callback_data='excel_subscriptions')],
        [InlineKeyboardButton("🎫 Промокоды", callback_data='excel_promocodes')],
        [InlineKeyboardButton("◀️ Назад к отчетам", callback_data='admin_reports')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_custom_report_keyboard():
    """Клавиатура для кастомных отчетов"""
    keyboard = [
        [
            InlineKeyboardButton("📊 Сегодня", callback_data='custom_today'),
            InlineKeyboardButton("📊 Вчера", callback_data='custom_yesterday'),
        ],
        [
            InlineKeyboardButton("📅 За период", callback_data='custom_period'),
            InlineKeyboardButton("📈 По тарифам", callback_data='custom_by_tariff'),
        ],
        [
            InlineKeyboardButton("📥 Excel выгрузка", callback_data='admin_excel_export'),
            InlineKeyboardButton("◀️ Назад", callback_data='admin_reports')
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_report_period_keyboard():
    """Клавиатура для выбора периода отчета"""
    keyboard = [
        [InlineKeyboardButton("📅 Сегодня", callback_data='period_today')],
        [InlineKeyboardButton("📅 Вчера", callback_data='period_yesterday')],
        [InlineKeyboardButton("📅 Последние 7 дней", callback_data='period_week')],
        [InlineKeyboardButton("📅 Последние 30 дней", callback_data='period_month')],
        [InlineKeyboardButton("📅 Этот месяц", callback_data='period_this_month')],
        [InlineKeyboardButton("📅 Прошлый месяц", callback_data='period_last_month')],
        [InlineKeyboardButton("◀️ Назад к отчетам", callback_data='admin_reports')]
    ]
    return InlineKeyboardMarkup(keyboard)

# ========== НОВЫЕ КЛАВИАТУРЫ ДЛЯ ZOOM ==========

def get_zoom_mode_keyboard(meeting_id):
    """Клавиатура выбора способа добавления Zoom"""
    keyboard = [
        [
            InlineKeyboardButton("🤖 Автосоздание (API)", 
                               callback_data=f'auto_zoom_{meeting_id}'),
            InlineKeyboardButton("👤 Ввести ссылку", 
                               callback_data=f'manual_zoom_{meeting_id}')
        ],
        [InlineKeyboardButton("❌ Отмена", callback_data='meetings_list')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_zoom_success_keyboard(meeting_id):
    """Клавиатура после успешного создания Zoom встречи"""
    keyboard = [
        [
            InlineKeyboardButton("📋 Поделиться ссылкой", 
                               callback_data=f'zoom_share_{meeting_id}'),
            InlineKeyboardButton("📅 Посмотреть детали", 
                               callback_data=f'edit_{meeting_id}')
        ],
        [InlineKeyboardButton("◀️ Назад к списку", callback_data='meetings_list')]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_zoom_share_keyboard(meeting_id):
    """Клавиатура для шаринга Zoom ссылки"""
    keyboard = [
        [
            InlineKeyboardButton("📱 Отправить участникам", 
                               callback_data=f'send_zoom_to_all_{meeting_id}'),
            InlineKeyboardButton("📋 Копировать ссылку", 
                               callback_data=f'copy_zoom_{meeting_id}')
        ],
        [InlineKeyboardButton("◀️ Назад", callback_data=f'edit_{meeting_id}')]
    ]
    return InlineKeyboardMarkup(keyboard)
