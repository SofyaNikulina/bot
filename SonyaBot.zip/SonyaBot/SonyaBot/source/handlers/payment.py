from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from database import get_session, User, Payment, Subscription, PromoUsage, Promocode
from keyboards import get_payment_keyboard, get_tariffs_keyboard, get_after_payment_keyboard, get_back_keyboard
from config import Config
from datetime import datetime, timedelta
import logging
import json
import uuid
import time

logger = logging.getLogger(__name__)

# ========== ТИНЬКОФФ ОПЛАТА ==========
try:
    from tinkoff_api import tbank
    logger.info("✅ Модуль tinkoff_api загружен")
except ImportError as e:
    logger.error(f"❌ Модуль tinkoff_api не найден: {e}")
    tbank = None

async def handle_tariff_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик выбора тарифа"""
    query = update.callback_query
    await query.answer()
    
    tariff_key = query.data.replace('tariff_', '')
    tariff_info = Config.TARIFFS.get(tariff_key)
    
    if not tariff_info:
        await query.message.reply_text("Извините, выбранный тариф недоступен.")
        return
    
    # Сохраняем выбранный тариф
    context.user_data['selected_tariff'] = tariff_key
    context.user_data['selected_tariff_info'] = tariff_info
    
    logger.info(f"✅ Пользователь {query.from_user.id} выбрал тариф: {tariff_key}")
    
    # Показываем информацию о тарифе
    price = tariff_info['price'] / 100
    
    text = f"""<b>Выбран тариф:</b> {tariff_info['label']}
    
<b>Описание:</b> {tariff_info['description']}
    
<b>Цена:</b> {price:,.0f} ₽
    
<b>Входит в тариф:</b>
• Еженедельные лекции и встречи в Zoom
• Доступ к записям
• Закрытое сообщество клуба
• Дополнительные материалы"""
    
    if tariff_key == '12_months':
        text += "\n\n🎁 <b>Бонусы:</b> рабочая тетрадь А4 и наклейки"
    
    text += "\n\nВы можете применить промокод или перейти к оплате."
    
    # Проверяем, можно ли редактировать сообщение (есть ли текст)
    try:
        await query.message.edit_text(
            text,
            reply_markup=get_payment_keyboard(tariff_key),
            parse_mode='HTML'
        )
    except Exception as e:
        # Если не удалось отредактировать (сообщение фото или другой тип)
        logger.warning(f"Не удалось отредактировать сообщение: {e}. Отправляем новое.")
        
        # Пытаемся удалить старое сообщение с кнопками
        try:
            await query.message.delete()
        except:
            pass  # Если не удалось удалить - не страшно
        
        # Отправляем новое сообщение
        await query.message.reply_text(
            text,
            reply_markup=get_payment_keyboard(tariff_key),
            parse_mode='HTML'
        )

async def handle_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик оплаты через Тинькофф"""
    query = update.callback_query
    await query.answer()
    
    logger.info(f"💳 Пользователь {query.from_user.id} начал оплату: {query.data}")
    
    if query.data == 'installment_payment':
        # Оплата долями
        admin = Config.ADMIN_USERNAMES[0] if Config.ADMIN_USERNAMES else 'skrepka_service'
        
        text = f"""💳 <b>Оплата долями</b>

Для оформления оплаты частями напишите нашему менеджеру: @{admin.replace('@', '')}"""
        
        keyboard = [
            [InlineKeyboardButton("✍️ Написать менеджеру", 
                                url=f"https://t.me/{admin.replace('@', '')}")],
            [InlineKeyboardButton("◀️ Назад", callback_data='back_to_tariffs')]
        ]
        
        try:
            await query.message.edit_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
        except Exception as e:
            logger.warning(f"Не удалось отредактировать сообщение: {e}. Отправляем новое.")
            # Отправляем новое сообщение
            await query.message.reply_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
        return
    
    elif query.data.startswith('pay_'):
        # ТИНЬКОФФ ОПЛАТА
        tariff_key = query.data.replace('pay_', '')
        tariff_info = Config.TARIFFS.get(tariff_key)
        
        if not tariff_info:
            try:
                await query.message.edit_text("Ошибка: тариф не найден.")
            except:
                await query.message.reply_text("Ошибка: тариф не найден.")
            return
        
        # Получаем промокод
        promocode_text = context.user_data.get('applied_promocode')
        promocode_data = context.user_data.get('promocode_data', {})
        discount = 0
        
        if promocode_text and promocode_data:
            original_price = tariff_info['price']
            
            if promocode_data.get('discount_amount', 0) > 0:
                discount = promocode_data['discount_amount']
            elif promocode_data.get('discount_percent', 0) > 0:
                discount = original_price * (promocode_data['discount_percent'] / 100)
            
            logger.info(f"💰 Применена скидка: {discount/100:.0f} ₽")
        
        # Рассчитываем итоговую цену
        original_price = tariff_info['price']
        final_price = max(100, original_price - discount)  # Минимум 1 рубль
        final_price_rub = final_price / 100
        
        # Генерируем ID заказа
        order_id = f"order_{query.from_user.id}_{int(time.time())}"
        
        # Сохраняем данные платежа ВО ВРЕМЕННОЕ ХРАНИЛИЩЕ
        # Пока не знаем payment_id, сохраняем order_id
        context.user_data['payment_data'] = {
            'tariff': tariff_key,
            'original_price': original_price,
            'discount': discount,
            'final_price': final_price,
            'promocode': promocode_text,
            'promocode_id': promocode_data.get('id'),
            'order_id': order_id,
            'user_id': query.from_user.id
        }
        
        # Создаем платеж в Тинькофф
        description = f"Подписка «Бестужевки» - {tariff_info['label']}"
        
        customer_data = {
            "email": "",
            "phone": ""
        }
        
        result = tbank.create_payment(
            order_id=order_id,
            amount=final_price_rub,
            description=description,
            customer_data=customer_data
        )
        
        if result["success"]:
            payment_url = result["payment_url"]
            payment_id = result["payment_id"]  # Получаем PaymentId из ответа Тинькофф
            order_id_from_response = result["order_id"]
            
            # Теперь обновляем данные в БД с payment_id
            try:
                engine = context.bot_data.get('engine')
                if engine:
                    session = get_session(engine)
                    
                    db_user = session.query(User).filter_by(telegram_id=query.from_user.id).first()
                    if not db_user:
                        db_user = User(
                            telegram_id=query.from_user.id,
                            username=query.from_user.username,
                            first_name=query.from_user.first_name,
                            last_name=query.from_user.last_name,
                            settings={'reminders': True}
                        )
                        session.add(db_user)
                        session.flush()
                    
                    # Создаем запись о платеже с payment_id
                    payment_record = Payment(
                        user_id=db_user.id,
                        amount=final_price,
                        original_amount=original_price,
                        discount=discount,
                        currency='RUB',
                        tariff=tariff_key,
                        promocode=promocode_text,
                        invoice_payload=json.dumps({
                            'order_id': order_id_from_response,
                            'payment_id': payment_id,
                            'user_id': query.from_user.id,
                            'tariff': tariff_key
                        }),
                        status='pending',
                        order_id=order_id_from_response,
                        provider_payment_charge_id=payment_id  # Сохраняем PaymentId
                    )
                    session.add(payment_record)
                    session.commit()
                    
                    # Обновляем временные данные с payment_id
                    context.user_data['payment_data']['payment_id'] = payment_id
                    context.user_data['payment_data']['order_id'] = order_id_from_response
                    
                    logger.info(f"💾 Платеж сохранен в БД: OrderId={order_id_from_response}, PaymentId={payment_id}, сумма={final_price_rub:.0f} руб")
                    
            except Exception as e:
                logger.error(f"Ошибка сохранения платежа в БД: {e}")
                # Продолжаем работу, платеж в Тинькофф создан
            
            # Форматируем текст
            if discount > 0:
                price_text = f"""<b>Исходная цена:</b> {original_price/100:,.0f} ₽
<b>Скидка:</b> {discount/100:,.0f} ₽
<b>Итоговая цена:</b> {final_price_rub:,.0f} ₽"""
            else:
                price_text = f"<b>Сумма к оплате:</b> {final_price_rub:,.0f} ₽"
            
            text = f"""✅ <b>Платеж создан</b>

<b>Тариф:</b> {tariff_info['label']}
{price_text}
           
Для оплаты перейдите по ссылке ниже:

После успешной оплаты нажмите "🔄 Проверить статус" чтобы подтвердить оплату"""
            
            # ВАЖНО: Используем payment_id для проверки статуса, а не order_id
            keyboard = [
                [InlineKeyboardButton("💳 Перейти к оплате", url=payment_url)],
                [InlineKeyboardButton("🔄 Проверить статус", callback_data=f'check_status_{payment_id}')],  # Используем payment_id!
                [InlineKeyboardButton("◀️ Назад к тарифам", callback_data='back_to_tariffs')]
            ]
            
            try:
                await query.message.edit_text(
                    text,
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='HTML'
                )
            except Exception as e:
                logger.warning(f"Не удалось отредактировать сообщение: {e}. Отправляем новое.")
                # Отправляем новое сообщение
                await query.message.reply_text(
                    text,
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='HTML'
                )
            
        else:
            error_msg = result.get('error', 'Неизвестная ошибка')
            logger.error(f"Ошибка создания платежа: {error_msg}")
            
            # Уточненное сообщение об ошибке
            error_text = f"""❌ <b>Ошибка создания платежа</b>

Не удалось создать платеж в Тинькофф.

<b>Ошибка:</b> {error_msg}"""
            
            if result.get('diagnosis'):
                error_text += f"\n\n<b>Рекомендация:</b> {result['diagnosis']}"
            
            error_text += "\n\nПожалуйста, попробуйте снова или свяжитесь с менеджером."
            
            try:
                await query.message.edit_text(
                    error_text,
                    parse_mode='HTML'
                )
            except:
                await query.message.reply_text(
                    error_text,
                    parse_mode='HTML'
                )

async def handle_tinkoff_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик для кнопок Тинькофф"""
    query = update.callback_query
    await query.answer()
    
    # Парсим данные из callback_data: tinkoff_pay_tariff_key
    parts = query.data.split('_')
    if len(parts) >= 3:
        tariff_key = parts[2]
        # Перенаправляем на обычную оплату
        query.data = f'pay_{tariff_key}'
        await handle_payment(update, context)
    else:
        try:
            await query.message.edit_text(
                "❌ Не удалось обработать запрос оплаты",
                parse_mode='HTML'
            )
        except:
            await query.message.reply_text(
                "❌ Не удалось обработать запрос оплаты",
                parse_mode='HTML'
            )

async def check_payment_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Проверка статуса платежа Тинькофф по PaymentId"""
    if not tbank:
        await update.callback_query.answer("Тинькофф оплата временно недоступна", show_alert=True)
        return
    
    query = update.callback_query
    await query.answer()
    
    payment_id = query.data.replace('check_status_', '')  # Теперь это PaymentId!
    logger.info(f"🔄 Проверка статуса платежа по PaymentId: {payment_id}")
    
    # Проверяем статус в Тинькофф по PaymentId
    status_result = tbank.check_payment_status(payment_id)
    
    if not status_result or not status_result.get("success"):
        error_msg = status_result.get('error', 'Неизвестная ошибка') if status_result else 'Не удалось проверить статус'
        error_code = status_result.get('error_code', '') if status_result else ''
        
        error_text = f"""❌ Ошибка проверки статуса: {error_msg}"""
        
        if status_result and status_result.get('diagnosis'):
            error_text += f"\n\n<b>Причина:</b> {status_result['diagnosis']}"
        
        if error_code == "104":
            # Платеж не найден - возможно еще обрабатывается
            error_text += "\n\nПлатеж еще обрабатывается. Попробуйте проверить статус через 1-2 минуты."
        
        try:
            await query.message.edit_text(
                error_text,
                parse_mode='HTML'
            )
        except:
            await query.message.reply_text(
                error_text,
                parse_mode='HTML'
            )
        return
    
    status = status_result["status"]
    status_text = status_result.get("status_text", status)
    amount = status_result.get("amount", 0)
    order_id = status_result.get("order_id", "")
    
    if status in ["CONFIRMED", "AUTHORIZED"]:
        # Платеж успешен
        await process_tinkoff_successful_payment(update, context, payment_id, status_result)
    elif status == "REJECTED":
        text = """❌ Платеж отклонен банком.

Возможные причины:
• Недостаточно средств на карте
• Карта заблокирована для онлайн-платежей
• Превышен лимит операций
• Ошибка при вводе данных

Пожалуйста, попробуйте снова или свяжитесь с менеджером."""
        
        try:
            await query.message.edit_text(text, parse_mode='HTML')
        except:
            await query.message.reply_text(text, parse_mode='HTML')
    elif status in ["CANCELED", "DEADLINE_EXPIRED"]:
        text = f"""❌ Платеж отменен

Статус: {status_text}
Сумма: {amount:.0f} ₽
Order ID: {order_id}

Вы можете создать новый платеж."""
        
        keyboard = [
            [InlineKeyboardButton("💳 Создать новый платеж", callback_data='back_to_tariffs')],
            [InlineKeyboardButton("✍️ Связаться с менеджером", callback_data='contact_manager')]
        ]
        
        try:
            await query.message.edit_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
        except:
            await query.message.reply_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
    elif status == "FORM_SHOWED":
        text = f"""⏳ Ожидание оплаты

Платежная форма открыта у пользователя.
Статус: {status_text}
Сумма: {amount:.0f} ₽

После оплаты статус обновится автоматически."""
        
        keyboard = [
            [InlineKeyboardButton("🔄 Проверить статус еще раз", callback_data=f'check_status_{payment_id}')],
            [InlineKeyboardButton("◀️ Назад", callback_data='back_to_tariffs')]
        ]
        
        try:
            await query.message.edit_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
        except:
            await query.message.reply_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
    else:
        text = f"""⏳ Платеж обрабатывается

Статус: {status_text}
Сумма: {amount:.0f} ₽
Order ID: {order_id}

Проверим статус через несколько минут."""
        
        keyboard = [
            [InlineKeyboardButton("🔄 Проверить статус еще раз", callback_data=f'check_status_{payment_id}')],
            [InlineKeyboardButton("◀️ Назад", callback_data='back_to_tariffs')]
        ]
        
        try:
            await query.message.edit_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
        except:
            await query.message.reply_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )

async def process_tinkoff_successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE, payment_id, status_result):
    """Обработка успешного платежа Тинькофф (доступ сразу с момента оплаты)"""
    query = update.callback_query
    engine = context.bot_data.get('engine')
    
    if not engine:
        logger.error("Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        # Находим платеж в БД по provider_payment_charge_id (PaymentId)
        payment_record = session.query(Payment).filter_by(provider_payment_charge_id=payment_id).first()
        
        if not payment_record:
            # Попробуем найти по order_id из ответа
            order_id = status_result.get("order_id", "")
            if order_id:
                payment_record = session.query(Payment).filter_by(order_id=order_id).first()
        
        if not payment_record:
            logger.error(f"Платеж PaymentId={payment_id} не найден в БД")
            try:
                await query.message.edit_text(
                    "Платеж успешен, но возникла ошибка при обновлении данных. Обратитесь к администратору.",
                    parse_mode='HTML'
                )
            except:
                await query.message.reply_text(
                    "Платеж успешен, но возникла ошибка при обновлении данных. Обратитесь к администратору.",
                    parse_mode='HTML'
                )
            return
        
        # Проверяем, не обработан ли уже этот платеж
        if payment_record.status == 'completed':
            try:
                await query.message.edit_text(
                    "✅ Этот платеж уже был успешно обработан ранее.",
                    parse_mode='HTML'
                )
            except:
                await query.message.reply_text(
                    "✅ Этот платеж уже был успешно обработан ранее.",
                    parse_mode='HTML'
                )
            return
        
        # Обновляем статус платежа
        payment_record.status = 'completed'
        payment_record.completed_at = datetime.now()
        payment_record.provider_payment_charge_id = payment_id
        
        # Увеличиваем счетчик промокода
        promocode_text = payment_record.promocode
        if promocode_text:
            promocode = session.query(Promocode).filter_by(code=promocode_text).first()
            if promocode:
                promocode.used_count += 1
                logger.info(f"📈 Промокод использован: {promocode_text} ({promocode.used_count}/{promocode.max_uses})")
        
        # Получаем пользователя
        db_user = session.query(User).filter_by(id=payment_record.user_id).first()
        
        # Проверяем, есть ли уже активная подписка
        existing_subscription = session.query(Subscription).filter_by(
            user_id=db_user.id, 
            is_active=True
        ).first()
        
        if existing_subscription:
            # Обновляем существующую подписку - продлеваем ее
            tariff_info = Config.TARIFFS.get(payment_record.tariff, {})
            duration_days = tariff_info.get('duration_days', 30)
            
            # Продлеваем существующую подписку
            if existing_subscription.end_date > datetime.now():
                # Если подписка еще активна - добавляем дни к текущей дате окончания
                new_end_date = existing_subscription.end_date + timedelta(days=duration_days)
            else:
                # Если подписка истекла - начинаем с сегодняшней даты
                new_end_date = datetime.now() + timedelta(days=duration_days)
            
            existing_subscription.end_date = new_end_date
            existing_subscription.tariff = payment_record.tariff
            existing_subscription.updated_at = datetime.now()
            
            logger.info(f"📅 Продлена существующая подписка пользователя {db_user.telegram_id} до {new_end_date.strftime('%d.%m.%Y')}")
            
            # Формируем сообщение о продлении
            success_text = f"""🎉 <b>Подписка продлена!</b>

Ваша подписка на тариф «{payment_record.tariff}» успешно продлена.

<b>Доступ продлен до: {new_end_date.strftime('%d.%m.%Y')}</b>

Не удаляй бот - здесь мы будем напоминать о встречах и важных событиях."""
            
        else:
            # Создаем новую подписку с доступом сразу с момента оплаты
            now = datetime.now()
            tariff_info = Config.TARIFFS.get(payment_record.tariff, {})
            duration_days = tariff_info.get('duration_days', 30)
            
            # ДОСТУП СРАЗУ С МОМЕНТА ОПЛАТЫ
            start_date = now
            end_date = now + timedelta(days=duration_days)
            
            subscription = Subscription(
                user_id=db_user.id,
                tariff=payment_record.tariff,
                start_date=start_date,
                end_date=end_date,
                is_active=True,
                join_month=start_date.month,
                join_year=start_date.year,
                created_at=now
            )
            session.add(subscription)
            
            logger.info(f"📅 Создана новая подписка пользователя {db_user.telegram_id} с доступом с {start_date.strftime('%d.%m.%Y')} до {end_date.strftime('%d.%m.%Y')}")
            
            # Формируем сообщение о новой подписке
            success_text = f"""🎉 <b>Ты с нами 🤍</b>

Добро пожаловать в клуб «Бестужевки»!

<b>Ваш доступ к тарифу «{payment_record.tariff}» активирован!</b>
<b>Действует до: {end_date.strftime('%d.%m.%Y')}</b>

Не удаляй бот — здесь мы будем напоминать о встречах и важных событиях."""
        
        # Сохраняем использование промокода
        if payment_record.promocode:
            promo_usage = PromoUsage(
                user_id=db_user.id,
                promocode=payment_record.promocode,
                discount_amount=payment_record.discount,
                payment_id=payment_record.id
            )
            session.add(promo_usage)
        
        session.commit()
        
        # Отправляем финальное сообщение пользователю
        try:
            await query.message.edit_text(
                success_text,
                reply_markup=get_after_payment_keyboard(),
                parse_mode='HTML'
            )
        except:
            await query.message.reply_text(
                success_text,
                reply_markup=get_after_payment_keyboard(),
                parse_mode='HTML'
            )
        
        # Очищаем user_data
        for key in ['payment_data', 'applied_promocode', 'selected_tariff', 'promocode_data']:
            if key in context.user_data:
                del context.user_data[key]
        
        logger.info(f"✅ Успешная оплата обработана: пользователь {db_user.telegram_id}, тариф {payment_record.tariff}, PaymentId={payment_id}")
        
        # Уведомление админам
        if existing_subscription:
            action_text = "ПРОДЛЕНА ПОДПИСКА"
            end_date_info = existing_subscription.end_date.strftime('%d.%m.%Y')
        else:
            action_text = "НОВАЯ ПОДПИСКА"
            end_date_info = end_date.strftime('%d.%m.%Y')
        
        admin_message = f"""💸 {action_text} - Успешный платеж Тинькофф

👤 Пользователь: @{db_user.username or 'без username'} ({db_user.first_name or ''})
💰 Сумма: {payment_record.amount/100:.0f} ₽
📋 Тариф: {payment_record.tariff}
🎫 Промокод: {payment_record.promocode or 'нет'}
🆔 Order ID: {payment_record.order_id}
🆔 Payment ID: {payment_id}
📅 Доступ ДО: {end_date_info}
✅ Доступ активирован СРАЗУ после оплаты"""
        
        for admin_id in Config.ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=admin_message
                )
            except Exception as e:
                logger.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
        
    except Exception as e:
        logger.error(f"❌ Ошибка обработки платежа: {e}")
        session.rollback()
        try:
            await query.message.edit_text(
                "Произошла ошибка при обработке платежа. Мы уже работаем над ее устранением.",
                parse_mode='HTML'
            )
        except:
            await query.message.reply_text(
                "Произошла ошибка при обработке платежа. Мы уже работаем над ее устранением.",
                parse_mode='HTML'
            )
    finally:
        session.close()

async def handle_promocode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик кнопок промокодов"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    if query.data == 'enter_promocode':
        text = "🎫 Введите промокод:"
        
        try:
            await query.message.edit_text(
                text,
                reply_markup=get_back_keyboard('tariff_selection')
            )
        except:
            await query.message.reply_text(
                text,
                reply_markup=get_back_keyboard('tariff_selection')
            )
        
        context.user_data['awaiting_promocode'] = True
    
    elif query.data == 'remove_promocode':
        # Удаляем примененный промокод
        if 'applied_promocode' in context.user_data:
            del context.user_data['applied_promocode']
        if 'promocode_data' in context.user_data:
            del context.user_data['promocode_data']
        
        # Возвращаемся к оплате
        tariff = context.user_data.get('selected_tariff')
        if tariff:
            tariff_info = Config.TARIFFS.get(tariff)
            if tariff_info:
                price = tariff_info['price'] / 100
                
                text = f"""<b>Выбран тариф:</b> {tariff_info['label']}
                
<b>Цена:</b> {price:,.0f} ₽
                
Промокод удален."""
                
                try:
                    await query.message.edit_text(
                        text,
                        reply_markup=get_payment_keyboard(tariff),
                        parse_mode='HTML'
                    )
                except:
                    await query.message.reply_text(
                        text,
                        reply_markup=get_payment_keyboard(tariff),
                        parse_mode='HTML'
                    )