from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import get_session, UserMessage, User, AdminReply
from config import Config
import logging
import re

logger = logging.getLogger(__name__)

async def forward_user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Переадресация ЛЮБОГО сообщения пользователя админам с сохранением в БД"""
    
    # Проверяем, что есть сообщение
    if not update.message:
        logger.warning("Нет update.message")
        return
    
    user = update.effective_user
    message = update.message
    
    logger.info(f"📨 FORWARD_USER_MESSAGE вызван для пользователя {user.id}")
    
    # Получаем текст сообщения
    text = message.text.strip() if message.text else ""
    caption = message.caption.strip() if message.caption else ""
    message_text = text or caption
    
    # ========== КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ ==========
    # НЕ проверяем здесь, похоже ли на промокод!
    # Эта логика должна быть ТОЛЬКО в handle_text_message
    
    # Проверяем только явный флаг awaiting_promocode
    if context.user_data.get('awaiting_promocode', False) and user.id not in Config.ADMIN_IDS:
        logger.info(f"🚫 Пользователь {user.id} ожидает промокод, НЕ пересылаем сообщение")
        logger.info(f"  Сообщение: '{message_text}'")
        # НЕ пересылаем - handle_text_message уже обработает это
        return
    
    # УДАЛЕНА проверка "похоже ли на промокод" при выбранном тарифе
    # Вся логика промокодов должна быть в handle_text_message
    # ========== КОНЕЦ ИСПРАВЛЕНИЯ ==========
    
    # Пропускаем сообщения от админов
    if user.id in Config.ADMIN_IDS:
        logger.info(f"Сообщение от админа {user.id}")
        # Но если это ответ админа на наше сообщение - обрабатываем
        if message.reply_to_message:
            await handle_admin_reply(update, context)
            logger.info(f"Админ {user.id} ответил на сообщение, обрабатываем")
        return
    
    # Пропускаем команды
    if message.text and message.text.startswith('/'):
        logger.info(f"Это команда: {message.text}, пропускаем")
        return
    
    logger.info(f"Обработка сообщения от пользователя {user.id}: {message_text or 'медиафайл'}")
    
    # Получаем сессию БД
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        # Ищем пользователя в БД
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if not db_user:
            # Создаем пользователя если не найден
            db_user = User(
                telegram_id=user.id,
                username=user.username,
                first_name=user.first_name,
                last_name=user.last_name,
                settings={
                    'reminders': True,
                    'notifications': True,
                    'timezone': 'Europe/Moscow'
                }
            )
            session.add(db_user)
            session.commit()
            logger.info(f"Создан новый пользователь в БД: {user.id}")
        
        # Сохраняем сообщение в БД
        user_message = UserMessage(
            telegram_id=user.id,
            message_id=message.message_id,
            message_text=message_text,
            message_type=get_message_type(message),
            file_id=get_file_id(message),
            file_caption=message.caption,
            created_at=message.date
        )
        
        session.add(user_message)
        session.commit()
        
        logger.info(f"💾 Сообщение #{user_message.id} от пользователя {user.id} сохранено в БД")
        
        # Формируем информацию о пользователе
        user_info = f"👤 <b>Пользователь:</b> {user.first_name or ''}"
        if user.last_name:
            user_info += f" {user.last_name}"
        if user.username:
            user_info += f" (@{user.username})"
        
        user_info += f"\n🆔 <b>ID:</b> <code>{user.id}</code>"
        user_info += f"\n📅 <b>Время:</b> {message.date.strftime('%d.%m.%Y %H:%M')}"
        user_info += f"\n🔢 <b>Сообщение #{user_message.id}</b>"
        
        # ДОБАВЛЕНО: Информация о контексте (если есть)
        if context.user_data.get('selected_tariff'):
            user_info += f"\n🎯 <b>Контекст:</b> Выбран тариф '{context.user_data.get('selected_tariff')}'"
        
        # ДОБАВЛЕНО: Инструкция для админа
        user_info += f"\n\n💡 <b>Чтобы ответить:</b> Просто ответьте (reply) на это сообщение"
        
        # Формируем полное сообщение
        full_message = f"{user_info}\n\n"
        
        # Добавляем текст сообщения
        if message.text:
            full_message += f"💬 <b>Сообщение:</b>\n{message.text}"
        elif message.caption:
            full_message += f"💬 <b>Подпись к файлу:</b>\n{message.caption}"
        else:
            full_message += "📎 <b>Прислан файл</b>"
        
        # Создаем клавиатуру для ответа
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("📩 Ответить", callback_data=f"reply_msg_{user_message.id}")],
            [InlineKeyboardButton("👁️ Просмотрено", callback_data=f"viewed_msg_{user_message.id}")]
        ])
        
        # Пересылаем всем администраторам
        forwarded_count = 0
        last_forwarded_id = None
        
        for admin_id in Config.ADMIN_IDS:
            try:
                # Пересылаем оригинальное сообщение или отправляем текст
                if message.photo or message.document or message.audio or message.video or message.sticker:
                    # Для медиа - пересылаем оригинал
                    forwarded = await message.forward(chat_id=admin_id)
                    # Отправляем информацию отдельным сообщением
                    info_msg = await context.bot.send_message(
                        chat_id=admin_id,
                        text=full_message,
                        parse_mode='HTML',
                        reply_markup=keyboard
                    )
                    last_forwarded_id = info_msg.message_id
                else:
                    # Для текста - отправляем как новое сообщение
                    forwarded = await context.bot.send_message(
                        chat_id=admin_id,
                        text=full_message,
                        parse_mode='HTML',
                        reply_markup=keyboard
                    )
                    last_forwarded_id = forwarded.message_id
                
                forwarded_count += 1
                logger.info(f"Сообщение #{user_message.id} от {user.id} переадресовано админу {admin_id}")
                
            except Exception as e:
                logger.error(f"Не удалось отправить сообщение админу {admin_id}: {e}")
        
        # Обновляем запись в БД
        if forwarded_count > 0:
            user_message.forwarded_to_admins = True
            user_message.forwarded_message_id = last_forwarded_id
            session.commit()
            
            # Подтверждаем пользователю
            await update.message.reply_text(
                "✅ Ваше сообщение отправлено менеджеру. Мы ответим вам в ближайшее время.",
                reply_markup=None
            )
            logger.info(f"✅ Сообщение #{user_message.id} успешно переадресовано {forwarded_count} админам")
        else:
            await update.message.reply_text(
                "❌ В данный момент менеджеры недоступны. Пожалуйста, попробуйте позже.",
                reply_markup=None
            )
            logger.warning(f"❌ Сообщение #{user_message.id} не было переадресовано ни одному админу")
            
    except Exception as e:
        logger.error(f"Ошибка при обработке сообщения: {e}", exc_info=True)
        session.rollback()
    finally:
        session.close()

async def handle_admin_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик когда админ отвечает (reply) на пересланное сообщение"""
    if not update.message or not update.message.reply_to_message:
        return
    
    user = update.effective_user
    message = update.message
    reply_to = update.message.reply_to_message
    
    # Проверяем что это админ
    if user.id not in Config.ADMIN_IDS:
        return
    
    logger.info(f"📤 Админ {user.id} отвечает на сообщение")
    
    # Ищем в тексте ID сообщения (Сообщение #2)
    match = re.search(r'Сообщение #(\d+)', reply_to.text or '')
    if not match:
        logger.warning(f"Не найден ID сообщения в тексте: {reply_to.text[:100]}")
        # Альтернативный поиск: может быть в другом формате
        match = re.search(r'Сообщение # (\d+)', reply_to.text or '')
        if not match:
            logger.warning(f"Альтернативный поиск тоже не нашел ID")
            return
    
    message_id = int(match.group(1))
    reply_text = message.text
    
    if not reply_text:
        await message.reply_text("❌ Сообщение не может быть пустым")
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        # Находим сообщение в БД
        user_message = session.query(UserMessage).filter_by(id=message_id).first()
        if not user_message:
            logger.error(f"Сообщение #{message_id} не найдено в БД")
            await message.reply_text("❌ Сообщение не найдено в базе данных")
            return
        
        logger.info(f"Найдено сообщение #{message_id} от пользователя {user_message.telegram_id}")
        
        # Сохраняем ответ в БД
        admin_reply = AdminReply(
            message_id=message_id,
            admin_id=user.id,
            reply_text=reply_text
        )
        session.add(admin_reply)
        
        # Обновляем исходное сообщение
        user_message.admin_replied = True
        user_message.admin_id = user.id
        user_message.admin_reply = reply_text
        user_message.replied_at = message.date
        
        # Отправляем ответ пользователю
        try:
            logger.info(f"📨 Пытаемся отправить ответ пользователю {user_message.telegram_id}")
            
            # Форматируем ответ
            formatted_reply = f"📩 <b>Ответ от менеджера:</b>\n\n{reply_text}"
            
            await context.bot.send_message(
                chat_id=user_message.telegram_id,
                text=formatted_reply,
                parse_mode='HTML'
            )
            
            logger.info(f"✅ Ответ отправлен пользователю {user_message.telegram_id}")
            
            admin_reply.sent = True
            admin_reply.sent_at = message.date
            session.commit()
            
            # Подтверждаем админу
            await message.reply_text(
                f"✅ Ответ отправлен пользователю #{user_message.telegram_id}",
                reply_to_message_id=message.message_id
            )
            
            # Обновляем кнопку в исходном сообщении админа
            if user_message.forwarded_message_id:
                try:
                    chat_id = reply_to.chat_id if hasattr(reply_to, 'chat_id') else reply_to.chat.id
                    await context.bot.edit_message_reply_markup(
                        chat_id=chat_id,
                        message_id=user_message.forwarded_message_id,
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("✅ Отвечено", callback_data=f"replied_msg_{message_id}")]
                        ])
                    )
                    logger.info(f"🔄 Кнопка обновлена в сообщении {user_message.forwarded_message_id}")
                except:
                    pass  # Не критично если не удалось обновить кнопку
                
        except Exception as e:
            logger.error(f"❌ Не удалось отправить ответ пользователю {user_message.telegram_id}: {e}", exc_info=True)
            await message.reply_text(
                f"❌ Не удалось отправить ответ пользователю #{user_message.telegram_id}. Возможно:\n"
                f"• Он заблокировал бота\n"
                f"• Он не начинал диалог с ботом\n"
                f"• Ошибка Telegram API"
            )
        
        session.commit()
        
    except Exception as e:
        logger.error(f"Ошибка при обработке ответа админа: {e}", exc_info=True)
        session.rollback()
        await message.reply_text("❌ Произошла ошибка при обработке ответа")
    finally:
        session.close()

def get_message_type(message) -> str:
    """Определяет тип сообщения"""
    if message.text:
        return 'text'
    elif message.photo:
        return 'photo'
    elif message.document:
        return 'document'
    elif message.audio:
        return 'audio'
    elif message.video:
        return 'video'
    elif message.voice:
        return 'voice'
    elif message.sticker:
        return 'sticker'
    elif message.contact:
        return 'contact'
    elif message.location:
        return 'location'
    else:
        return 'unknown'

def get_file_id(message):
    """Получает file_id медиафайла"""
    if message.photo:
        return message.photo[-1].file_id
    elif message.document:
        return message.document.file_id
    elif message.audio:
        return message.audio.file_id
    elif message.video:
        return message.video.file_id
    elif message.voice:
        return message.voice.file_id
    elif message.sticker:
        return message.sticker.file_id
    else:
        return None