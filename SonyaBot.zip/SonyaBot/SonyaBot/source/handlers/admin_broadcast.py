from telegram import Update
from telegram.ext import ContextTypes, CommandHandler
from database import get_session, User, Subscription
from config import Config
import logging

logger = logging.getLogger(__name__)

async def broadcast_all(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Рассылка всем пользователям"""
    if update.effective_user.id not in Config.ADMIN_IDS:
        return
    
    if not context.args:
        await update.message.reply_text("❌ Использование: /broadcast_all текст сообщения")
        return
    
    message = ' '.join(context.args)
    engine = context.bot_data.get('engine')
    
    if not engine:
        await update.message.reply_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        users = session.query(User).all()
        sent_count = 0
        failed_count = 0
        
        await update.message.reply_text(f"📤 Начинаю рассылку для {len(users)} пользователей...")
        
        for user in users:
            try:
                await context.bot.send_message(
                    chat_id=user.telegram_id,
                    text=f"📢 <b>Сообщение от клуба «Бестужевки»:</b>\n\n{message}",
                    parse_mode='HTML'
                )
                sent_count += 1
            except Exception as e:
                logger.error(f"Не удалось отправить сообщение пользователю {user.id}: {e}")
                failed_count += 1
        
        await update.message.reply_text(
            f"✅ Рассылка завершена!\n\n"
            f"📨 Отправлено: {sent_count}\n"
            f"❌ Не отправлено: {failed_count}"
        )
        
    except Exception as e:
        logger.error(f"Ошибка при рассылке: {e}")
        await update.message.reply_text(f"❌ Ошибка при рассылке: {e}")
    finally:
        session.close()

async def broadcast_subscribed(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Рассылка только подписанным пользователям"""
    if update.effective_user.id not in Config.ADMIN_IDS:
        return
    
    if not context.args:
        await update.message.reply_text("❌ Использование: /broadcast_subscribed текст сообщения")
        return
    
    message = ' '.join(context.args)
    engine = context.bot_data.get('engine')
    
    if not engine:
        await update.message.reply_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        # Получаем пользователей с активными подписками
        subscribed_users = session.query(User).join(Subscription).filter(
            Subscription.is_active == True
        ).distinct().all()
        
        sent_count = 0
        failed_count = 0
        
        await update.message.reply_text(f"📤 Начинаю рассылку для {len(subscribed_users)} подписанных пользователей...")
        
        for user in subscribed_users:
            try:
                await context.bot.send_message(
                    chat_id=user.telegram_id,
                    text=f"📢 <b>Сообщение от клуба «Бестужевки»:</b>\n\n{message}",
                    parse_mode='HTML'
                )
                sent_count += 1
            except Exception as e:
                logger.error(f"Не удалось отправить сообщение подписанному пользователю {user.id}: {e}")
                failed_count += 1
        
        await update.message.reply_text(
            f"✅ Рассылка подписанным завершена!\n\n"
            f"📨 Отправлено: {sent_count}\n"
            f"❌ Не отправлено: {failed_count}"
        )
        
    except Exception as e:
        logger.error(f"Ошибка при рассылке подписанным: {e}")
        await update.message.reply_text(f"❌ Ошибка при рассылке: {e}")
    finally:
        session.close()

async def broadcast_active(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Рассылка только активным пользователям"""
    if update.effective_user.id not in Config.ADMIN_IDS:
        return
    
    if not context.args:
        await update.message.reply_text("❌ Использование: /broadcast_active текст сообщения")
        return
    
    message = ' '.join(context.args)
    engine = context.bot_data.get('engine')
    
    if not engine:
        await update.message.reply_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        # Получаем активных пользователей (кто согласился с политикой)
        active_users = session.query(User).filter(
            User.agreed_to_policy == True,
            User.is_active == True
        ).all()
        
        sent_count = 0
        failed_count = 0
        
        await update.message.reply_text(f"📤 Начинаю рассылку для {len(active_users)} активных пользователей...")
        
        for user in active_users:
            try:
                await context.bot.send_message(
                    chat_id=user.telegram_id,
                    text=f"📢 <b>Сообщение от клуба «Бестужевки»:</b>\n\n{message}",
                    parse_mode='HTML'
                )
                sent_count += 1
            except Exception as e:
                logger.error(f"Не удалось отправить сообщение активному пользователю {user.id}: {e}")
                failed_count += 1
        
        await update.message.reply_text(
            f"✅ Рассылка активным пользователям завершена!\n\n"
            f"📨 Отправлено: {sent_count}\n"
            f"❌ Не отправлено: {failed_count}"
        )
        
    except Exception as e:
        logger.error(f"Ошибка при рассылке активным: {e}")
        await update.message.reply_text(f"❌ Ошибка при рассылке: {e}")
    finally:
        session.close()

async def broadcast_ids(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Рассылка по конкретным ID пользователей"""
    if update.effective_user.id not in Config.ADMIN_IDS:
        return
    
    if len(context.args) < 2:
        await update.message.reply_text("❌ Использование: /broadcast_ids 123,456,789 текст сообщения")
        return
    
    # Первый аргумент - список ID через запятую
    ids_str = context.args[0]
    message = ' '.join(context.args[1:])
    
    try:
        # Парсим ID
        user_ids = [int(id_str.strip()) for id_str in ids_str.split(',')]
    except ValueError:
        await update.message.reply_text("❌ Неверный формат ID. Используйте: 123,456,789")
        return
    
    sent_count = 0
    failed_count = 0
    
    await update.message.reply_text(f"📤 Начинаю рассылку для {len(user_ids)} пользователей...")
    
    for user_id in user_ids:
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=f"📢 <b>Сообщение от клуба «Бестужевки»:</b>\n\n{message}",
                parse_mode='HTML'
            )
            sent_count += 1
        except Exception as e:
            logger.error(f"Не удалось отправить сообщение пользователю {user_id}: {e}")
            failed_count += 1
    
    await update.message.reply_text(
        f"✅ Рассылка по ID завершена!\n\n"
        f"📨 Отправлено: {sent_count}\n"
        f"❌ Не отправлено: {failed_count}"
    )