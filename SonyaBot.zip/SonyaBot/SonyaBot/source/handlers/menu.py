# handlers/menu.py
from telegram import Update
from telegram.ext import ContextTypes
from keyboards import (
    get_main_menu_keyboard, get_tariffs_keyboard, get_faq_keyboard, 
    get_back_keyboard, get_after_payment_keyboard, 
    get_speakers_keyboard, get_speaker_detail_keyboard,
    get_programs_keyboard, get_back_to_programs_keyboard
)
from config import Config
import logging

logger = logging.getLogger(__name__)

async def handle_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик главного меню"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'about_club':
        text = """<b>«Бестужевки» — это пространство, вдохновлённое традицией Бестужевских курсов — первой системой высшего образования для женщин в России, переосмысленной для современности.</b>

<b>В клубе:</b>

<b>🎓 Вдумчивые лекции и живые встречи.</b>
1 лекция (1-1,5ч) в неделю в Zoom по одному из предметов. Можно смотреть в записи.

<b>🤝 Сообщество единомышленниц</b>
закрытый канал в Telegram

<b>💝 Подарки от «Бестужевки»</b>
для годового тарифа: печатная рабочая тетрадь А4 и наклейки (отправим СДЭК/почтой)"""
        
        try:
            # Фото для раздела "О клубе"
            photo_url = "https://s6.iimage.su/s/17/ufX3DQhxvm7ETZqJ5PlnMQpc9gzgGSpITQrOPpvM.jpg"
            
            # Отправляем фото с текстом как подписью
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,
                parse_mode='HTML',
                reply_markup=get_back_keyboard('main')
            )
            
        except Exception as e:
            logger.error(f"Ошибка отправки фото: {e}")
            # Если фото не загрузится, отправляем текст без фото
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_back_keyboard('main')
            )
    
    elif query.data == 'format_schedule':
        # Безопасная обработка URL
        program_url = Config.PROGRAM_URL
        if not program_url or program_url == 'https://docs.google.com/...':
            program_url = "Ссылка на программу будет доступна после запуска"
        
        text = f"""<b>Как устроен клуб «Бестужевки»:</b>

<b>1 лекция или встреча в неделю (Zoom)</b>
длительность: 60–90 минут

А также вы получите:
- доступ к записям встреч
- закрытое сообщество для обсуждений
- дополнительные материалы: тексты, рекомендации, списки книг и фильмов.
- книжный клуб по русской художественной литературе (офлайн, г.Москва)
- офлайн встречи в Москве и Санкт-Петербурге (знакомство с резидентами, лекция, поход в музей или на выставку)"""
        
        # Всегда отправляем новое сообщение для разделов с фото
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=text,
            reply_markup=get_back_keyboard('main'),
            parse_mode='HTML'
        )
    
    elif query.data == 'tariffs':
        text = """<b>Стоимость участия:</b>

🎯 <b>1 месяц - 5000₽ (4 лекции) </b>

🎯 <b>12 месяцев - 40000₽ (48 лекций, рабочая тетрадь по истории с наклейками)</b>

Годовой формат - самый выгодный формат участия.
Также в него входят бонусы: рабочая тетрадь и наклейки

<b>Во все тарифы входит:</b>

• еженедельные лекции и встречи в Zoom
• доступ к записям
• закрытое сообщество клуба
• дополнительные материалы

Оплатить долями можно на любом тарифе. Выбери формат участия - и добро пожаловать в «Бестужевки»."""
        
        try:
            # Фото для раздела "Тарифы" - ЗАМЕНИТЕ НА СВОЮ ССЫЛКУ!
            photo_url = "https://s6.iimage.su/s/18/uy50kyBxamdE5vkO27JAaQDvq4iCXSFZFTO2eiAZ.jpg"  # ← ЗАМЕНИТЕ НА СВОЮ ССЫЛКУ
            
            # Отправляем фото с текстом как подписью и кнопками выбора тарифа
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,
                parse_mode='HTML',
                reply_markup=get_tariffs_keyboard()
            )
            
        except Exception as e:
            logger.error(f"Ошибка отправки фото для тарифов: {e}")
            # Если фото не загрузится, отправляем только текст
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_tariffs_keyboard()
            )
    
    elif query.data == 'speakers':
        text = """👨‍🏫 <b>Наши спикеры</b>

Знакомьтесь с нашими экспертами — профессионалами в своих областях, которые будут делиться знаниями в клубе «Бестужевки».

Выберите преподавателя, чтобы узнать больше:"""

        try:
            # Фото для раздела "Наши спикеры"
            photo_url = "https://allwebs.ru/images/2026/01/16/18ba86f40e87c427408154db5c8e04c0.jpg"
            
            # Отправляем ОДНО сообщение: фото + текст (caption) + кнопки
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,  # Текст идет как подпись к фото
                parse_mode='HTML',
                reply_markup=get_speakers_keyboard()
            )
            
        except Exception as e:
            logger.error(f"Ошибка отправки фото: {e}")
            # Если фото не загрузится, отправляем только текст с кнопками
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_speakers_keyboard()
            )
    
    elif query.data == 'programm':
        text = """📚 <b>Программы курсов</b>

Выберите программу, чтобы увидеть детальную информацию и план занятий:"""

        # Всегда отправляем новое сообщение
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=text,
            reply_markup=get_programs_keyboard(),
            parse_mode='HTML'
        )
    

    elif query.data == 'faq':
        text = """❓ <b>Часто задаваемые вопросы</b>

Выберите интересующий вас вопрос:"""
        
        # Всегда отправляем новое сообщение
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=text,
            reply_markup=get_faq_keyboard(),
            parse_mode='HTML'
        )
    
    elif query.data == 'contact_manager':
        # Получаем первого администратора
        admin = Config.ADMIN_USERNAMES[0] if Config.ADMIN_USERNAMES else '@skrepka_service'
        
        # Очищаем @ если он уже есть в начале
        if admin.startswith('@'):
            admin_mention = admin
        else:
            admin_mention = f'@{admin}'
        
        text = f"""✍️ <b>Связь с менеджером</b>

Вы можете написать нашему менеджеру: {admin_mention}

Или задайте свой вопрос прямо здесь, и мы передадим его менеджеру."""
        
        try:
            # Фото для раздела "написать менеджеру"
            photo_url = "https://s6.iimage.su/s/17/uPtHeMRx2hKC14TCDcf6Id6rBB6r41KOXOsi6NfF.jpg"
            
            # Отправляем фото с текстом как подписью
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,
                parse_mode='HTML',
                reply_markup=get_back_keyboard('main')
            )
            
        except Exception as e:
            logger.error(f"Ошибка отправки фото: {e}")
            # Если фото не загрузится, отправляем текст без фото
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_back_keyboard('main')
            )

async def handle_back_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик кнопки Назад"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'back_to_main':
        text = """<b>Главное меню</b>

Выберите раздел:"""
        
        # Всегда отправляем новое сообщение, не пытаемся редактировать
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=text,
            reply_markup=get_main_menu_keyboard(),
            parse_mode='HTML'
        )
    
    elif query.data == 'back_to_tariffs':
        text = """<b>Тарифы</b>

Выберите тариф:"""
        
        # Пытаемся отправить фото с текстом
        try:
            # Фото для раздела "Тарифы" - та же ссылка
            photo_url = "https://example.com/path/to/your/tariffs-photo.jpg"  # ← ТА ЖЕ ССЫЛКА
            
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,
                parse_mode='HTML',
                reply_markup=get_tariffs_keyboard()
            )
        except Exception as e:
            logger.error(f"Ошибка отправки фото: {e}")
            # Если фото не загрузится, отправляем текст без фото
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_tariffs_keyboard()
            )
    
    elif query.data == 'back_to_speakers':
        text = """👨‍🏫 <b>Наши спикеры</b>

Выберите преподавателя, чтобы узнать больше:"""
        
        # Пытаемся отправить фото
        try:
            photo_url = "https://allwebs.ru/images/2026/01/16/18ba86f40e87c427408154db5c8e04c0.jpg"
            
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,
                parse_mode='HTML',
                reply_markup=get_speakers_keyboard()
            )
        except Exception as e:
            logger.error(f"Ошибка отправки фото: {e}")
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_speakers_keyboard()
            )
    
    elif query.data == 'back_to_faq':
        text = """❓ <b>Часто задаваемые вопросы</b>

Выберите интересующий вас вопрос:"""
        
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=text,
            reply_markup=get_faq_keyboard(),
            parse_mode='HTML'
        )

async def handle_speaker_detail(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик детальной информации о спикере"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'speaker_art_history':
        text = """🖼️ <b>Спикер по истории искусств</b>
<code>Чуворкина Ольга</code>

🎓 •Историк искусства
•Академический директор лектория Синхронизация

•Окончила РГГУ (по специальности историк искусства), магистратуру Университета Париж-IV Сорбонна (l'Université Sorbonne-Paris-IV, UFR Histoire de l'art et archéologie);
•Куратор выставок;
•Лектор;
•Член Ассоциации Искусствоведов.

•На протяжении 5 лет работала методистом и автором образовательных проектов и авторских курсов в РГГУ;
•Вела экскурсии в Третьяковской галерее (ГТГ) и Пушкинском музее (ГМИИ). 

•Создатель авторских лекций и мастер-классов по искусству, сторителлингу и ораторскому 

✨ <i>Ольга откроет для вас мир искусства через призму истории и поможет понять язык художественных образов</i>"""
        
        try:
            # Фото  (замените ссылку)
            photo_url = "https://ltdfoto.ru/images/2026/01/16/9c6db19a-37bc-47dd-99ee-0691afc30d71.jpg"
            
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,
                parse_mode='HTML',
                reply_markup=get_speaker_detail_keyboard()
            )
                
        except Exception as e:
            logger.error(f"Ошибка отправки фото: {e}")
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_speaker_detail_keyboard()
            )

    elif query.data == 'speaker_art_history2':
        text = """🖼️ <b>Спикер по истории искусств</b>
<code>Мария Мороз</code>


🎓 Магистр Болонского университета по направлению «Современные практики и кураторство»
• Соавтор книги «Портрет Ватрушки. Детям об импрессионизме», 2024. 
• Работала редактором в Третьяковкой галерее, специалистом выставочных проектов в Музее русского импрессионизма, арт-менеджером Таус Махачевой, научным сотрудником в Московском музее современного искусства. 
• Автор подкаста «Что ты творишь?». С 2015 года читает лекции для проекта «Синхронизация», с 2018 года для Музея русского импрессионизма
• Ведет канал про современное искусство в тг «Что ты творишь?»

🖼️ <i>Мария откроет для вас мир искусства через призму истории и поможет понять язык художественных образов</i>"""
        
        try:
            # Фото Марии (замените ссылку)
            photo_url = "https://ltdfoto.ru/images/2026/01/16/b0529b99-0458-4410-8065-33046857b9b7.jpg"
            
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,
                parse_mode='HTML',
                reply_markup=get_speaker_detail_keyboard()
            )
                
        except Exception as e:
            logger.error(f"Ошибка отправки фото: {e}")
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_speaker_detail_keyboard()
            )
    

    elif query.data == 'speaker_philosophy_entrepreneurship':
        text = """🚀 <b>Спикер по философии русского предпринимательства</b>
<code>Коротыч Денис Дмитриевич</code>

🎓 <b>Образование:</b>
• Выпускник аспирантуры МГУ, историк

💼 <b>Профессиональный опыт:</b>
• Музейный проектировщик
• Разработчик социально-гуманитарных образовательных практик
• Постоянный спикер «Всероссийского форума технологического предпринимательства»
• Автор научных статей по истории российского предпринимательства
• Создатель экскурсионных маршрутов по Москве

📚 <i>Денис исследует историю российского бизнеса через призму философии и культурного контекста</i>"""
        
        try:
            # Фото Дениса Коротыча (замените ссылку)
            photo_url = "https://i.postimg.cc/jjvgCKpZ/4fdfdc25-60bd-4bde-8659-a3a9ae98c752.jpg"
            
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,
                parse_mode='HTML',
                reply_markup=get_speaker_detail_keyboard()
            )
                
        except Exception as e:
            logger.error(f"Ошибка отправки фото Дениса Коротыча: {e}")
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_speaker_detail_keyboard()
            )
    
    elif query.data == 'speaker_etiquette':
        text = """👑 <b>Спикер по этикету</b>
<code>Екатерина Сартакова</code>

🎓 <b>Профессиональная квалификация:</b>
• Специалист по светскому и деловому этикету с опытом работы с 2013 года
• Член Национальной ассоциации специалистов по протоколу при президенте РФ
• Исследователь культуры

💼 <b>Медийная деятельность:</b>
• Эксперт передачи «Вежливые люди» на радио «Маяк»

✨ <i>Екатерина научит искусству общения, делового протокола и светских манер в современном мире</i>"""
        
        try:
            # Фото Екатерины Сартаковой (замените ссылку)
            photo_url = "https://i.postimg.cc/43wLnZDw/7142be48-ca69-4dcd-a7ee-8947ad615410.jpg"
            
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,
                parse_mode='HTML',
                reply_markup=get_speaker_detail_keyboard()
            )
                
        except Exception as e:
            logger.error(f"Ошибка отправки фото Екатерины Сартаковой: {e}")
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_speaker_detail_keyboard()
            )
    
    elif query.data == 'speaker_history':
        text = """🏛️ <b>Спикер по истории</b>
<code>Мария Емельяненкова</code>

🎓 <b>Образование:</b>
• Выпускница Австрийской высшей школы этикета

💼 <b>Профессиональный опыт:</b>
• Индивидуальный экскурсовод по Санкт-Петербургу
• Лектор по истории России
• Ведущая интеллектуальных игр
• Член Общественного совета по вопросам семьи и детства при администрации Центрального района Санкт-Петербурга

🏆 <b>Награды и достижения:</b>
• Признанный эксперт по истории Санкт-Петербурга

✨ <i>Мария оживляет историю через увлекательные рассказы, экскурсии и интеллектуальные игры</i>"""
        
        try:
            # Фото Марии Емельяненкова (замените ссылку)
            photo_url = "https://i.postimg.cc/8CwKsD2Z/dab98f66-ac72-4bdd-8a08-3dbfb306e67c.jpg"
            
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=text,
                parse_mode='HTML',
                reply_markup=get_speaker_detail_keyboard()
            )
                
        except Exception as e:
            logger.error(f"Ошибка отправки фото Марии Емельяненкова: {e}")
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_speaker_detail_keyboard()
            )

async def handle_after_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик действий после оплаты"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'add_to_calendar':
        text = """📅 <b>Добавить в календарь</b>

Ссылка для добавления в календарь будет отправлена за день до встречи."""
        
        await query.message.reply_text(
            text=text,
            parse_mode='HTML'
        )
    
    elif query.data == 'materials':
        text = """📚 <b>Материалы</b>

Доступ к материалам откроется после начала действия вашей подписки (с 1 числа месяца).

Все материалы будут доступны в закрытом чате клуба."""
        
        await query.message.reply_text(
            text=text,
            parse_mode='HTML'
        )

# ========== ОБРАБОТЧИК ПРОГРАММ ==========

async def handle_program_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик выбора программы - ФОТО ПО ССЫЛКАМ"""
    query = update.callback_query
    await query.answer()
    
    # Словарь с программами: название, описание и ссылка на фото
    programs = {
        'program_philosophy': {
            'title': '🏛️ Философия доревалюционного предпринимательства',
            'text': """<b>🏛️ Программа: Философия доревалюционного предпринимательства</b>

<i>Ведущий: Денис Коротыч</i>

📅 <b>Длительность:</b> 12 занятий
⏰ <b>Формат:</b> Онлайн-лекции в Zoom + практические задания

📋 <b>Программа курса:</b>

1. Стартапы
2. Воспитание и образование в купеческих семьях
3. Маркетинг и реклама дореволюционных предпринимателей
4. Меценаты искусства
5. «Богатство обязывает» история благотворителей
6. Ювелирное дело в ХІХ в.: мастера и судьбы
7. Сладкая история: кондитеры и чаеторговцы
8. Купец всему голова? История московского самоуправления
9. История книгоиздательства и книготорговли
10. Секреты эффективности и жизненная философия
11. Социальная политика и управление персоналом
12. «Градус успеха»
алкогольные империи и ресторанный бизнес до 1917 года

🎯 <b>Что получите:</b>
• Понимание исторических корней российского бизнеса
• Практические инструменты для современного предпринимательства
• Уникальные кейсы из истории русского бизнеса""",
            'photo_url': 'https://s6.iimage.su/s/17/uogx3URxNyzPHOCh3EPMZBuBzmyTC7rT9zu9ezJN.jpg'
        },
        'program_etiquette': {
            'title': '👑 Современный этикет',
            'text': """<b>👑 Программа: Современный этикет</b>

<i>Ведущая: Екатерина Сартакова</i>

📅 <b>Длительность:</b> 12 занятий
⏰ <b>Формат:</b> Онлайн-встречи + практикумы

📋 <b>Программа курса:</b>

1. Речевой этикет: культура коммуникации.
2. Small talk: светская беседа когда,
как, зачем.
3. Цифровой этикет: культура онлайн
коммуникации.
4. Пасхальные беседы.
5. Столовый этикет. Современные основы
застольных манер.
6. Столовый этикет. Сервировка стола:
ее виды, прочтение.
7. Внешний вид: светские коды.
8. Традиции русского чаепития.
9. Внешний вид: деловые коды.
10. Японская культура застолья.
11. Этикет взаимодействия между мужчиной
и женщиной.
12. Новогодние беседы

🎯 <b>Что получите:</b>
• Уверенность в любых социальных ситуациях
• Навыки делового общения
• Умение произвести правильное впечатление""",
            'photo_url': 'https://s6.iimage.su/s/17/uGt6qPPx3qouWbohJblkzOIP7gCYfFYWzmaiWFBz.jpg'
        },
        'program_art': {
            'title': '🖼️ История русского искусства',
            'text': """<b>🖼️ Программа: История русского искусства</b>

<i>Ведущие: Ольга Чуворкина и Мария Мороз</i>

📅 <b>Длительность:</b> 12 занятий
⏰ <b>Формат:</b> Лекции в Zoom + виртуальные экскурсии

📋 <b>Программа курса:</b>

1. Древнерусская живопись
2. Живопись XVII - начала XIX вв:
от парсуны до романтического портрета
3. Бунт Передвижников
4. Модерн в живописи
5. Авангард
6. От соцреализма до активизма
7. Тренды российского искусства последние 30 лет
8. Наталья Гончарова и Амазонки авангарда
9. Марк Шагал
10. Малевич и В. Кандинский
11. Эрик Булатов и концептуальное искусство
12. Практикум

🎯 <b>Что получите:</b>
• Системные знания об истории русского искусства
• Умение анализировать произведения искусства
• Понимание культурного контекста""",
            'photo_url': 'https://s6.iimage.su/s/17/uw4yuk2xYYCBWGZzCp7m0BJU5UhLG1zvIBhCJabK.jpg'
        },
        'program_history': {
            'title': '🇷🇺 История России',
            'text': """<b>🇷🇺 Программа: История России</b>

<i>Ведущая: Мария Емельяненкова</i>

📅 <b>Длительность:</b> 15 занятий
⏰ <b>Формат:</b> Лекции + интерактивные дискуссии

📋 <b>Программа курса:</b>

1. Истоки: Тайны древа славян. Кто мы и откуда?
2. Распад Киева: Когда брат пошел на брата.
3. Татаро-монгольское Иго: Цена выживания и уроки сопротивления.
4. Феномен Москвы: Как небольшой город стал Третьим Римом.
5. Психопортрет тирана: Что сломалось в Иване Грозном?
6. Игра престолов по-русски: Самозванцы, бояре, анархия.
7. Проект "Романовы". Народное ополчение и рождение новой династии.
8. Наследники Смуты: Как Михаил и Алексей Романовы собирали Россию заново.
9. Борьба за трон: Заговорщики у власти.
10. Эпоха фаворитов: Тайные интриги дворцовых переворотов.
И многое другое!""",
            'photo_url': 'https://s6.iimage.su/s/17/uelDWRJxHGGizb57msz4Rs7i7fEhlTDhR6B7oTz3.jpg'
        }
    }
    
    program_id = query.data
    program_info = programs.get(program_id)
    
    if not program_info:
        # Если нажата кнопка "Назад к программам" из фотографии
        if program_id == 'programm':
            text = """📚 <b>Программы курсов</b>

Выберите программу, чтобы увидеть детальную информацию и план занятий:"""
            
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=text,
                parse_mode='HTML',
                reply_markup=get_programs_keyboard()
            )
            return
            
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text="Программа не найдена.",
            parse_mode='HTML',
            reply_markup=get_back_to_programs_keyboard()
        )
        return
    
    try:
        # Проверяем длину текста - лимит Telegram 1024 символа для подписи к фото
        caption_text = program_info['text']
        if len(caption_text) > 1024:
            # Если текст слишком длинный, сокращаем его
            logger.warning(f"Текст программы {program_id} слишком длинный ({len(caption_text)} символов). Сокращаем.")
            # Берем первую часть текста до 1020 символов
            caption_text = caption_text[:1020] + "..."
        
        # Отправляем фото по ссылке с текстом как подписью и кнопками
        await context.bot.send_photo(
            chat_id=query.message.chat_id,
            photo=program_info['photo_url'],
            caption=caption_text,
            parse_mode='HTML',
            reply_markup=get_back_to_programs_keyboard()
        )
            
    except Exception as e:
        logger.error(f"Ошибка отправки фото программы: {e}")
        # Если фото не загрузится, отправляем только текст
        # Также проверяем длину текста для обычного сообщения
        text = program_info['text']
        if len(text) > 4096:  # Лимит для обычного сообщения
            text = text[:4090] + "..."
        
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=text,
            parse_mode='HTML',
            reply_markup=get_back_to_programs_keyboard()
        )
