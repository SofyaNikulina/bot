# handlers/__init__.py - ПОЛНОСТЬЮ ИСПРАВЛЕННЫЙ
from .start import start_command, handle_privacy_policy, handle_contact
from .menu import handle_main_menu, handle_back_button, handle_after_payment, handle_speaker_detail, handle_program_selection
from .payment import (
    handle_tariff_selection, 
    handle_payment, 
    handle_promocode,
    handle_tinkoff_payment, 
    check_payment_status
)
from .faq import handle_faq
from .admin import admin_command, handle_admin
from .utils import handle_text_message, help_command, handle_unknown_command
from .messages import forward_user_message
from .admin_commands import admin_messages
from .admin_reply import get_reply_conversation_handler
from .admin_meetings import get_meetings_conversation_handler, MeetingsManager
from .utils import handle_zoom_link
from .admin_broadcast import broadcast_all, broadcast_subscribed, broadcast_active, broadcast_ids
from .admin_promocodes import (
    manage_promocodes, 
    get_promocodes_conversation_handler,
    list_promocodes,
    edit_promocode_menu,
    delete_promocode_menu
)

# Импортируем функции отчетов из корневого reports.py
from reports import handle_admin_report_request, handle_excel_export

# Импортируем модуль reminders для уведомлений о встречах и Zoom
from .reminders import (
    send_zoom_during_stream,
    notify_admins_about_stream,
    notify_admins_about_reminder
)

__all__ = [
    'start_command',
    'handle_privacy_policy',
    'handle_contact',
    'handle_main_menu',
    'handle_back_button',
    'handle_after_payment',
    'handle_speaker_detail',
    'handle_program_selection',
    'handle_tariff_selection',
    'handle_payment',
    'handle_promocode',
    'handle_faq',
    'admin_command',
    'handle_admin',
    'handle_text_message',
    'help_command',
    'handle_tinkoff_payment',
    'check_payment_status',
    'forward_user_message',
    'admin_messages',
    'get_reply_conversation_handler',
    'get_meetings_conversation_handler',
    'MeetingsManager',
    'handle_zoom_link',
    'handle_unknown_command',
    'broadcast_all',
    'broadcast_subscribed',
    'broadcast_active',
    'broadcast_ids',
    'manage_promocodes',
    'get_promocodes_conversation_handler',
    'handle_admin_report_request',  # Из корневого reports.py
    'handle_excel_export',           # Из корневого reports.py
    # Новые функции для уведомлений
    'send_zoom_during_stream',
    'notify_admins_about_stream',
    'notify_admins_about_reminder',
]