# test_zoom_simple.py
import asyncio
import os
import sys
from datetime import datetime, timedelta

# Добавляем путь для импорта
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from config import Config
from zoom_integration import get_zoom_instance, create_zoom_meeting

async def test_zoom_simple():
    """Простой тест Zoom API"""
    print("🧪 Тестируем Zoom API...")
    
    # Проверяем конфигурацию
    print(f"ZOOM_ENABLED: {Config.ZOOM_ENABLED}")
    print(f"ZOOM_CLIENT_ID: {'Есть' if Config.ZOOM_CLIENT_ID else 'Нет'}")
    print(f"ZOOM_API_KEY: {'Есть' if Config.ZOOM_API_KEY else 'Нет'}")
    
    if not Config.ZOOM_ENABLED:
        print("❌ Zoom API отключен в конфиге")
        return
    
    # Пробуем получить экземпляр
    zoom = get_zoom_instance()
    if zoom:
        print(f"✅ Экземпляр Zoom создан (использует {'JWT' if zoom.use_jwt else 'OAuth'})")
    else:
        print("❌ Не удалось создать экземпляр Zoom")
        return
    
    # Тестируем создание встречи (на завтра)
    tomorrow = datetime.now() + timedelta(days=1)
    print(f"🔄 Пробуем создать встречу на {tomorrow.strftime('%d.%m.%Y %H:%M')}...")
    
    try:
        result = await create_zoom_meeting(
            topic="Тестовая встреча из бота",
            start_time=tomorrow,
            duration=60
        )
        
        if result:
            print("🎉 УСПЕХ! Встреча создана!")
            print(f"   ID: {result['id']}")
            print(f"   Ссылка: {result['join_url']}")
            print(f"   Пароль: {result['password']}")
        else:
            print("❌ Встреча не создана (результат None)")
            
    except Exception as e:
        print(f"💥 ОШИБКА при создании встречи: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_zoom_simple())