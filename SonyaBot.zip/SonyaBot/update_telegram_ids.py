# update_telegram_ids.py
import sqlite3

print("🔄 ОБНОВЛЕНИЕ TELEGRAM ID")
print("="*70)

conn = sqlite3.connect('bestuzhevki.db')
cursor = conn.cursor()

# Сюда вставьте реальные ID, когда узнаете
users_ids = {
    'Dasha_Alvik': 0,  # замените 0 на реальный ID
    'asswxa': 0,
    'YuliaSu': 0,
    'katesoshnikova': 0,
    'mariyapoptsova': 0,
    'reginamuhkitdinova': 0,
    'anyaprocherk': 0,
    's_svetasveta': 0,
    'anastasia0986': 0
}

updated = 0
for username, real_id in users_ids.items():
    if real_id != 0:
        cursor.execute("""
            UPDATE users 
            SET telegram_id = ? 
            WHERE username = ? AND telegram_id < 0
        """, (real_id, username))
        if cursor.rowcount > 0:
            updated += cursor.rowcount
            print(f"✅ Обновлен ID для @{username}: {real_id}")

conn.commit()
print(f"\n📊 Обновлено пользователей: {updated}")
conn.close()