# bot.py - ПОЛНОСТЬЮ ИСПРАВЛЕННАЯ ВЕРСИЯ С ДЕБАГОМ И ОБРАБОТЧИКОМ ДЛЯ ПОДАРКОВ

import sys
import io
import os
import logging
import asyncio
import traceback
from datetime import datetime
import pytz
import requests
from telegram import Update
from telegram.ext import (
    Application, 
    ApplicationBuilder, 
    CommandHandler, 
    CallbackQueryHandler, 
    MessageHandler, 
    filters, 
    ContextTypes,
    ConversationHandler
)
from handlers.reminders import (
    send_zoom_during_stream,
    notify_admins_about_stream,
    notify_admins_about_reminder
)
from telegram.error import NetworkError, TimedOut, BadRequest, RetryAfter
from config import Config
from database import init_db

# Устанавливаем UTF-8 кодировку для вывода
if sys.platform == "win32":
    os.system('chcp 65001 > nul')
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=getattr(logging, Config.LOG_LEVEL),
    handlers=[
        logging.FileHandler(Config.LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Глобальный обработчик ошибок"""
    logger.error(f"Exception while handling update: {context.error}", exc_info=True)
    
    try:
        if isinstance(context.error, NetworkError) or isinstance(context.error, TimedOut):
            logger.warning(f"Сетевая ошибка, пропускаем уведомление: {context.error}")
            return
            
        for admin_id in Config.ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=f"⚠️ Ошибка в боте: {str(context.error)[:200]}"
                )
            except Exception as e:
                logger.warning(f"Не удалось отправить уведомление админу {admin_id}: {e}")
    except Exception as e:
        logger.error(f"Ошибка в error_handler: {e}")

async def safe_send_message(bot, chat_id, text, **kwargs):
    """Безопасная отправка сообщения с обработкой ошибок"""
    max_retries = 3
    retry_delay = 5
    
    for attempt in range(max_retries):
        try:
            return await bot.send_message(chat_id, text, **kwargs)
        except (NetworkError, TimedOut, RetryAfter) as e:
            if attempt < max_retries - 1:
                wait_time = retry_delay * (attempt + 1)
                logger.warning(f"Сетевая ошибка при отправке сообщения (попытка {attempt + 1}/{max_retries}): {e}. Ждем {wait_time} сек...")
                await asyncio.sleep(wait_time)
            else:
                logger.error(f"Не удалось отправить сообщение после {max_retries} попыток: {e}")
                raise
        except Exception as e:
            logger.error(f"Ошибка при отправке сообщения: {e}")
            raise

async def handle_copy_zoom(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик кнопки копирования Zoom ссылки"""
    query = update.callback_query
    await query.answer()
    
    logger.info(f"📋 handle_copy_zoom вызван: {query.data}")
    
    try:
        meeting_id = int(query.data.split('_')[2])
        
        engine = context.bot_data.get('engine')
        if not engine:
            logger.error("❌ Engine не найден в bot_data")
            return
        
        from database import get_session, Meeting
        session = None
        try:
            session = get_session(engine)
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            
            if meeting and meeting.zoom_link:
                await query.message.reply_text(
                    f"🔗 **Zoom ссылка для копирования:**\n\n"
                    f"`{meeting.zoom_link}`\n\n"
                    f"Нажмите и удерживайте ссылку, чтобы скопировать.",
                    parse_mode='Markdown'
                )
            else:
                await query.message.reply_text("❌ У этой встречи нет Zoom ссылки.")
                
        except Exception as e:
            logger.error(f"❌ Ошибка при копировании Zoom: {e}")
            await query.message.reply_text("❌ Ошибка при получении Zoom ссылки.")
        finally:
            if session:
                session.close()
            
    except Exception as e:
        logger.error(f"❌ Ошибка в handle_copy_zoom: {e}")
        await query.message.reply_text("❌ Произошла ошибка при обработке запроса.")

async def test_scheduler_manually(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ручной тест планировщика"""
    user = update.effective_user
    
    if user.id not in Config.ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет прав для этой команды.")
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        await update.message.reply_text("❌ Engine не найден.")
        return
    
    await update.message.reply_text("🔧 Запускаю ручной тест планировщика...")
    
    from scheduler import SchedulerManager
    
    test_scheduler = SchedulerManager(context.bot, engine)
    
    try:
        await update.message.reply_text("⏰ Проверяю 15-минутные напоминания...")
        await test_scheduler.check_15_min_reminders()
        
        await update.message.reply_text("🎥 Проверяю живые трансляции...")
        await test_scheduler.check_live_streams()
        
        await update.message.reply_text("✅ Ручной тест завершен. Проверьте логи.")
        
    except Exception as e:
        logger.error(f"❌ Ошибка при ручном тесте: {e}")
        await update.message.reply_text(f"❌ Ошибка: {str(e)}")

async def check_bot_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Проверка статуса бота"""
    user = update.effective_user
    
    if user.id not in Config.ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет прав для этой команды.")
        return
    
    engine = context.bot_data.get('engine')
    
    status_text = f"""🤖 **Статус бота**

📊 **База данных:** {'✅ Подключена' if engine else '❌ Ошибка'}
👥 **Админы:** {len(Config.ADMIN_IDS)} чел.
💰 **Тинькофф:** {'✅ Настроен' if Config.TINKOFF_TERMINAL_ID else '❌ Не настроен'}
🔗 **Zoom:** {'✅ Настроен' if Config.ZOOM_ENABLED else '❌ Не настроен'}
🏙️ **Города:** {len(Config.CITIES)} вариантов
💼 **Профессии:** {len(Config.PROFESSIONS)} вариантов

📅 **Текущее время:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
🕐 **Московское время:** {datetime.now(pytz.timezone('Europe/Moscow')).strftime('%Y-%m-%d %H:%M:%S')}

Используйте /test_scheduler для проверки планировщика.
Используйте /delete_user для удаления пользователя из базы."""
    
    await update.message.reply_text(status_text, parse_mode='Markdown')

# ========== ДИАГНОСТИЧЕСКАЯ КОМАНДА ==========
async def test_callback_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправляет тестовую inline-кнопку"""
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔴 ТЕСТОВАЯ КНОПКА", callback_data="test_button_pressed")]
    ])
    
    await update.message.reply_text(
        "🧪 **ТЕСТОВАЯ КЛАВИАТУРА**\n\nНажмите кнопку ниже:",
        parse_mode='Markdown',
        reply_markup=keyboard
    )

# ========== СПЕЦИАЛЬНЫЙ ОБРАБОТЧИК ДЛЯ /delete_user ==========
async def delete_user_special_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Специальный обработчик только для команды delete_user с самым высоким приоритетом"""
    if update.message and update.message.text and update.message.text.startswith('/delete_user'):
        user = update.effective_user
        logger.info(f"🔴 Специальный обработчик delete_user: пользователь {user.id}")
        
        if user.id not in Config.ADMIN_IDS:
            await update.message.reply_text("⛔ У вас нет прав для этой команды.")
            return
        
        try:
            # Парсим аргументы команды
            command_parts = update.message.text.split()
            if len(command_parts) > 1:
                context.args = command_parts[1:]
                logger.info(f"📋 Аргументы команды: {context.args}")
            else:
                context.args = []
                
            from handlers.admin import admin_delete_user
            await admin_delete_user(update, context)
            
            logger.info(f"✅ Команда /delete_user успешно обработана")
            return None
            
        except Exception as e:
            logger.error(f"❌ Ошибка в специальном обработчике delete_user: {e}")
            logger.error(traceback.format_exc())
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
            return None
    
    return None

def setup_handlers(application):
    """Настройка всех обработчиков в правильном порядке"""
    
    logger.info("🔄 Настройка обработчиков...")
    
    try:
        # Импорт обработчиков
        from handlers import (
            start_command, 
            handle_privacy_policy, 
            handle_contact, 
            handle_main_menu, 
            handle_back_button, 
            handle_after_payment, 
            handle_tariff_selection, 
            handle_payment, 
            handle_promocode, 
            handle_faq, 
            admin_command, 
            handle_admin, 
            help_command,
            handle_tinkoff_payment, 
            check_payment_status,
            handle_speaker_detail, 
            handle_program_selection,
            handle_shipping_info
        )
        from handlers.messages import forward_user_message, handle_admin_reply
        from handlers.admin_reply import get_reply_conversation_handler
        from handlers.admin_commands import admin_messages
        from handlers.admin_meetings import get_meetings_conversation_handler, MeetingsManager
        from handlers.utils import (
            handle_zoom_link, 
            handle_unknown_command,
            handle_city_selection, 
            handle_profession_selection,
            handle_back_to_cities, 
            handle_email_input_text,
            handle_shipping_info_text, 
            handle_promocode_text,
            handle_other_city_input, 
            handle_text_message,
            handle_back_to_tariffs, 
            handle_back_to_main
        )
        
        from handlers.start import (
            ask_city, 
            complete_registration,
            handle_city_selection as start_handle_city_selection,
            handle_profession_selection as start_handle_profession_selection
        )
        
        from handlers.admin_broadcast import broadcast_all, broadcast_subscribed, broadcast_active, broadcast_ids
        
        from handlers.admin_promocodes import (
            manage_promocodes,
            list_promocodes,
            active_promocodes,
            expired_promocodes,
            edit_promocode_menu,
            delete_promocode_menu,
            get_promocodes_conversation_handler,
            start_create_promocode
        )
        
        from handlers.admin import admin_delete_user, handle_delete_user_confirmation
        
        # ========== ИМПОРТ НОВЫХ ФУНКЦИЙ ДЛЯ ПРОВЕРКИ СТАТУСА И ПОДАРКОВ ==========
        from handlers.payment import (
            check_payment_status_command, 
            handle_check_status_button,
            handle_fill_gift_data,
            handle_manual_activation
        )
        
        try:
            from reports import handle_admin_report_request, handle_excel_export
            logger.info("✅ Импорт отчетов из reports.py успешен")
        except ImportError as e:
            logger.error(f"❌ Не удалось импортировать reports.py: {e}")
            async def handle_admin_report_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
                await update.callback_query.answer()
                await update.callback_query.message.edit_text(
                    "❌ Система отчетов временно недоступна",
                    parse_mode='Markdown'
                )
            
            async def handle_excel_export(update: Update, context: ContextTypes.DEFAULT_TYPE):
                await update.callback_query.answer()
                await update.callback_query.message.edit_text(
                    "❌ Excel выгрузка временно недоступна",
                    parse_mode='Markdown'
                )
        
        # ========== ГРУППА -100: ДЕБАГ ВСЕХ CALLBACK-ЗАПРОСОВ ==========
        async def debug_all_callbacks(update: Update, context: ContextTypes.DEFAULT_TYPE):
            """Логирует ВСЕ callback-запросы, которые доходят до бота"""
            if update.callback_query:
                logger.critical(f"🚨🚨🚨 ДЕБАГ: ПОЛУЧЕН CALLBACK: {update.callback_query.data}")
                logger.critical(f"🚨🚨🚨 ДЕБАГ: ОТ ПОЛЬЗОВАТЕЛЯ: {update.callback_query.from_user.id}")
                logger.critical(f"🚨🚨🚨 ДЕБАГ: СООБЩЕНИЕ ID: {update.callback_query.message.message_id}")
                
                # ИСПРАВЛЕНО: Только логируем, но НЕ вызываем обработчики напрямую
                if update.callback_query.data.startswith('confirm_delete_user_') or update.callback_query.data == 'cancel_delete_user':
                    logger.critical("🎯🎯🎯 ДЕБАГ: ЭТО CALLBACK ДЛЯ УДАЛЕНИЯ ПОЛЬЗОВАТЕЛЯ! (будет обработан в группе 2)")
                
                if update.callback_query.data == 'fill_gift_data':
                    logger.critical("🎯🎯🎯 ДЕБАГ: ЭТО CALLBACK ДЛЯ ЗАПОЛНЕНИЯ ДАННЫХ ПОДАРКОВ! (будет обработан в группе 2)")
                
                if update.callback_query.data.startswith('activate_subscription_'):
                    logger.critical("🎯🎯🎯 ДЕБАГ: ЭТО CALLBACK ДЛЯ РУЧНОЙ АКТИВАЦИИ! (будет обработан в группе 2)")
            
            # Возвращаем None, чтобы продолжить обработку в следующих группах
            return None
        
        application.add_handler(CallbackQueryHandler(debug_all_callbacks), group=-100)
        logger.info("  ✅ Дебаг-обработчик всех callback-запросов зарегистрирован (group=-100)")
        
        # ========== ГРУППА -99: ТЕСТОВЫЙ ОБРАБОТЧИК ==========
        async def test_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
            """Простой тестовый обработчик - ТОЛЬКО для тестовых кнопок!"""
            if update.callback_query and update.callback_query.data == "test_button_pressed":
                query = update.callback_query
                await query.answer()
                logger.critical(f"✅✅✅ ТЕСТОВЫЙ ОБРАБОТЧИК СРАБОТАЛ! callback: {query.data}")
                await query.message.reply_text(f"✅ Тест: получен callback {query.data}")
                return  # Прерываем только для тестовой кнопки
            
            # Для всех остальных callback'ов - продолжаем обработку
            return None
        
        application.add_handler(CallbackQueryHandler(test_callback_handler, pattern='^test_button_pressed$'), group=-99)
        logger.info("  ✅ Тестовый обработчик callback-запросов зарегистрирован (group=-99)")
        
        # ========== ГРУППА -1: СПЕЦИАЛЬНЫЙ ОБРАБОТЧИК ДЛЯ /delete_user ==========
        application.add_handler(
            MessageHandler(
                filters.COMMAND & filters.Regex(r'^/delete_user(\s|$)'), 
                delete_user_special_handler
            ), 
            group=-1
        )
        
        # ========== ГРУППА 0: ОСНОВНЫЕ КОМАНДЫ ==========
        application.add_handler(CommandHandler("start", start_command), group=0)
        application.add_handler(CommandHandler("admin", admin_command), group=0)
        application.add_handler(CommandHandler("help", help_command), group=0)
        application.add_handler(CommandHandler("messages", admin_messages), group=0)
        application.add_handler(CommandHandler("test_scheduler", test_scheduler_manually), group=0)
        application.add_handler(CommandHandler("status", check_bot_status), group=0)
        application.add_handler(CommandHandler("send_reminder", MeetingsManager.send_reminder_manually), group=0)
        application.add_handler(CommandHandler("test_callback", test_callback_command), group=0)
        
        # ========== НОВЫЕ КОМАНДЫ ДЛЯ ПРОВЕРКИ СТАТУСА ПЛАТЕЖА ==========
        application.add_handler(CommandHandler("payment_status", check_payment_status_command), group=0)
        application.add_handler(CommandHandler("check_payment", check_payment_status_command), group=0)  # Алиас
        
        # Команды рассылки
        application.add_handler(CommandHandler("broadcast_all", broadcast_all), group=0)
        application.add_handler(CommandHandler("broadcast_subscribed", broadcast_subscribed), group=0)
        application.add_handler(CommandHandler("broadcast_active", broadcast_active), group=0)
        application.add_handler(CommandHandler("broadcast_ids", broadcast_ids), group=0)

        # ========== ГРУППА 1: CONVERSATION HANDLERS ==========
        logger.info("🔄 Регистрация Conversation Handlers в группе 1...")
        
        # ConversationHandler для ответов админов
        reply_handler = get_reply_conversation_handler()
        if reply_handler:
            application.add_handler(reply_handler, group=1)
            logger.info("  ✅ Admin Reply ConversationHandler зарегистрирован")
        
        # ConversationHandler для встреч
        meetings_handler = get_meetings_conversation_handler()
        if meetings_handler:
            application.add_handler(meetings_handler, group=1)
            logger.info("  ✅ Meetings ConversationHandler зарегистрирован")
        
        # ConversationHandler для промокодов
        promocodes_handler = get_promocodes_conversation_handler()
        if promocodes_handler:
            application.add_handler(promocodes_handler, group=1)
            logger.info("  ✅ Promocodes ConversationHandler зарегистрирован")
        
        # ========== ГРУППА 2: CALLBACK QUERIES ==========
        logger.info("🔄 Регистрация CallbackQueryHandler в группе 2...")
        
        # Удаление пользователя
        application.add_handler(
            CallbackQueryHandler(handle_delete_user_confirmation, pattern='^(confirm_delete_user_|cancel_delete_user)$'), 
            group=2
        )
        
        # ========== НОВЫЕ ОБРАБОТЧИКИ ДЛЯ ПЛАТЕЖЕЙ И ПОДАРКОВ ==========
        application.add_handler(
            CallbackQueryHandler(handle_fill_gift_data, pattern='^fill_gift_data$'),
            group=2
        )
        
        application.add_handler(
            CallbackQueryHandler(handle_manual_activation, pattern='^activate_subscription_[0-9]+$'),
            group=2
        )
        
        # Регистрация
        application.add_handler(CallbackQueryHandler(handle_privacy_policy, pattern='^(agree_policy|decline_policy)$'), group=2)
        
        # Города
        application.add_handler(CallbackQueryHandler(handle_city_selection, pattern='^city_'), group=2)
        application.add_handler(CallbackQueryHandler(handle_back_to_cities, pattern='^back_to_cities$'), group=2)
        
        # Профессии
        application.add_handler(CallbackQueryHandler(handle_profession_selection, pattern='^prof_'), group=2)
        
        # Главное меню и навигация
        application.add_handler(CallbackQueryHandler(handle_main_menu, pattern='^(about_club|format_schedule|tariffs|speakers|faq|contact_manager|programm)$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_back_button, pattern='^back_to_'), group=2)
        application.add_handler(CallbackQueryHandler(handle_back_to_main, pattern='^back_to_main$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_back_to_tariffs, pattern='^back_to_tariffs$'), group=2)
        
        # Спикеры и программы
        application.add_handler(CallbackQueryHandler(handle_speaker_detail, pattern='^speaker_'), group=2)
        application.add_handler(CallbackQueryHandler(handle_program_selection, pattern='^program_'), group=2)
        
        # Тарифы и оплата
        application.add_handler(CallbackQueryHandler(handle_tariff_selection, pattern='^tariff_'), group=2)
        application.add_handler(CallbackQueryHandler(handle_payment, pattern='^pay_|^installment_payment$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_promocode, pattern='^(enter_promocode|remove_promocode|apply_promocode)$'), group=2)
        
        # FAQ
        application.add_handler(CallbackQueryHandler(handle_faq, pattern='^faq_'), group=2)
        
        # После оплаты
        application.add_handler(CallbackQueryHandler(handle_after_payment, pattern='^(add_to_calendar|materials)$'), group=2)
        
        # Промокоды (админка)
        application.add_handler(CallbackQueryHandler(manage_promocodes, pattern='^admin_promocodes$'), group=2)
        application.add_handler(CallbackQueryHandler(list_promocodes, pattern='^list_promocodes$'), group=2)
        application.add_handler(CallbackQueryHandler(active_promocodes, pattern='^active_promocodes$'), group=2)
        application.add_handler(CallbackQueryHandler(expired_promocodes, pattern='^expired_promocodes$'), group=2)
        application.add_handler(CallbackQueryHandler(edit_promocode_menu, pattern='^edit_promocode_menu$'), group=2)
        application.add_handler(CallbackQueryHandler(delete_promocode_menu, pattern='^delete_promocode_menu$'), group=2)
        
        # Тинькофф оплата
        if Config.TINKOFF_TERMINAL_ID and Config.TINKOFF_TERMINAL_PASSWORD:
            application.add_handler(CallbackQueryHandler(handle_tinkoff_payment, pattern='^tinkoff_'), group=2)
            application.add_handler(CallbackQueryHandler(check_payment_status, pattern='^check_status_'), group=2)
            
            # ========== ОБРАБОТЧИК ДЛЯ КНОПКИ ПОВТОРНОЙ ПРОВЕРКИ СТАТУСА ==========
            application.add_handler(
                CallbackQueryHandler(handle_check_status_button, pattern='^check_status_button_[0-9]+$'),
                group=2
            )
        
        # Отчеты
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^admin_report_week$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^admin_report_month$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^admin_report_custom$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^admin_excel_export$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^admin_report_'), group=2)
        application.add_handler(CallbackQueryHandler(handle_excel_export, pattern='^excel_'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^custom_'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^period_'), group=2)
        
        # ========== УПРАВЛЕНИЕ ВСТРЕЧАМИ И ZOOM ==========
        # Базовые обработчики встреч
        application.add_handler(CallbackQueryHandler(MeetingsManager.show_meetings_list, pattern='^meetings_list$'), group=2)
        application.add_handler(CallbackQueryHandler(MeetingsManager.add_zoom_link, pattern='^add_zoom_'), group=2)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_edit_meeting_menu, pattern='^edit_meeting_menu$'), group=2)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_delete_meeting_menu, pattern='^delete_meeting_menu$'), group=2)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_meeting_selection, pattern='^(edit_|delete_|select_)'), group=2)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_edit_meeting_action, pattern='^edit_action_'), group=2)
        
        # УДАЛЕНИЕ ВСТРЕЧ
        application.add_handler(
            CallbackQueryHandler(
                MeetingsManager.handle_delete_confirmation, 
                pattern='^confirm_delete_meeting_[0-9]+$'
            ), 
            group=2
        )
        
        # ОТМЕНА УДАЛЕНИЯ ВСТРЕЧИ
        application.add_handler(
            CallbackQueryHandler(
                MeetingsManager.handle_cancel_delete, 
                pattern='^cancel_delete_meeting$'
            ), 
            group=2
        )
        
        # Отмена любого действия
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_cancel_action, pattern='^cancel_action$'), group=2)
        
        # Создание встречи
        application.add_handler(CallbackQueryHandler(MeetingsManager.start_add_meeting_callback, pattern='^add_meeting$'), group=2)
        application.add_handler(CallbackQueryHandler(MeetingsManager.start_add_meeting_callback, pattern='^create_meeting$'), group=2)
        
        # Zoom
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_auto_zoom, pattern='^auto_zoom_'), group=2)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_manual_zoom, pattern='^manual_zoom_'), group=2)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_zoom_share, pattern='^zoom_share_'), group=2)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_send_zoom_to_all, pattern='^send_zoom_to_all_'), group=2)
        application.add_handler(CallbackQueryHandler(handle_copy_zoom, pattern='^copy_zoom_'), group=2)
        
        # ========== АДМИН-ПАНЕЛЬ ==========
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_stats$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_users$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_payments$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_meetings$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_reports$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_broadcast$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_faq$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_metrics$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_back$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_panel$'), group=2)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_'), group=2)
        
        logger.info("  ✅ CallbackQueryHandler зарегистрированы")
        
        # ========== ГРУППА 3: КОНТАКТЫ И МЕДИАФАЙЛЫ ==========
        logger.info("🔄 Регистрация MessageHandler для контактов и медиа в группе 3...")
        
        application.add_handler(MessageHandler(filters.CONTACT, handle_contact), group=3)
        application.add_handler(MessageHandler(
            filters.PHOTO | filters.VIDEO | filters.AUDIO | filters.VOICE | filters.Document.ALL,
            forward_user_message
        ), group=3)
        
        # Обработчик ответов админов (reply)
        application.add_handler(MessageHandler(
            filters.REPLY & filters.TEXT & ~filters.COMMAND,
            handle_admin_reply
        ), group=3)
        
        logger.info("  ✅ MessageHandler для контактов, медиа и reply зарегистрированы")
        
        # ========== ГРУППА 4: ТЕКСТОВЫЕ СООБЩЕНИЯ ==========
        logger.info("🔄 Регистрация MessageHandler для текстовых сообщений в группе 4...")
        
        async def handle_text_with_states(update: Update, context: ContextTypes.DEFAULT_TYPE):
            """Обработчик текста с проверкой состояний"""
            user = update.effective_user
            message_text = update.message.text
            
            # Проверяем специальные состояния
            if context.user_data.get('awaiting_city_input'):
                await handle_other_city_input(update, context, message_text)
                return
            
            if context.user_data.get('awaiting_email_for_receipt'):
                await handle_email_input_text(update, context)
                return
            
            if context.user_data.get('awaiting_shipping_info'):
                await handle_shipping_info_text(update, context)
                return
            
            if context.user_data.get('awaiting_promocode'):
                await handle_promocode_text(update, context)
                return
            
            # Для админов - Zoom ссылки
            if user.id in Config.ADMIN_IDS:
                if 'adding_zoom_to' in context.user_data and 'zoom_mode' in context.user_data:
                    from handlers.admin_meetings import MeetingsManager
                    processed = await MeetingsManager.process_manual_zoom_text(update, context)
                    if processed:
                        return
                
                if 'zoom.us' in message_text or 'zoom.us/j/' in message_text:
                    from handlers.admin_meetings import MeetingsManager
                    processed = await MeetingsManager.process_zoom_link(update, context)
                    if processed:
                        return
            
            # Стандартная пересылка менеджеру
            if len(message_text.strip()) > 0:
                try:
                    await forward_user_message(update, context)
                except Exception as e:
                    logger.error(f"Ошибка при пересылке сообщения: {e}")
                    await update.message.reply_text(
                        "❌ Не удалось отправить сообщение менеджеру. Попробуйте позже."
                    )
        
        application.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_with_states), 
            group=4
        )
        
        logger.info("  ✅ MessageHandler для текстовых сообщений зарегистрирован")
        
        # ========== ГРУППА 5: НЕИЗВЕСТНЫЕ КОМАНДЫ ==========
        logger.info("🔄 Регистрация MessageHandler для неизвестных команд в группе 5...")
        
        async def unknown_command_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
            """Обработчик неизвестных команд"""
            user = update.effective_user
            command = update.message.text.split()[0] if update.message.text else "unknown"
            
            if command == '/delete_user':
                logger.debug(f"Игнорируем команду {command} в обработчике неизвестных команд")
                return
            
            logger.info(f"❓ Неизвестная команда от пользователя {user.id}: {command}")
            
            if user.id in Config.ADMIN_IDS:
                await update.message.reply_text(
                    f"❌ Команда не найдена: {command}\n"
                    f"Доступные команды: /start, /admin, /help, /status, /delete_user, /broadcast_all, /payment_status"
                )
            else:
                await update.message.reply_text(
                    "❌ Неизвестная команда.\n"
                    "Используйте /start для начала работы, /payment_status для проверки оплаты или /help для помощи."
                )
        
        application.add_handler(
            MessageHandler(filters.COMMAND, unknown_command_handler), 
            group=5
        )
        
        logger.info("  ✅ MessageHandler для неизвестных команд зарегистрирован")
        
        # ========== ОБРАБОТЧИК ОШИБОК ==========
        application.add_error_handler(error_handler)
        
        logger.info("✅ Все обработчики успешно настроены")
        logger.info("✅ Порядок групп: -100 (дебаг) → -99 (тест) → -1 (delete_user) → 0 (команды) → 1 (ConversationHandlers) → 2 (callback) → 3 (медиа/reply) → 4 (текст) → 5 (неизвестные команды)")
        logger.info("✅ ВАЖНО: cancel_delete_meeting и cancel_delete_user теперь НЕ КОНФЛИКТУЮТ!")
        logger.info("✅ ДОБАВЛЕНЫ ОБРАБОТЧИКИ: fill_gift_data, activate_subscription_*")
        
    except Exception as e:
        logger.error(f"❌ Ошибка настройки обработчиков: {e}")
        logger.error(traceback.format_exc())
        raise

async def setup_scheduler_async(application, engine):
    """Асинхронная настройка планировщика"""
    try:
        from scheduler import setup_scheduler
        scheduler = setup_scheduler(application, engine)
        if scheduler:
            logger.info("✅ Планировщик настроен")
        else:
            logger.warning("⚠️ Планировщик не удалось настроить")
        return scheduler
    except Exception as e:
        logger.warning(f"⚠️ Ошибка настройки планировщика: {e}")
        return None

async def main_async():
    """Асинхронная основная функция запуска бота"""
    
    logger.info("=" * 60)
    logger.info("🚀 ИНИЦИАЛИЗАЦИЯ БОТА 'Бестужевки'")
    logger.info("=" * 60)
    
    # ========== КРИТИЧЕСКАЯ ПРОВЕРКА РЕЖИМА РАБОТЫ ==========
    try:
        logger.info("🔍 Проверка наличия вебхука...")
        webhook_info = requests.get(f"https://api.telegram.org/bot{Config.BOT_TOKEN}/getWebhookInfo").json()
        if webhook_info.get('result', {}).get('url'):
            logger.warning(f"⚠️⚠️⚠️ ОБНАРУЖЕН ВЕБХУК: {webhook_info['result']['url']}")
            logger.warning("⚠️⚠️⚠️ УДАЛЯЮ ВЕБХУК ДЛЯ РАБОТЫ В РЕЖИМЕ POLLING")
            
            delete_response = requests.get(f"https://api.telegram.org/bot{Config.BOT_TOKEN}/deleteWebhook?drop_pending_updates=true")
            logger.info(f"✅ Вебхук удален: {delete_response.json()}")
        else:
            logger.info("✅ Вебхук не установлен, работаем в режиме polling")
    except Exception as e:
        logger.error(f"❌ Ошибка при проверке вебхука: {e}")
    # ==========================================================
    
    if not Config.validate():
        logger.error("[ERROR] Конфигурация не прошла проверку. Исправьте .env файл.")
        return
    
    engine = None
    try:
        engine = init_db()
        logger.info("✅ База данных инициализирована")
    except Exception as e:
        logger.error(f"❌ Ошибка инициализации базы данных: {e}")
        logger.error(traceback.format_exc())
        return
    
    application = None
    try:
        application = ApplicationBuilder() \
            .token(Config.BOT_TOKEN) \
            .connect_timeout(120) \
            .read_timeout(120) \
            .write_timeout(120) \
            .pool_timeout(120) \
            .get_updates_read_timeout(120) \
            .get_updates_connect_timeout(120) \
            .get_updates_write_timeout(120) \
            .get_updates_pool_timeout(120) \
            .http_version("1.1") \
            .build()
        
        application.bot_data['engine'] = engine
        logger.info("✅ Приложение Telegram создано с таймаутами 120 секунд")
        
    except Exception as e:
        logger.error(f"❌ Ошибка создания приложения Telegram: {e}")
        logger.error(traceback.format_exc())
        return
    
    try:
        setup_handlers(application)
    except Exception as e:
        logger.error(f"❌ Ошибка настройки обработчиков: {e}")
        logger.error(traceback.format_exc())
        return
    
    scheduler = None
    try:
        scheduler = await setup_scheduler_async(application, engine)
    except Exception as e:
        logger.warning(f"⚠️ Планировщик не настроен: {e}")
    
    logger.info("=" * 60)
    logger.info("📊 ИНФОРМАЦИЯ:")
    logger.info(f"   Клуб: {Config.CLUB_NAME}")
    logger.info(f"   Админов: {len(Config.ADMIN_IDS)}")
    logger.info(f"   Тинькофф оплата: {'✅' if Config.TINKOFF_TERMINAL_ID and Config.TINKOFF_TERMINAL_PASSWORD else '❌'}")
    logger.info(f"   Zoom интеграция: {'✅' if Config.ZOOM_ENABLED else '❌'}")
    logger.info(f"   Планировщик: {'✅' if scheduler else '❌'}")
    logger.info(f"   Команда проверки статуса: ✅ /payment_status")
    logger.info(f"   Обработчик подарков: ✅ fill_gift_data")
    logger.info("=" * 60)
    
    for admin_id in Config.ADMIN_IDS:
        try:
            await safe_send_message(
                application.bot,
                chat_id=admin_id,
                text=f"""🤖 Бот '{Config.CLUB_NAME}' запущен!

📊 **Система регистрации с новыми полями активна:**
• 🏙️ Город проживания
• 💼 Профессия
• 📧 Email для чеков 54-ФЗ
• 📦 Данные для отправки подарков

🔄 Используйте /admin для управления.
🗑️ Используйте /delete_user для удаления пользователей.
🎫 Управление промокодами доступно в админ-панели.
🧪 Используйте /test_callback для проверки callback-запросов.
💳 Пользователи могут проверить статус оплаты командой /payment_status
📦 Для годового тарифа доступна кнопка заполнения данных подарков"""
            )
        except Exception as e:
            logger.warning(f"Не удалось отправить уведомление админу {admin_id}: {e}")
    
    try:
        logger.info("✅ Бот успешно запущен!")
        
        await application.initialize()
        await application.start()
        await application.updater.start_polling(
            drop_pending_updates=True,
            allowed_updates=["message", "callback_query", "chat_member", "inline_query", "chosen_inline_result"],
            read_timeout=120,
            write_timeout=120,
            connect_timeout=120,
            pool_timeout=120
        )
        
        logger.info("🔄 Бот работает... Нажмите Ctrl+C для остановки.")
        
        while True:
            await asyncio.sleep(3600)
        
    except KeyboardInterrupt:
        logger.info("⏹️ Бот остановлен пользователем")
    except (NetworkError, TimedOut) as e:
        logger.error(f"❌ Сетевая ошибка при работе бота: {e}")
        logger.info("🔄 Перезапуск через 10 секунд...")
        await asyncio.sleep(10)
        await main_async()
    except Exception as e:
        logger.error(f"❌ Фатальная ошибка при работе бота: {e}")
        logger.error(traceback.format_exc())
        raise
    finally:
        if application and application.running:
            try:
                logger.info("🔄 Останавливаем бота...")
                await application.stop()
                await application.shutdown()
                logger.info("✅ Бот остановлен")
            except Exception as e:
                logger.error(f"❌ Ошибка при остановке бота: {e}")
        
        if scheduler:
            try:
                scheduler.shutdown()
            except:
                pass

def main():
    """Основная функция запуска бота"""
    try:
        if sys.platform == 'win32':
            pass
        
        asyncio.run(main_async())
    except KeyboardInterrupt:
        logger.info("👋 Завершено пользователем")
    except Exception as e:
        logger.error(f"❌ Фатальная ошибка при запуске бота: {e}")
        logger.error(traceback.format_exc())

if __name__ == '__main__':
    main()