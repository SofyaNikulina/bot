from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters, CallbackQueryHandler, CommandHandler
from database import get_session, UserMessage, AdminReply
from config import Config
import logging

logger = logging.getLogger(__name__)

# Состояния для ConversationHandler
WAITING_REPLY = 1

async def handle_reply_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик нажатия кнопки "Ответить" под сообщением"""
    query = update.callback_query
    await query.answer()
    
    logger.info(f"🔘 Нажата кнопка 'Ответить', callback_data: {query.data}")
    
    # Проверяем, что нажал админ
    if query.from_user.id not in Config.ADMIN_IDS:
        logger.warning(f"Пользователь {query.from_user.id} не админ")
        await query.message.reply_text("⛔ Только администраторы могут отвечать на сообщения.")
        return ConversationHandler.END
    
    # Извлекаем ID сообщения из callback_data
    if query.data.startswith('reply_msg_'):
        message_id = int(query.data.replace('reply_msg_', ''))
    else:
        logger.error(f"Неправильный callback_data: {query.data}")
        return ConversationHandler.END
    
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        await query.message.reply_text("❌ Ошибка подключения к базе данных.")
        return ConversationHandler.END
    
    session = get_session(engine)
    
    try:
        # Находим сообщение в БД
        user_message = session.query(UserMessage).filter_by(id=message_id).first()
        if not user_message:
            logger.error(f"Сообщение #{message_id} не найдено в БД")
            await query.message.reply_text("❌ Сообщение не найдено в базе данных.")
            return ConversationHandler.END
        
        # Сохраняем в контексте информацию для ответа
        context.user_data['replying_to'] = {
            'message_id': message_id,
            'user_id': user_message.telegram_id,
            'admin_message_id': query.message.message_id,
            'chat_id': query.message.chat_id
        }
        
        logger.info(f"📝 Начинаем ответ на сообщение #{message_id} от пользователя {user_message.telegram_id}")
        
        # Запрашиваем текст ответа
        await query.message.reply_text(
            f"✍️ <b>Введите ответ для пользователя #{user_message.telegram_id}</b>\n\n"
            f"Вы отвечаете на сообщение #{message_id}.\n"
            f"Напишите текст ответа или отправьте /cancel для отмены.",
            parse_mode='HTML'
        )
        
        return WAITING_REPLY
        
    except Exception as e:
        logger.error(f"Ошибка при обработке запроса на ответ: {e}", exc_info=True)
        await query.message.reply_text("❌ Произошла ошибка при обработке запроса.")
        return ConversationHandler.END
    finally:
        session.close()

async def process_admin_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик текста ответа от админа"""
    
    logger.info("="*60)
    logger.info("📤 ОТПРАВКА ОТВЕТА ОТ АДМИНА")
    logger.info(f"Админ: {update.message.from_user.id}")
    logger.info(f"Текст ответа: {update.message.text}")
    
    # Проверяем, что это админ
    if update.message.from_user.id not in Config.ADMIN_IDS:
        logger.warning("⛔ Не админ пытается ответить")
        await update.message.reply_text("⛔ У вас нет прав для этой команды.")
        return ConversationHandler.END
    
    # Проверяем, что есть данные для ответа
    if 'replying_to' not in context.user_data:
        logger.error("❌ Нет данных replying_to в user_data")
        await update.message.reply_text("❌ Не найдены данные для ответа. Начните заново, нажав кнопку 'Ответить'.")
        return ConversationHandler.END
    
    reply_data = context.user_data['replying_to']
    message_id = reply_data['message_id']
    user_id = reply_data['user_id']
    admin_message_id = reply_data.get('admin_message_id')
    chat_id = reply_data.get('chat_id')
    
    logger.info(f"Данные ответа: message_id={message_id}, user_id={user_id}")
    
    reply_text = update.message.text
    
    if not reply_text or reply_text.strip() == "":
        await update.message.reply_text("❌ Сообщение не может быть пустым. Напишите текст ответа или /cancel для отмены.")
        return WAITING_REPLY  # Остаемся в том же состоянии
    
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        await update.message.reply_text("❌ Ошибка подключения к базе данных.")
        return ConversationHandler.END
    
    session = get_session(engine)
    
    try:
        # Находим исходное сообщение
        user_message = session.query(UserMessage).filter_by(id=message_id).first()
        if not user_message:
            logger.error(f"Сообщение #{message_id} не найдено в БД")
            await update.message.reply_text("❌ Сообщение не найдено.")
            return ConversationHandler.END
        
        # Проверяем, не был ли уже отправлен ответ
        if user_message.admin_replied:
            logger.warning(f"На сообщение #{message_id} уже был дан ответ")
            await update.message.reply_text("⚠️ На это сообщение уже был дан ответ. Всё равно отправить?")
            # Продолжаем, так как админ подтвердит
        
        # Сохраняем ответ в БД
        admin_reply = AdminReply(
            message_id=message_id,
            admin_id=update.message.from_user.id,
            reply_text=reply_text
        )
        session.add(admin_reply)
        
        # Обновляем исходное сообщение
        user_message.admin_replied = True
        user_message.admin_id = update.message.from_user.id
        user_message.admin_reply = reply_text
        user_message.replied_at = update.message.date
        
        session.commit()
        
        logger.info(f"💾 Ответ сохранен в БД, AdminReply ID: {admin_reply.id}")
        
        # Отправляем ответ пользователю
        try:
            logger.info(f"📨 Пытаемся отправить ответ пользователю {user_id}")
            
            # Форматируем ответ
            formatted_reply = f"📩 <b>Ответ от менеджера:</b>\n\n{reply_text}"
            
            await context.bot.send_message(
                chat_id=user_id,
                text=formatted_reply,
                parse_mode='HTML'
            )
            
            logger.info(f"✅ Ответ отправлен пользователю {user_id}")
            
            admin_reply.sent = True
            admin_reply.sent_at = update.message.date
            session.commit()
            
            # Подтверждаем админу
            await update.message.reply_text(
                f"✅ Ответ отправлен пользователю #{user_id}",
                reply_to_message_id=update.message.message_id
            )
            
            # Обновляем кнопку в исходном сообщении админа
            if admin_message_id and chat_id:
                try:
                    await context.bot.edit_message_reply_markup(
                        chat_id=chat_id,
                        message_id=admin_message_id,
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("✅ Отвечено", callback_data=f"replied_msg_{message_id}")]
                        ])
                    )
                    logger.info(f"🔄 Кнопка обновлена в сообщении {admin_message_id}")
                except Exception as e:
                    logger.warning(f"Не удалось обновить кнопку: {e}")
            else:
                logger.warning("Нет данных для обновления кнопки")
                
        except Exception as e:
            logger.error(f"❌ Не удалось отправить ответ пользователю {user_id}: {e}", exc_info=True)
            await update.message.reply_text(
                f"❌ Не удалось отправить ответ пользователю #{user_id}. Возможно:\n"
                f"• Он заблокировал бота\n"
                f"• Он не начинал диалог с ботом\n"
                f"• Ошибка Telegram API"
            )
            # Не очищаем данные, чтобы можно было попробовать снова
            return WAITING_REPLY
        
    except Exception as e:
        logger.error(f"Ошибка при сохранении ответа: {e}", exc_info=True)
        session.rollback()
        await update.message.reply_text("❌ Произошла ошибка при сохранении ответа.")
        return WAITING_REPLY  # Остаемся в том же состоянии
    finally:
        session.close()
        # Очищаем данные
        if 'replying_to' in context.user_data:
            del context.user_data['replying_to']
            logger.info("🧹 Данные replying_to очищены")
    
    logger.info("="*60)
    return ConversationHandler.END

async def cancel_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отмена ответа"""
    logger.info("❌ Ответ отменен")
    
    if update.message and update.message.from_user.id in Config.ADMIN_IDS:
        await update.message.reply_text("❌ Ответ отменен.")
    
    # Очищаем данные
    if 'replying_to' in context.user_data:
        del context.user_data['replying_to']
    
    return ConversationHandler.END

# Conversation Handler для ответов админов
def get_reply_conversation_handler():
    """Создание ConversationHandler для ответов админов"""
    return ConversationHandler(
        entry_points=[CallbackQueryHandler(handle_reply_button, pattern='^reply_msg_')],
        states={
            WAITING_REPLY: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, process_admin_reply)
            ]
        },
        fallbacks=[
            CommandHandler('cancel', cancel_reply),
            CallbackQueryHandler(cancel_reply, pattern='^cancel_reply$')
        ],
        name="admin_reply_conversation",
        persistent=False,
        per_message=False  # Важно: per_message=False для корректной работы
    )