# handlers/admin.py - ИСПРАВЛЕННЫЙ (удаляем дублирующую регистрацию обработчиков)

from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
from database import get_session, User, Payment, Subscription, Meeting, AdminLog, PromoUsage, Promocode
from keyboards import (
    get_admin_keyboard, 
    get_admin_reports_keyboard,
    get_meetings_management_keyboard,
    get_meetings_list_keyboard,
    get_meeting_selection_keyboard,
    get_meeting_detail_keyboard,
    get_admin_back_keyboard,
    get_cancel_keyboard
)
from config import Config
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

def log_admin_action(session, admin_id: int, action: str, details: dict = None):
    """Логирование действий администратора"""
    try:
        log = AdminLog(
            admin_id=admin_id,
            action=action,
            details=details or {}
        )
        session.add(log)
        session.commit()
        logger.debug(f"Записано действие админа {admin_id}: {action}")
    except Exception as e:
        logger.error(f"Ошибка логирования действия админа: {e}")
        session.rollback()

# ========== КОМАНДА ДЛЯ УДАЛЕНИЯ ПОЛЬЗОВАТЕЛЯ ==========

async def admin_delete_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда для удаления пользователя (только для админов)"""
    user = update.effective_user
    
    logger.info(f"🟢 admin_delete_user вызван админом {user.id}")
    
    # Проверяем права администратора
    if user.id not in Config.ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет прав для этой команды")
        return
    
    # Проверяем аргументы команды
    if not context.args:
        await update.message.reply_text(
            "❌ <b>Укажите Telegram ID пользователя</b>\n\n"
            "Использование:\n"
            "<code>/delete_user 123456789</code> - удалить пользователя по ID\n"
            "<code>/delete_user @username</code> - удалить пользователя по username\n"
            "<code>/delete_user me</code> - удалить себя (админа)\n\n"
            "⚠️ <b>Внимание:</b> Будут удалены все данные пользователя:\n"
            "• Профиль\n"
            "• Подписки\n"
            "• Платежи\n"
            "• История использований промокодов",
            parse_mode='HTML'
        )
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("❌ Engine не найден в bot_data")
        await update.message.reply_text("❌ Ошибка подключения к базе данных")
        return
    
    session = get_session(engine)
    
    try:
        target_id = context.args[0]
        user_to_delete = None
        
        logger.info(f"🔍 Поиск пользователя: {target_id}")
        
        # Обработка разных форматов ввода
        if target_id == 'me':
            user_to_delete = session.query(User).filter_by(telegram_id=user.id).first()
            if not user_to_delete:
                await update.message.reply_text("❌ Вы не найдены в базе данных")
                return
                
        elif target_id.startswith('@'):
            username = target_id[1:]
            user_to_delete = session.query(User).filter_by(username=username).first()
            if not user_to_delete:
                await update.message.reply_text(f"❌ Пользователь с username {target_id} не найден")
                return
                
        else:
            try:
                telegram_id = int(target_id)
                user_to_delete = session.query(User).filter_by(telegram_id=telegram_id).first()
                if not user_to_delete:
                    await update.message.reply_text(f"❌ Пользователь с ID {telegram_id} не найден")
                    return
            except ValueError:
                await update.message.reply_text("❌ Неверный формат ID. Используйте число, @username или 'me'")
                return
        
        logger.info(f"✅ Пользователь найден: ID={user_to_delete.id}, telegram_id={user_to_delete.telegram_id}, username=@{user_to_delete.username}")
        
        # Сохраняем информацию о пользователе для отчета
        user_info = {
            'id': user_to_delete.id,
            'telegram_id': user_to_delete.telegram_id,
            'username': user_to_delete.username,
            'first_name': user_to_delete.first_name,
            'email': user_to_delete.email,
            'phone': user_to_delete.phone_number,
            'joined_at': user_to_delete.joined_at.strftime('%d.%m.%Y %H:%M') if user_to_delete.joined_at else 'неизвестно'
        }
        
        # Подсчитываем количество связанных записей
        subscriptions_count = session.query(Subscription).filter_by(user_id=user_to_delete.id).count()
        payments_count = session.query(Payment).filter_by(user_id=user_to_delete.id).count()
        promo_usage_count = session.query(PromoUsage).filter_by(user_id=user_to_delete.id).count()
        
        # Запрашиваем подтверждение
        confirm_keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ Да, удалить", callback_data=f'confirm_delete_user_{user_to_delete.id}'),
                InlineKeyboardButton("❌ Нет, отменить", callback_data='cancel_delete_user')
            ]
        ])
        
        message = await update.message.reply_text(
            f"⚠️ <b>Подтверждение удаления пользователя</b>\n\n"
            f"👤 <b>Информация о пользователе:</b>\n"
            f"• ID: <code>{user_to_delete.telegram_id}</code>\n"
            f"• Username: @{user_to_delete.username or 'нет'}\n"
            f"• Имя: {user_to_delete.first_name or 'нет'}\n"
            f"• Email: {user_to_delete.email or 'нет'}\n"
            f"• Телефон: {user_to_delete.phone_number or 'нет'}\n"
            f"• Дата регистрации: {user_info['joined_at']}\n\n"
            f"📊 <b>Связанные данные:</b>\n"
            f"• Подписки: {subscriptions_count}\n"
            f"• Платежи: {payments_count}\n"
            f"• Использования промокодов: {promo_usage_count}\n\n"
            f"<b>❗️ Это действие необратимо!</b>\n"
            f"Все данные пользователя будут безвозвратно удалены.",
            parse_mode='HTML',
            reply_markup=confirm_keyboard
        )
        
        logger.info(f"📨 Отправлено сообщение с подтверждением удаления, message_id={message.message_id}")
        
        # Сохраняем ID пользователя для удаления в context.user_data
        context.user_data['user_to_delete_id'] = user_to_delete.id
        context.user_data['user_to_delete_telegram_id'] = user_to_delete.telegram_id
        context.user_data['user_to_delete_username'] = user_to_delete.username
        logger.info(f"💾 Сохранено в user_data: user_to_delete_id={user_to_delete.id}")
        
    except Exception as e:
        logger.error(f"❌ Ошибка при удалении пользователя: {e}", exc_info=True)
        await update.message.reply_text(f"❌ Произошла ошибка: {str(e)[:100]}")
        session.rollback()
    finally:
        session.close()


async def handle_delete_user_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик подтверждения удаления пользователя"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    logger.info(f"🟢 handle_delete_user_confirmation вызван админом {user.id}, callback_data={query.data}")
    
    # Проверяем права администратора
    if user.id not in Config.ADMIN_IDS:
        logger.warning(f"⚠️ Пользователь {user.id} пытается подтвердить удаление без прав")
        await query.message.edit_text("⛔ У вас нет прав для этого действия")
        return
    
    if query.data == 'cancel_delete_user':
        logger.info(f"❌ Удаление пользователя отменено админом {user.id}")
        await query.message.edit_text(
            "✅ Удаление пользователя отменено.",
            parse_mode='HTML'
        )
        if 'user_to_delete_id' in context.user_data:
            logger.info(f"🗑️ Удаляю из user_data: user_to_delete_id={context.user_data['user_to_delete_id']}")
            del context.user_data['user_to_delete_id']
        if 'user_to_delete_telegram_id' in context.user_data:
            del context.user_data['user_to_delete_telegram_id']
        if 'user_to_delete_username' in context.user_data:
            del context.user_data['user_to_delete_username']
        return
    
    if query.data.startswith('confirm_delete_user_'):
        try:
            # Получаем ID пользователя из callback_data
            user_id = int(query.data.split('_')[-1])
            logger.info(f"🔍 Получен ID пользователя для удаления: {user_id}")
            
            # Проверяем engine
            engine = context.bot_data.get('engine')
            if not engine:
                logger.error("❌ Engine не найден в bot_data!")
                await query.message.edit_text("❌ Ошибка подключения к базе данных")
                return
            
            logger.info(f"✅ Engine найден в bot_data")
            
            # Создаем сессию
            session = get_session(engine)
            logger.info(f"✅ Сессия БД создана")
            
            try:
                # Находим пользователя
                user_to_delete = session.query(User).filter_by(id=user_id).first()
                
                if not user_to_delete:
                    logger.error(f"❌ Пользователь с ID {user_id} не найден в базе данных")
                    await query.message.edit_text("❌ Пользователь не найден в базе данных")
                    return
                
                logger.info(f"✅ Пользователь найден: telegram_id={user_to_delete.telegram_id}, username=@{user_to_delete.username}")
                
                # Сохраняем информацию для лога
                telegram_id = user_to_delete.telegram_id
                username = user_to_delete.username
                
                # Подсчитываем количество связанных записей
                subscriptions_count = session.query(Subscription).filter_by(user_id=user_id).count()
                payments_count = session.query(Payment).filter_by(user_id=user_id).count()
                promo_usage_count = session.query(PromoUsage).filter_by(user_id=user_id).count()
                
                logger.info(f"📊 Статистика удаляемого пользователя:")
                logger.info(f"   - Подписки: {subscriptions_count}")
                logger.info(f"   - Платежи: {payments_count}")
                logger.info(f"   - Использования промокодов: {promo_usage_count}")
                
                # Удаляем связанные данные
                if subscriptions_count > 0:
                    deleted_subscriptions = session.query(Subscription).filter_by(user_id=user_id).delete()
                    logger.info(f"🗑️ Удалено подписок: {deleted_subscriptions}")
                
                if payments_count > 0:
                    deleted_payments = session.query(Payment).filter_by(user_id=user_id).delete()
                    logger.info(f"🗑️ Удалено платежей: {deleted_payments}")
                
                if promo_usage_count > 0:
                    deleted_promo_usage = session.query(PromoUsage).filter_by(user_id=user_id).delete()
                    logger.info(f"🗑️ Удалено использований промокодов: {deleted_promo_usage}")
                
                # Удаляем пользователя
                session.delete(user_to_delete)
                session.commit()
                
                logger.info(f"✅ Пользователь успешно удален из БД")
                
                # Логируем действие
                try:
                    log_admin_action(session, user.id, 'deleted_user', {
                        'deleted_user_id': telegram_id,
                        'deleted_username': username,
                        'deleted_subscriptions': subscriptions_count,
                        'deleted_payments': payments_count,
                        'deleted_promo_usage': promo_usage_count
                    })
                    logger.info(f"✅ Действие записано в лог")
                except Exception as log_error:
                    logger.error(f"❌ Ошибка при логировании: {log_error}")
                
                await query.message.edit_text(
                    f"✅ <b>Пользователь успешно удален!</b>\n\n"
                    f"👤 Telegram ID: <code>{telegram_id}</code>\n"
                    f"📱 Username: @{username or 'нет'}\n\n"
                    f"🗑️ Удалено:\n"
                    f"• Подписок: {subscriptions_count}\n"
                    f"• Платежей: {payments_count}\n"
                    f"• Использований промокодов: {promo_usage_count}",
                    parse_mode='HTML'
                )
                
                logger.info(f"✅ Админ {user.id} удалил пользователя {telegram_id} (@{username})")
                
            except Exception as e:
                logger.error(f"❌ Ошибка при удалении пользователя: {e}", exc_info=True)
                session.rollback()
                await query.message.edit_text(f"❌ Ошибка при удалении: {str(e)[:100]}")
            finally:
                session.close()
                logger.info(f"🔒 Сессия БД закрыта")
                
                # Очищаем user_data
                if 'user_to_delete_id' in context.user_data:
                    logger.info(f"🗑️ Удаляю из user_data: user_to_delete_id={context.user_data['user_to_delete_id']}")
                    del context.user_data['user_to_delete_id']
                if 'user_to_delete_telegram_id' in context.user_data:
                    del context.user_data['user_to_delete_telegram_id']
                if 'user_to_delete_username' in context.user_data:
                    del context.user_data['user_to_delete_username']
                    
        except (ValueError, IndexError) as e:
            logger.error(f"❌ Ошибка при разборе callback_data: {e}")
            logger.error(f"   callback_data: {query.data}")
            await query.message.edit_text("❌ Ошибка при обработке запроса")


# ========== ОСНОВНЫЕ ФУНКЦИИ АДМИН-ПАНЕЛИ ==========

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /admin"""
    user = update.effective_user
    
    logger.info(f"Команда /admin от пользователя {user.id} (@{user.username})")
    
    if user.id not in Config.ADMIN_IDS:
        logger.warning(f"Пользователь {user.id} попытался получить доступ к админ-панели")
        await update.message.reply_text("⛔ У вас нет прав администратора.")
        return
    
    text = """<b>🛠️ Панель администратора</b>

Выберите раздел для управления:"""
    
    await update.message.reply_text(
        text,
        reply_markup=get_admin_keyboard(),
        parse_mode='HTML'
    )


async def handle_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик админ-панели"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    
    logger.info(f"Админ {user.id} выбрал: {query.data}")
    
    if user.id not in Config.ADMIN_IDS:
        logger.warning(f"Пользователь {user.id} пытается получить доступ к админ-панели")
        await query.message.edit_text("⛔ У вас нет прав администратора.")
        return
    
    # Получаем engine из bot_data
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("❌ Engine не найден в bot_data!")
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    # Создаем сессию с правильным engine
    session = get_session(engine)
    
    try:
        if query.data == 'admin_stats':
            # Статистика
            total_users = session.query(User).count()
            active_users = session.query(User).filter(User.is_active == True).count()
            subscribed_users = session.query(Subscription).filter(Subscription.is_active == True).count()
            
            # Платежи
            payments = session.query(Payment).filter(Payment.status == 'completed').all()
            total_revenue = sum(p.amount for p in payments) / 100 if payments else 0
            
            # Тарифы
            tariffs_count = {}
            all_tariffs = ['creative', '1_month', '3_months', '12_months']
            for tariff in all_tariffs:
                count = session.query(Subscription).filter(
                    Subscription.tariff == tariff,
                    Subscription.is_active == True
                ).count()
                tariffs_count[tariff] = count
            
            # Активные встречи
            upcoming_meetings = session.query(Meeting).filter(
                Meeting.date_time >= datetime.now(),
                Meeting.is_active == True
            ).count()
            
            text = f"""<b>📊 Статистика клуба «Бестужевки»</b>

<b>👥 Пользователи:</b>
• Всего: {total_users}
• Активных: {active_users}
• С подпиской: {subscribed_users}

<b>💰 Финансы:</b>
• Общая выручка: {total_revenue:,.0f} ₽
• Средний чек: {total_revenue/len(payments) if payments else 0:,.0f} ₽

<b>📈 Тарифы:</b>
• Творческий: {tariffs_count.get('creative', 0)}
• 1 месяц: {tariffs_count.get('1_month', 0)}
• 3 месяца: {tariffs_count.get('3_months', 0)}
• 12 месяцев: {tariffs_count.get('12_months', 0)}

<b>📅 Встречи:</b>
• Предстоящих встреч: {upcoming_meetings}

<b>🔄 За сегодня:</b>
• Новые пользователи: {session.query(User).filter(User.joined_at >= datetime.now().date()).count()}
• Новые оплаты: {session.query(Payment).filter(Payment.created_at >= datetime.now().date(), Payment.status == 'completed').count()}
• Новые встречи: {session.query(Meeting).filter(Meeting.created_at >= datetime.now().date()).count()}"""
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_stats', {
                'total_users': total_users,
                'total_revenue': total_revenue
            })
        
        elif query.data == 'admin_users':
            # Последние 10 пользователей
            users = session.query(User).order_by(User.joined_at.desc()).limit(10).all()
            
            text = "<b>👥 Последние пользователи:</b>\n\n"
            
            for i, db_user in enumerate(users, 1):
                has_subscription = session.query(Subscription).filter(
                    Subscription.user_id == db_user.id,
                    Subscription.is_active == True
                ).first() is not None
                
                user_name = f"{db_user.first_name or ''} {db_user.last_name or ''}".strip()
                if not user_name:
                    user_name = "Без имени"
                
                text += f"{i}. <b>{user_name}</b>\n"
                text += f"   👤 @{db_user.username or 'нет'}\n"
                text += f"   📱 {db_user.phone_number or 'нет'}\n"
                text += f"   🆔 <code>{db_user.telegram_id}</code>\n"
                text += f"   📅 {db_user.joined_at.strftime('%d.%m.%Y')}\n"
                text += f"   💎 Подписка: {'✅ да' if has_subscription else '❌ нет'}\n\n"
            
            if len(users) == 10:
                text += "ℹ️ Показаны последние 10 пользователей"
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_users')
        
        elif query.data == 'admin_payments':
            # Последние 10 платежей
            payments = session.query(Payment).filter(Payment.status == 'completed').order_by(Payment.completed_at.desc()).limit(10).all()
            
            text = "<b>💰 Последние платежи:</b>\n\n"
            
            for i, payment in enumerate(payments, 1):
                payment_user = payment.user
                user_name = f"{payment_user.first_name or ''} {payment_user.last_name or ''}".strip()
                if not user_name:
                    user_name = "Без имени"
                
                text += f"{i}. <b>{user_name}</b>\n"
                text += f"   💳 {payment.amount/100:,.0f} ₽\n"
                text += f"   📅 {payment.completed_at.strftime('%d.%m.%Y %H:%M') if payment.completed_at else 'нет даты'}\n"
                text += f"   🏷️ {payment.tariff or 'не указан'}\n"
                if payment.promocode:
                    text += f"   🎫 {payment.promocode}\n"
                text += "\n"
            
            if len(payments) == 10:
                text += "ℹ️ Показаны последние 10 платежей"
            elif not payments:
                text += "ℹ️ Платежей еще нет"
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_payments', {
                'count': len(payments)
            })
        
        elif query.data == 'admin_meetings':
            # Управление встречами
            total_meetings = session.query(Meeting).count()
            upcoming_meetings = session.query(Meeting).filter(
                Meeting.date_time >= datetime.now()
            ).count()
            past_meetings = session.query(Meeting).filter(
                Meeting.date_time < datetime.now()
            ).count()
            
            text = f"""<b>📅 Управление встречами</b>

📊 Статистика:
• Всего встреч: {total_meetings}
• Предстоящих: {upcoming_meetings}
• Прошедших: {past_meetings}

Выберите действие:"""
            
            await query.message.edit_text(
                text,
                reply_markup=get_meetings_management_keyboard(),
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_meetings_management')
        
        elif query.data == 'admin_reports':
            # Раздел отчетов
            text = "<b>📊 Отчеты и аналитика</b>\n\nВыберите тип отчета:"
            
            await query.message.edit_text(
                text,
                reply_markup=get_admin_reports_keyboard(),
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_reports')
        
        elif query.data == 'admin_promocodes':
            # Управление промокодами
            try:
                from handlers.admin_promocodes import manage_promocodes
                await manage_promocodes(update, context)
            except ImportError as e:
                logger.error(f"Не удалось импортировать manage_promocodes: {e}")
                promocodes = session.query(Promocode).order_by(Promocode.created_at.desc()).limit(10).all()
                
                text = """<b>🎫 Управление промокодами</b>\n\n"""
                
                if promocodes:
                    text += "<b>Последние промокоды:</b>\n"
                    for i, promo in enumerate(promocodes, 1):
                        status = "✅" if promo.is_active else "❌"
                        valid_to = f"до {promo.valid_to.strftime('%d.%m.%Y')}" if promo.valid_to else "без срока"
                        uses = f"{promo.used_count}/{promo.max_uses}" if promo.max_uses else f"{promo.used_count}/∞"
                        
                        text += f"{i}. {status} <code>{promo.code}</code>\n"
                        text += f"   Скидка: {promo.discount_amount/100 if promo.discount_amount else promo.discount_percent}{'₽' if promo.discount_amount else '%'}\n"
                        text += f"   Использовано: {uses}\n"
                        text += f"   {valid_to}\n\n"
                else:
                    text += "ℹ️ Промокодов пока нет\n\n"
                
                text += "<b>Создание промокодов доступно в админ-панели</b>"
                
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("📝 Создать промокод", callback_data='create_promocode')],
                    [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
                ])
                
                await query.message.edit_text(
                    text,
                    reply_markup=keyboard,
                    parse_mode='HTML'
                )
            
            log_admin_action(session, user.id, 'viewed_promocodes')
        
        elif query.data == 'admin_broadcast':
            # Рассылка
            total_users = session.query(User).count()
            active_users = session.query(User).filter(User.is_active == True).count()
            subscribed_users = session.query(Subscription).filter(Subscription.is_active == True).count()
            
            text = f"""<b>📢 Рассылка сообщений</b>

👥 Аудитория для рассылки:
• Всего пользователей: {total_users}
• Активных пользователей: {active_users}
• С подпиской: {subscribed_users}

<b>Способы рассылки:</b>

1. <b>Всем пользователям:</b>
<code>/broadcast_all Текст сообщения</code>

2. <b>Только с подпиской:</b>
<code>/broadcast_subscribed Текст сообщения</code>

3. <b>Только активным:</b>
<code>/broadcast_active Текст сообщения</code>

4. <b>По ID пользователей:</b>
<code>/broadcast_ids 123,456,789 Текст сообщения</code>

<b>Пример:</b>
<code>/broadcast_all Привет! Напоминаем о встрече завтра в 19:00.</code>"""
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_broadcast')
        
        elif query.data == 'admin_faq':
            # Управление FAQ
            text = "<b>❓ Управление FAQ</b>\n\n"
            text += "<b>Текущие вопросы FAQ:</b>\n"
            
            faq_items = [
                ("Как часто выходят лекции?", "faq_frequency"),
                ("Где проходит обучение?", "faq_platform"),
                ("Где посмотреть программу?", "faq_program"),
                ("Можно ли смотреть в записи?", "faq_recording"),
                ("Будут ли домашние задания?", "faq_homework"),
                ("Когда можно присоединиться?", "faq_join_time"),
                ("Можно ли вернуть деньги?", "faq_refund"),
                ("Можно ли оплатить в рассрочку?", "faq_installment"),
                ("Как получить бонусы?", "faq_bonuses")
            ]
            
            for question, callback in faq_items:
                text += f"• {question}\n"
            
            text += "\n<b>Для редактирования FAQ:</b>\n"
            text += "1. Измените файл <code>handlers/faq.py</code>\n"
            text += "2. Обновите клавиатуру в <code>keyboards.py</code>\n"
            text += "3. Перезапустите бота"
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_faq_management')
        
        elif query.data == 'admin_metrics':
            # Метрики
            week_ago = datetime.now() - timedelta(days=7)
            
            new_users = session.query(User).filter(User.joined_at >= week_ago).count()
            completed_payments = session.query(Payment).filter(
                Payment.created_at >= week_ago,
                Payment.status == 'completed'
            ).count()
            revenue_7_days = sum(p.amount for p in session.query(Payment).filter(
                Payment.created_at >= week_ago,
                Payment.status == 'completed'
            ).all()) / 100 if completed_payments else 0
            
            # Конверсия
            all_users_week = session.query(User).filter(User.joined_at >= week_ago).count()
            paid_users_week = session.query(User).join(Payment).filter(
                Payment.created_at >= week_ago,
                Payment.status == 'completed',
                User.joined_at >= week_ago
            ).distinct().count()
            
            conversion_rate = (paid_users_week / max(all_users_week, 1)) * 100
            
            text = f"""<b>📈 Метрики и аналитика</b>

📅 <b>За последние 7 дней:</b>
• Новых пользователей: {new_users}
• Оплат: {completed_payments}
• Выручка: {revenue_7_days:,.0f} ₽
• Конверсия: {conversion_rate:.1f}%

📊 <b>Детальная аналитика:</b>
Подробные метрики доступны в еженедельных отчетах.
Используйте раздел 'Отчеты' для получения детальной статистики.

🔍 <b>Дополнительные метрики:</b>
• Среднее время до первой оплаты
• Удержание пользователей
• Популярность тарифов
• Эффективность промокодов"""
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_metrics', {
                'new_users_7d': new_users,
                'revenue_7d': revenue_7_days,
                'conversion_rate': conversion_rate
            })
        
        elif query.data == 'admin_back':
            # Возврат в админ-панель
            text = "<b>🛠️ Панель администратора</b>\n\nВыберите раздел:"
            
            await query.message.edit_text(
                text,
                reply_markup=get_admin_keyboard(),
                parse_mode='HTML'
            )
        
        elif query.data.startswith('edit_meeting_menu') or query.data.startswith('delete_meeting_menu'):
            # Меню для редактирования/удаления встреч
            meetings = session.query(Meeting).order_by(Meeting.date_time).all()
            
            if not meetings:
                await query.message.edit_text(
                    "❌ Нет встреч для редактирования/удаления.",
                    reply_markup=get_meetings_list_keyboard()
                )
                return
            
            action = "редактирования" if "edit" in query.data else "удаления"
            
            text = f"<b>📋 Выберите встречу для {action}:</b>\n\n"
            
            await query.message.edit_text(
                text,
                reply_markup=get_meeting_selection_keyboard(
                    meetings, 
                    action_prefix='edit_' if "edit" in query.data else 'delete_'
                ),
                parse_mode='HTML'
            )
        
        elif query.data.startswith('edit_'):
            # Редактирование конкретной встречи
            try:
                meeting_id = int(query.data.split('_')[1])
                meeting = session.query(Meeting).filter_by(id=meeting_id).first()
                
                if not meeting:
                    await query.message.edit_text("❌ Встреча не найдена.")
                    return
                
                text = f"""<b>📅 Детали встречи:</b>

🏷️ <b>Название:</b> {meeting.title}
📅 <b>Дата и время:</b> {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
⏱️ <b>Продолжительность:</b> {meeting.duration} мин
📝 <b>Описание:</b> {meeting.description or 'нет'}
🔗 <b>Zoom ссылка:</b> {'✅ есть' if meeting.zoom_link else '❌ нет'}
📊 <b>Статус:</b> {'✅ активна' if meeting.is_active else '⏸️ неактивна'}

🆔 <b>ID встречи:</b> {meeting.id}"""
                
                await query.message.edit_text(
                    text,
                    reply_markup=get_meeting_detail_keyboard(meeting_id),
                    parse_mode='HTML'
                )
                
                log_admin_action(session, user.id, 'viewed_meeting_details', {
                    'meeting_id': meeting_id,
                    'meeting_title': meeting.title
                })
                
            except (ValueError, IndexError) as e:
                logger.error(f"Ошибка при разборе meeting_id: {e}")
                await query.message.edit_text("❌ Ошибка при обработке запроса.")
        
        elif query.data.startswith('add_zoom_'):
            # Добавление Zoom ссылки
            try:
                meeting_id = int(query.data.split('_')[2])
                meeting = session.query(Meeting).filter_by(id=meeting_id).first()
                
                if not meeting:
                    await query.message.edit_text("❌ Встреча не найдена.")
                    return
                
                text = f"""<b>🔗 Добавление Zoom ссылки</b>

Для встречи: <b>{meeting.title}</b>
Дата: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}

Отправьте Zoom ссылку в следующем сообщении.

<b>Формат:</b>
https://zoom.us/j/1234567890
или
https://us04web.zoom.us/j/1234567890

<b>Пароль (если есть) можно добавить отдельно.</b>"""
                
                context.user_data['adding_zoom_to'] = meeting_id
                
                await query.message.edit_text(
                    text,
                    reply_markup=get_cancel_keyboard('meetings_list'),
                    parse_mode='HTML'
                )
                
                log_admin_action(session, user.id, 'started_adding_zoom', {
                    'meeting_id': meeting_id
                })
                
            except (ValueError, IndexError) as e:
                logger.error(f"Ошибка при разборе meeting_id для Zoom: {e}")
                await query.message.edit_text("❌ Ошибка при обработке запроса.")
        
        elif query.data == 'create_promocode':
            # Создание промокода
            try:
                from handlers.admin_promocodes import start_create_promocode
                await start_create_promocode(update, context)
            except ImportError as e:
                logger.error(f"Не удалось импортировать start_create_promocode: {e}")
                await query.message.edit_text(
                    "❌ Функция создания промокодов недоступна.",
                    reply_markup=get_admin_back_keyboard()
                )
    
    except Exception as e:
        logger.error(f"Ошибка в админ-панели: {e}", exc_info=True)
        await query.message.edit_text(
            "❌ Произошла ошибка при обработке запроса.",
            parse_mode='HTML'
        )
    finally:
        session.close()


# ========== УДАЛЯЕМ ДУБЛИРУЮЩУЮ РЕГИСТРАЦИЮ ОБРАБОТЧИКОВ ==========
# ВАЖНО: НЕ РЕГИСТРИРУЕМ ОБРАБОТЧИКИ ЗДЕСЬ!
# Все обработчики регистрируются в bot.py в правильном порядке

# Функция register_admin_handlers ПОЛНОСТЬЮ УДАЛЕНА!
# Больше никаких конфликтов с регистрацией!