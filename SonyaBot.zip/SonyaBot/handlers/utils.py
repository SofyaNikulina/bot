# handlers/utils.py - ПОЛНОСТЬЮ ИСПРАВЛЕННАЯ ВЕРСИЯ

from telegram import Update
from telegram.ext import ContextTypes, filters
from database import get_session, User, Promocode
from config import Config
import logging
import re
from datetime import datetime
from handlers.start import complete_registration
from handlers.start import handle_city_selection as start_handle_city_selection
from handlers.start import handle_profession_selection as start_handle_profession_selection


logger = logging.getLogger(__name__)

# ========== ОБРАБОТКА ГОРОДОВ ==========

async def handle_city_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик выбора города"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    city = query.data.replace('city_', '')
    
    logger.info(f"📍 Пользователь {user.id} выбрал город: {city}")
    
    if city == 'other':
        # Запрос ввода другого города
        from keyboards import get_other_city_keyboard
        
        text = """🏙️ <b>Введите ваш город:</b>
        
Пожалуйста, напишите название вашего города."""
        
        try:
            await query.message.edit_text(
                text,
                reply_markup=get_other_city_keyboard(),
                parse_mode='HTML'
            )
        except:
            await query.message.reply_text(
                text,
                reply_markup=get_other_city_keyboard(),
                parse_mode='HTML'
            )
        
        context.user_data['awaiting_city_input'] = True
        return
    
    # Сохраняем город в БД
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if db_user:
            db_user.city = city
            session.commit()
            logger.info(f"✅ Город сохранен для пользователя {user.id}: {city}")
        else:
            logger.warning(f"Пользователь {user.id} не найден при сохранении города")
    except Exception as e:
        logger.error(f"Ошибка сохранения города: {e}")
        session.rollback()
        return
    finally:
        session.close()
    
    # Удаляем сообщение с выбором города
    try:
        await query.message.delete()
    except Exception as e:
        logger.warning(f"Не удалось удалить сообщение: {e}")
    
    # Запрашиваем профессию через новое сообщение
    await context.bot.send_message(
        chat_id=query.message.chat_id,
        text=f"✅ Выбран город: <b>{city}</b>\n\n"
             f"<b>Следующий шаг:</b> Выберите вашу профессиональную сферу:",
        reply_markup=get_professions_keyboard(),
        parse_mode='HTML'
    )


async def handle_other_city_input(update: Update, context: ContextTypes.DEFAULT_TYPE, city_text):
    """Обработчик ввода другого города"""
    user = update.effective_user
    
    if not city_text or len(city_text) < 2:
        await update.message.reply_text(
            "❌ Пожалуйста, введите корректное название города.",
            parse_mode='HTML'
        )
        return
    
    # Сохраняем город в БД
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if db_user:
            db_user.city = city_text
            session.commit()
            logger.info(f"✅ Город сохранен для пользователя {user.id}: {city_text}")
        else:
            logger.warning(f"Пользователь {user.id} не найден при сохранении города")
    except Exception as e:
        logger.error(f"Ошибка сохранения города: {e}")
        session.rollback()
        return
    finally:
        session.close()
    
    # Убираем состояние ожидания
    if 'awaiting_city_input' in context.user_data:
        del context.user_data['awaiting_city_input']
    
    # Запрашиваем профессию
    from keyboards import get_professions_keyboard
    
    await update.message.reply_text(
        f"✅ Выбран город: <b>{city_text}</b>\n\n"
        f"<b>Следующий шаг:</b> Выберите вашу профессиональную сферу:",
        reply_markup=get_professions_keyboard(),
        parse_mode='HTML'
    )


# ========== ОБРАБОТКА ПРОФЕССИЙ ==========

# Словарь профессий для преобразования ID в название
PROFESSIONS_DICT = {
    'entrepreneur': 'Предпринимательница',
    'manager': 'Работаю на линейной должности (менеджер)',
    'executive': 'Работаю на управляющей позиции',
    'self_employed': 'Самозанятая',
    'student': 'Учусь / студентка',
    'not_working': 'Не работаю',
    'maternity': 'В декрете'
}

async def handle_profession_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик выбора профессии"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    profession_id = query.data.replace('prof_', '')
    
    logger.info(f"💼 Пользователь {user.id} выбрал профессию ID: {profession_id}")
    
    # Получаем название профессии по ID
    profession_name = PROFESSIONS_DICT.get(profession_id, profession_id)
    
    # Сохраняем профессию в БД
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if db_user:
            db_user.profession = profession_name
            session.commit()
            logger.info(f"✅ Профессия сохранена для пользователя {user.id}: {profession_name}")
        else:
            logger.warning(f"Пользователь {user.id} не найден при сохранении профессии")
    except Exception as e:
        logger.error(f"Ошибка сохранения профессии: {e}")
        session.rollback()
        return
    finally:
        session.close()
    
    # Удаляем сообщение с выбором профессии
    try:
        await query.message.delete()
    except Exception as e:
        logger.warning(f"Не удалось удалить сообщение: {e}")
    
    # Отправляем сообщение об успехе
    await context.bot.send_message(
        chat_id=query.message.chat_id,
        text=f"✅ Выбрана сфера: <b>{profession_name}</b>",
        parse_mode='HTML'
    )
    
    # ЗАВЕРШАЕМ РЕГИСТРАЦИЮ и показываем главное меню
    await complete_registration(update, context)


# ========== ОБРАБОТКА ВВОДА EMAIL ==========

async def handle_email_input_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик ввода email для чека (вызывается из текстовых сообщений)"""
    if not update.message or not update.message.text:
        return
    
    user = update.effective_user
    email = update.message.text.strip().lower()
    
    # Простая валидация email
    if '@' not in email or '.' not in email or len(email) < 5:
        await update.message.reply_text(
            "❌ <b>Пожалуйста, введите корректный email адрес.</b>\n\n"
            "Пример: <code>name@example.com</code>\n\n"
            "Email необходим для отправки электронного чека 54-ФЗ.",
            parse_mode='HTML'
        )
        return
    
    # Сохраняем email в контексте
    context.user_data['receipt_email'] = email
    
    # Обновляем email пользователя в БД
    engine = context.bot_data.get('engine')
    if engine:
        session = get_session(engine)
        try:
            db_user = session.query(User).filter_by(telegram_id=user.id).first()
            if db_user:
                db_user.email = email
                session.commit()
                logger.info(f"✅ Email сохранен в БД для пользователя {user.id}: {email}")
            else:
                logger.warning(f"Пользователь {user.id} не найден в БД при сохранении email")
        except Exception as e:
            logger.error(f"❌ Ошибка сохранения email в БД: {e}")
            session.rollback()
        finally:
            session.close()
    
    # Показываем информацию о тарифе с кнопками оплаты
    tariff_key = context.user_data.get('selected_tariff')
    tariff_info = context.user_data.get('selected_tariff_info')
    
    if not tariff_key or not tariff_info:
        await update.message.reply_text(
            "❌ Произошла ошибка. Пожалуйста, выберите тариф заново через меню.",
            parse_mode='HTML'
        )
        # Очищаем контекст
        for key in ['selected_tariff', 'selected_tariff_info', 'receipt_email', 'awaiting_email_for_receipt']:
            if key in context.user_data:
                del context.user_data[key]
        return
    
    price = tariff_info['price'] / 100
    
    text = f"""✅ <b>Email для чека сохранен:</b> <code>{email}</code>
    
<b>Выбран тариф:</b> {tariff_info['label']}
    
<b>Цена:</b> {price:,.0f} ₽
    
<b>Входит в тариф:</b>
• Еженедельные лекции и встречи в Zoom
• Доступ к записям
• Закрытое сообщество клуба
• Дополнительные материалы"""
    
    if tariff_key == '12_months':
        text += "\n\n🎁 <b>Бонусы:</b> рабочая тетрадь А4 и наклейки"
    
    text += "\n\nВы можете применить промокод или перейти к оплате."
    
    # Используем клавиатуру оплаты
    from keyboards import get_payment_keyboard
    keyboard = get_payment_keyboard(tariff_key)
    
    await update.message.reply_text(
        text,
        reply_markup=keyboard,
        parse_mode='HTML'
    )
    
    # Убираем состояние ожидания
    if 'awaiting_email_for_receipt' in context.user_data:
        del context.user_data['awaiting_email_for_receipt']
    
    logger.info(f"✅ Email введен пользователем {user.id}, показаны кнопки оплаты")


# ========== ОБРАБОТКА ДАННЫХ ДЛЯ ПОДАРКОВ ==========

async def handle_shipping_info_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка данных для отправки подарков (вызывается из текстовых сообщений)"""
    if not update.message or not update.message.text:
        return
    
    user = update.effective_user
    text = update.message.text.strip()
    
    # Проверяем, ожидаем ли мы данные для подарков
    if not context.user_data.get('awaiting_shipping_info'):
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        return
    
    session = get_session(engine)
    
    try:
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if not db_user:
            logger.error(f"Пользователь {user.id} не найден в БД при обработке данных для подарков")
            await update.message.reply_text("❌ Произошла ошибка. Пожалуйста, обратитесь к администратору.")
            return
        
        # Проверяем, какое поле запрашиваем
        if context.user_data.get('awaiting_full_name'):
            # Сохраняем ФИО
            if len(text) < 5:
                await update.message.reply_text(
                    "❌ <b>Пожалуйста, введите полное ФИО.</b>\n\n"
                    "Пример: <code>Иванова Мария Сергеевна</code>",
                    parse_mode='HTML'
                )
                return
            
            db_user.full_name = text
            session.commit()
            
            # Запрашиваем адрес
            context.user_data['awaiting_address'] = True
            del context.user_data['awaiting_full_name']
            
            await update.message.reply_text(
                "✅ <b>ФИО сохранено!</b>\n\n"
                "📍 <b>Теперь введите ваш адрес для отправки подарков:</b>\n\n"
                "<b>Формат:</b> индекс, город, улица, дом, квартира\n"
                "<b>Пример:</b> <code>123456, Москва, ул. Примерная, д. 10, кв. 25</code>",
                parse_mode='HTML'
            )
            
            logger.info(f"✅ ФИО сохранено для пользователя {user.id}: {text}")
            
        elif context.user_data.get('awaiting_address'):
            # Сохраняем адрес
            if len(text) < 10:
                await update.message.reply_text(
                    "❌ <b>Пожалуйста, введите полный адрес.</b>\n\n"
                    "Пример: <code>123456, Москва, ул. Примерная, д. 10, кв. 25</code>",
                    parse_mode='HTML'
                )
                return
            
            db_user.shipping_address = text
            session.commit()
            
            # Сохраняем в подписке
            subscription_id = context.user_data.get('active_subscription_id')
            subscription = None
            if subscription_id:
                from database import Subscription
                subscription = session.query(Subscription).filter_by(id=subscription_id).first()
                if subscription:
                    subscription.bonuses_shipping = "ожидает отправки"
                    subscription.bonuses_sent = False
                    session.commit()
            
            # Все данные собраны
            del context.user_data['awaiting_shipping_info']
            del context.user_data['awaiting_address']
            tariff = context.user_data.get('active_tariff', '12_months')
            
            # Отправляем финальное сообщение с кнопкой Главное меню
            from keyboards import get_after_payment_keyboard_with_main_menu
            
            end_date_str = subscription.end_date.strftime('%d.%m.%Y') if subscription and subscription.end_date else 'дата не определена'
            
            success_text = f"""🎉 <b>Спасибо! Все данные сохранены 🤍</b>

<b>Ваш доступ к тарифу «{tariff}» активирован!</b>
<b>Действует до: {end_date_str}</b>

<b>Для отправки подарков:</b>
👤 <b>ФИО:</b> {db_user.full_name}
📦 <b>Адрес:</b> {db_user.shipping_address}

🎁 <b>Бонусы:</b> рабочая тетрадь А4 и наклейки
📮 <b>Статус отправки:</b> ожидает отправки

Подарки будут отправлены в течение 14 рабочих дней.
Вы получите уведомление с трек-номером.

Не удаляй бот — здесь мы будем напоминать о встречах и важных событиях."""
            
            keyboard = get_after_payment_keyboard_with_main_menu(tariff)
            
            await update.message.reply_text(
                success_text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            # Очищаем остальной контекст
            for key in ['active_subscription_id', 'active_tariff']:
                if key in context.user_data:
                    del context.user_data[key]
            
            logger.info(f"✅ Данные для подарков сохранены: пользователь {user.id}, ФИО: {db_user.full_name}, адрес: {db_user.shipping_address}")
            
            # Уведомление админам о получении данных для подарков
            admin_message = f"""🎁 ПОЛУЧЕНЫ ДАННЫЕ ДЛЯ ОТПРАВКИ ПОДАРКОВ

👤 Пользователь: @{db_user.username or 'без username'} ({db_user.first_name or ''})
📧 Email: {db_user.email or 'не указан'}
📞 Телефон: {db_user.phone_number or 'не указан'}
👤 ФИО: {db_user.full_name}
📍 Адрес: {db_user.shipping_address}
📦 Тариф: {tariff}
📅 Доступ до: {end_date_str}

✅ Готово к отправки!"""
            
            for admin_id in Config.ADMIN_IDS:
                try:
                    from handlers.messages import safe_send_message
                    await safe_send_message(
                        context.bot,
                        admin_id,
                        admin_message
                    )
                except Exception as e:
                    logger.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
        
    except Exception as e:
        logger.error(f"❌ Ошибка сохранения данных для подарков: {e}", exc_info=True)
        session.rollback()
        await update.message.reply_text(
            "❌ Произошла ошибка при сохранении данных. Пожалуйста, попробуйте еще раз или обратитесь к администратору."
        )
    finally:
        session.close()


# ========== ОБРАБОТКА ПРОМОКОДОВ ==========

async def handle_promocode_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик ввода промокода"""
    if not update.message or not update.message.text:
        return
    
    promocode_text = update.message.text.strip().upper()
    user = update.effective_user
    
    # БАЗОВАЯ ПРОВЕРКА: Если текст слишком длинный или содержит пробелы - это не промокод
    if len(promocode_text) > 30 or ' ' in promocode_text:
        # Сбрасываем флаг ожидания промокода и передаем управление дальше
        if 'awaiting_promocode' in context.user_data:
            del context.user_data['awaiting_promocode']
        # Возвращаем False, чтобы сообщение обработалось как обычное
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        return
    
    session = get_session(engine)
    
    try:
        # Ищем промокод в базе
        promocode = session.query(Promocode).filter_by(code=promocode_text).first()
        
        if not promocode:
            await update.message.reply_text(
                f"❌ Промокод <code>{promocode_text}</code> не найден.",
                parse_mode='HTML'
            )
            # НЕ сбрасываем awaiting_promocode, чтобы пользователь мог ввести другой
            return
        
        # Проверяем активность
        if not promocode.is_active:
            await update.message.reply_text(
                f"❌ Промокод <code>{promocode_text}</code> неактивен.",
                parse_mode='HTML'
            )
            return
        
        # Проверяем срок действия
        if promocode.valid_to and promocode.valid_to < datetime.now():
            await update.message.reply_text(
                f"❌ Промокод <code>{promocode_text}</code> истек.",
                parse_mode='HTML'
            )
            return
        
        # Проверяем лимит использований
        if promocode.used_count >= promocode.max_uses:
            await update.message.reply_text(
                f"❌ Промокод <code>{promocode_text}</code> уже использован максимальное количество раз.",
                parse_mode='HTML'
            )
            return
        
        # Сохраняем промокод в контексте
        context.user_data['applied_promocode'] = promocode_text
        context.user_data['promocode_data'] = {
            'id': promocode.id,
            'discount_amount': promocode.discount_amount,
            'discount_percent': promocode.discount_percent,
            'max_uses': promocode.max_uses,
            'used_count': promocode.used_count
        }
        
        # ВАЖНО: Сбрасываем флаг ожидания промокода!
        if 'awaiting_promocode' in context.user_data:
            del context.user_data['awaiting_promocode']
        
        # Показываем информацию о скидке
        discount_text = ""
        if promocode.discount_amount > 0:
            discount_text = f"{promocode.discount_amount/100:.0f} ₽"
        elif promocode.discount_percent > 0:
            discount_text = f"{promocode.discount_percent}%"
        
        await update.message.reply_text(
            f"✅ Промокод <code>{promocode_text}</code> применен!\n\n"
            f"Скидка: {discount_text}",
            parse_mode='HTML'
        )
        
        # Возвращаем к оплате с обновленной информацией
        tariff = context.user_data.get('selected_tariff')
        if tariff:
            tariff_info = Config.TARIFFS.get(tariff)
            if tariff_info:
                # Рассчитываем новую цену с учетом скидки
                original_price = tariff_info['price'] / 100
                promocode_data = context.user_data.get('promocode_data', {})
                discount = 0
                
                if promocode_data.get('discount_amount', 0) > 0:
                    discount = promocode_data['discount_amount'] / 100
                elif promocode_data.get('discount_percent', 0) > 0:
                    discount = original_price * (promocode_data['discount_percent'] / 100)
                
                final_price = original_price - discount
                
                text = f"""✅ <b>Промокод применен!</b>

<b>Тариф:</b> {tariff_info['label']}
<b>Промокод:</b> {promocode_text}
<b>Исходная цена:</b> {original_price:,.0f} ₽
<b>Скидка:</b> {discount:,.0f} ₽
<b>Итоговая цена:</b> {final_price:,.0f} ₽

Вы можете перейти к оплате или ввести другой промокод."""
                
                # Используем клавиатуру оплаты
                from keyboards import get_payment_keyboard
                keyboard = get_payment_keyboard(tariff, promocode_applied=True, promocode=promocode_text)
                
                await update.message.reply_text(
                    text,
                    reply_markup=keyboard,
                    parse_mode='HTML'
                )
                
                logger.info(f"✅ Промокод {promocode_text} применен, показана новая цена")
        
    except Exception as e:
        logger.error(f"Ошибка обработки промокода: {e}")
        await update.message.reply_text("❌ Произошла ошибка при обработке промокода.")
    finally:
        session.close()


# ========== ОБРАБОТЧИК ВОЗВРАТА К ТАРИФАМ ==========

async def handle_back_to_tariffs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик возврата к выбору тарифа - ОЧИЩАЕТ ВСЕ СОСТОЯНИЯ"""
    query = update.callback_query
    await query.answer()
    
    # ОЧИЩАЕМ ВСЕ СОСТОЯНИЯ ОЖИДАНИЯ
    states_to_clear = [
        'awaiting_promocode',
        'awaiting_email_for_receipt',
        'awaiting_city_input',
        'awaiting_shipping_info',
        'awaiting_full_name',
        'awaiting_address',
        'selected_tariff',
        'selected_tariff_info',
        'receipt_email',
        'applied_promocode',
        'promocode_data'
    ]
    
    for key in states_to_clear:
        if key in context.user_data:
            del context.user_data[key]
    
    # Показываем клавиатуру с тарифами
    from keyboards import get_tariffs_keyboard
    
    text = """💰 <b>Выберите тариф:</b>

✨ <b>1 месяц — 5000 ₽</b>
• Еженедельные лекции и встречи
• Доступ к записям
• Закрытое сообщество

✨ <b>12 месяцев — 40000 ₽</b>
• Всё из тарифа 1 месяц
• Рабочая тетрадь А4 и наклейки в подарок
• Заморозка до 30 дней"""
    
    try:
        await query.message.edit_text(
            text,
            reply_markup=get_tariffs_keyboard(),
            parse_mode='HTML'
        )
    except:
        await query.message.reply_text(
            text,
            reply_markup=get_tariffs_keyboard(),
            parse_mode='HTML'
        )
    
    logger.info(f"🔄 Пользователь {query.from_user.id} вернулся к выбору тарифа")


# ========== ОСНОВНОЙ ОБРАБОТЧИК ТЕКСТА ==========

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Главный обработчик текстовых сообщений - ОБНОВЛЕН"""
    user = update.effective_user
    message_text = update.message.text
    
    logger.info(f"📝 Текст от пользователя {user.id}: {message_text[:100]}...")
    
    # Проверяем состояния ожидания в порядке приоритета
    
    # 1. Ожидание другого города
    if context.user_data.get('awaiting_city_input'):
        await handle_other_city_input(update, context, message_text)
        return
    
    # 2. Ожидание email для чека
    elif context.user_data.get('awaiting_email_for_receipt'):
        await handle_email_input_text(update, context)
        return
    
    # 3. Ожидание данных для подарков (ФИО или адрес)
    elif context.user_data.get('awaiting_shipping_info'):
        await handle_shipping_info_text(update, context)
        return
    
    # 4. Ожидание промокода
    elif context.user_data.get('awaiting_promocode'):
        # Вызываем обработчик промокода
        await handle_promocode_text(update, context)
        # Если обработчик вернул управление (промокод не распознан), 
        # сообщение уже обработано или проигнорировано
        return
    
    # 5. Обработка Zoom ссылок от админов
    elif user.id in Config.ADMIN_IDS:
        # Проверяем, не ожидается ли ручной ввод Zoom ссылки
        if 'adding_zoom_to' in context.user_data and 'zoom_mode' in context.user_data:
            # Пропускаем обработку, будет выполнена в admin_meetings.py
            return
        
        # Проверяем, является ли сообщение Zoom ссылкой
        if 'zoom.us' in message_text or 'zoom.us/j/' in message_text:
            from handlers.admin_meetings import MeetingsManager
            processed = await MeetingsManager.process_zoom_link(update, context)
            if processed:
                return
    
    # 6. Сообщение для менеджера (для всех пользователей)
    if len(message_text.strip()) > 0:
        try:
            from handlers.messages import forward_user_message
            await forward_user_message(update, context)
        except Exception as e:
            logger.error(f"Ошибка при пересылке сообщения: {e}")
            await update.message.reply_text(
                "❌ Не удалось отправить сообщение менеджеру. Попробуйте позже."
            )


# ========== ОБРАБОТКА ZOOM ССЫЛОК ==========

async def handle_zoom_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик Zoom ссылок от админов"""
    user = update.effective_user
    
    # Проверяем, что отправитель - админ
    if user.id not in Config.ADMIN_IDS:
        return
    
    message_text = update.message.text
    
    # Проверяем, является ли сообщение Zoom ссылкой
    if 'zoom.us' in message_text or 'zoom.us/j/' in message_text:
        from handlers.admin_meetings import MeetingsManager
        processed = await MeetingsManager.process_zoom_link(update, context)
        if processed:
            return
    
    # Если не Zoom ссылка и не обработано, передаем в основной обработчик
    await handle_text_message(update, context)


# ========== ОБРАБОТКА НЕИЗВЕСТНЫХ КОМАНД ==========

async def handle_unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик неизвестных команд"""
    await update.message.reply_text(
        "❌ Неизвестная команда. Используйте меню для навигации."
    )


# ========== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ==========

async def handle_back_to_cities(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик возврата к выбору города"""
    query = update.callback_query
    await query.answer()
    
    from keyboards import get_cities_keyboard
    
    text = """📍 <b>Пожалуйста, укажите ваш город проживания:</b>
    
Это поможет нам лучше понимать нашу аудиторию и планировать офлайн-встречи."""
    
    try:
        await query.message.edit_text(
            text,
            reply_markup=get_cities_keyboard(),
            parse_mode='HTML'
        )
    except:
        await query.message.reply_text(
            text,
            reply_markup=get_cities_keyboard(),
            parse_mode='HTML'
        )
    
    # Убираем состояние ожидания ввода другого города
    if 'awaiting_city_input' in context.user_data:
        del context.user_data['awaiting_city_input']


async def handle_back_to_main(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик возврата в главное меню - ОЧИЩАЕТ ВСЕ СОСТОЯНИЯ"""
    query = update.callback_query
    await query.answer()
    
    # ОЧИЩАЕМ ВСЕ СОСТОЯНИЯ ОЖИДАНИЯ
    states_to_clear = [
        'awaiting_promocode',
        'awaiting_email_for_receipt',
        'awaiting_city_input',
        'awaiting_shipping_info',
        'awaiting_full_name',
        'awaiting_address',
        'selected_tariff',
        'selected_tariff_info',
        'receipt_email',
        'applied_promocode',
        'promocode_data'
    ]
    
    for key in states_to_clear:
        if key in context.user_data:
            del context.user_data[key]
    
    # Показываем главное меню
    from keyboards import get_main_menu_keyboard
    
    text = """💙 <b>Добро пожаловать в «Бестужевки»!</b>

Образовательный проект для женщин. 
Мы объединяем историю, искусство, этикет и философию, 
чтобы помочь вам развиваться и находить единомышленниц.

Выберите раздел в меню ниже 👇"""
    
    try:
        await query.message.edit_text(
            text,
            reply_markup=get_main_menu_keyboard(),
            parse_mode='HTML'
        )
    except:
        await query.message.reply_text(
            text,
            reply_markup=get_main_menu_keyboard(),
            parse_mode='HTML'
        )
    
    logger.info(f"🏠 Пользователь {query.from_user.id} вернулся в главное меню")


def is_valid_email(email: str) -> bool:
    """Проверка валидности email"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None


def is_valid_russian_address(address: str) -> bool:
    """Базовая проверка российского адреса"""
    # Проверяем, что адрес содержит хотя бы город и улицу/дом
    address_lower = address.lower()
    
    # Проверяем наличие индекса (6 цифр)
    if re.search(r'\b\d{6}\b', address):
        return True
    
    # Проверяем наличие города (должно быть после запятой или в начале)
    if re.search(r'(г\.|город|гор\.|москва|спб|санкт-петербург)', address_lower):
        return True
    
    # Проверяем наличие улицы
    if re.search(r'(ул\.|улица|пр\.|проспект|пр-т|просп|б-р|бульвар|пер\.|переулок)', address_lower):
        return True
    
    # Проверяем наличие номера дома
    if re.search(r'(д\.|дом|д\.|корп\.|корпус|к\.|стр\.|строение|лит\.|литер)', address_lower):
        return True
    
    # Если адрес достаточно длинный, считаем его валидным
    return len(address) >= 20


# ========== КОМАНДА ПОМОЩИ ==========

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /help"""
    help_text = """🤖 *Помощь по боту «Бестужевки»* 💙

*Основные команды:*
/start - Начать работу с ботом
/help - Показать это сообщение
/admin - Панель администратора (только для админов)

*Меню бота:*
🏛️ О клубе - Узнать о формате клуба
📅 Формат/расписание - Посмотреть расписание встреч
💰 Тарифы - Выбрать подписку
👩‍🏫 Спикеры - Познакомиться с преподавателями
❓ FAQ - Ответы на частые вопросы
👤 Связаться с менеджером - Задать вопрос
📋 Программы - Посмотреть план занятий

*Оплата:*
• Выберите тариф в меню
• Оплатите через Тинькофф
• Получите доступ к встречам и материалам

*Если возникли проблемы:*
1. Попробуйте перезапустить бот командой /start
2. Обратитесь к менеджеру через меню
3. Напишите в поддержку

*Техническая поддержка:*
@support_username (укажите реальный username)"""

    await update.message.reply_text(help_text, parse_mode='Markdown')


# Импортируем функции из keyboards внутри функций, где они нужны
from keyboards import get_professions_keyboard