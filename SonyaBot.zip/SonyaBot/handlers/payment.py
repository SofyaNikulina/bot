# handlers/payment.py - ИСПРАВЛЕННАЯ ВЕРСИЯ С ПРОДОЛЖЕНИЕМ ПРЕРВАННОГО ПРОЦЕССА

from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from database import get_session, User, Payment, Subscription, PromoUsage, Promocode
from keyboards import get_payment_keyboard, get_tariffs_keyboard, get_back_keyboard, get_after_payment_keyboard_with_main_menu, get_main_menu_keyboard, get_back_to_main_keyboard
from config import Config
from datetime import datetime, timedelta
import logging
import json
import time

logger = logging.getLogger(__name__)

# ========== ТИНЬКОФФ ОПЛАТА ==========
try:
    from tinkoff_api import tbank
    logger.info("✅ Модуль tinkoff_api загружен")
except ImportError as e:
    logger.error(f"❌ Модуль tinkoff_api не найден: {e}")
    tbank = None

# ========== ФУНКЦИЯ: ПРОВЕРКА СТАТУСА ПО КОМАНДЕ С ПРОДОЛЖЕНИЕМ ПРОЦЕССА ==========
async def check_payment_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда для проверки статуса последнего платежа пользователя с возможностью продолжить прерванный процесс"""
    user = update.effective_user
    logger.info(f"🔍 Проверка статуса платежа по команде от пользователя {user.id}")
    
    engine = context.bot_data.get('engine')
    if not engine:
        await update.message.reply_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        # Находим пользователя в БД
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        
        if not db_user:
            await update.message.reply_text(
                "❌ Вы еще не зарегистрированы в системе.\n"
                "Используйте /start для регистрации."
            )
            return
        
        # Ищем последний платеж пользователя
        last_payment = session.query(Payment).filter_by(
            user_id=db_user.id
        ).order_by(Payment.created_at.desc()).first()
        
        if not last_payment:
            await update.message.reply_text(
                "📭 У вас пока нет платежей.\n"
                "Выберите тариф в меню для оплаты."
            )
            return
        
        # Проверяем статус платежа в Тинькофф, если он еще в обработке
        if last_payment.status == 'pending' and tbank and last_payment.provider_payment_charge_id:
            # Проверяем актуальный статус в Тинькофф
            payment_id = last_payment.provider_payment_charge_id
            status_result = tbank.check_payment_status(payment_id)
            
            if status_result and status_result.get("success"):
                status = status_result.get("status")
                
                # Если платеж подтвержден в Тинькофф, но в БД еще pending - активируем
                if status in ["CONFIRMED", "AUTHORIZED"] and last_payment.status != 'completed':
                    logger.info(f"✅ Обнаружен неподтвержденный успешный платеж! PaymentId={payment_id}, активирую подписку")
                    
                    # Создаем фиктивный update для process_tinkoff_successful_payment
                    class FakeQuery:
                        def __init__(self, message):
                            self.message = message
                        async def answer(self):
                            pass
                    
                    fake_update = Update(update.update_id)
                    fake_update.callback_query = FakeQuery(update.message)
                    
                    # Активируем подписку
                    await process_tinkoff_successful_payment(
                        fake_update, context, payment_id, status_result
                    )
                    
                    # Обновляем данные после активации
                    session.refresh(last_payment)
                    session.refresh(db_user)
        
        # Получаем название тарифа
        tariff_name = last_payment.tariff
        if last_payment.tariff in Config.TARIFFS:
            tariff_name = Config.TARIFFS[last_payment.tariff]['label']
        
        # Проверяем, есть ли активная подписка
        subscription = session.query(Subscription).filter_by(
            user_id=db_user.id,
            is_active=True
        ).first()
        
        # Формируем сообщение в зависимости от статуса
        if last_payment.status == 'completed':
            # Платеж успешен - проверяем подписку
            if subscription:
                # Подписка активна
                status_text = "✅ Оплачен"
                message = f"""💳 **Статус вашего платежа**

📊 **Статус:** {status_text}
💰 **Сумма:** {last_payment.amount/100} ₽
🏷️ **Тариф:** {tariff_name}
📅 **Дата:** {last_payment.created_at.strftime('%d.%m.%Y %H:%M')}
"""
                
                message += f"\n✅ **Подписка активна до:** {subscription.end_date.strftime('%d.%m.%Y')}"
                
                if subscription.end_date < datetime.now():
                    message += "\n⚠️ Срок подписки истек. Продлите подписку в меню."
                else:
                    days_left = (subscription.end_date - datetime.now()).days
                    message += f"\n⏳ **Осталось дней:** {days_left}"
                
                # Проверяем, нужно ли заполнить данные для подарков (годовой тариф)
                if last_payment.tariff == '12_months' and (not db_user.full_name or not db_user.shipping_address):
                    message += f"""

📦 **Для получения подарков (рабочая тетрадь и наклейки) необходимо заполнить данные!**

✍️ Нажмите кнопку ниже, чтобы заполнить ФИО и адрес для отправки."""
                    
                    keyboard = InlineKeyboardMarkup([
                        [InlineKeyboardButton("📦 Заполнить данные для подарков", callback_data='fill_gift_data')],
                        [InlineKeyboardButton("🏠 Главное меню", callback_data='back_to_main')]
                    ])
                else:
                    is_admin = user.id in Config.ADMIN_IDS
                    keyboard = get_main_menu_keyboard(is_admin)
                
            else:
                # Платеж успешен, но подписка не создана - нужно создать
                logger.warning(f"⚠️ Платеж успешен, но подписка не найдена для пользователя {user.id}")
                
                message = f"""✅ **Платеж успешен, но подписка не активирована!**

💰 **Сумма:** {last_payment.amount/100} ₽
🏷️ **Тариф:** {tariff_name}
📅 **Дата:** {last_payment.created_at.strftime('%d.%m.%Y %H:%M')}

⚠️ **Возникла проблема с активацией подписки.**
Нажмите кнопку ниже, чтобы активировать подписку вручную."""
                
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Активировать подписку", callback_data=f'activate_subscription_{last_payment.id}')],
                    [InlineKeyboardButton("🏠 Главное меню", callback_data='back_to_main')]
                ])
        
        elif last_payment.status == 'pending':
            # Платеж в ожидании - проверяем в Тинькофф
            status_text = "⏳ Ожидает подтверждения"
            message = f"""💳 **Статус вашего платежа**

📊 **Статус:** {status_text}
💰 **Сумма:** {last_payment.amount/100} ₽
🏷️ **Тариф:** {tariff_name}
📅 **Дата:** {last_payment.created_at.strftime('%d.%m.%Y %H:%M')}
"""
            
            payment_id = last_payment.provider_payment_charge_id or last_payment.order_id
            if payment_id:
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Проверить статус еще раз", callback_data=f'check_status_button_{payment_id}')],
                    [InlineKeyboardButton("🏠 Главное меню", callback_data='back_to_main')]
                ])
            else:
                keyboard = get_back_to_main_keyboard()
            
            await update.message.reply_text(
                message,
                parse_mode='Markdown',
                reply_markup=keyboard
            )
            return
        
        else:
            # Остальные статусы
            status_map = {
                'failed': '❌ Ошибка оплаты',
                'cancelled': '🚫 Отменен',
                'refunded': '💰 Возвращен'
            }
            status_text = status_map.get(last_payment.status, '❓ Неизвестный статус')
            
            message = f"""💳 **Статус вашего платежа**

📊 **Статус:** {status_text}
💰 **Сумма:** {last_payment.amount/100} ₽
🏷️ **Тариф:** {tariff_name}
📅 **Дата:** {last_payment.created_at.strftime('%d.%m.%Y %H:%M')}
"""
            is_admin = user.id in Config.ADMIN_IDS
            keyboard = get_main_menu_keyboard(is_admin)
        
        await update.message.reply_text(
            message,
            parse_mode='Markdown',
            reply_markup=keyboard
        )
        
    except Exception as e:
        logger.error(f"❌ Ошибка при проверке статуса платежа: {e}", exc_info=True)
        await update.message.reply_text(
            "❌ Произошла ошибка при проверке статуса платежа.\n"
            "Пожалуйста, обратитесь к администратору."
        )
    finally:
        session.close()


# ========== ОБРАБОТЧИК ДЛЯ ЗАПОЛНЕНИЯ ДАННЫХ ПОДАРКОВ ==========
async def handle_fill_gift_data(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик кнопки заполнения данных для подарков"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    logger.info(f"📦 Запрос на заполнение данных для подарков от пользователя {user_id}")
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        db_user = session.query(User).filter_by(telegram_id=user_id).first()
        if not db_user:
            await query.message.edit_text("❌ Пользователь не найден.")
            return
        
        # Проверяем, есть ли у пользователя годовая подписка
        subscription = session.query(Subscription).filter_by(
            user_id=db_user.id,
            tariff='12_months',
            is_active=True
        ).first()
        
        if not subscription:
            # Проверяем, есть ли завершенный платеж за годовой тариф
            payment = session.query(Payment).filter_by(
                user_id=db_user.id,
                tariff='12_months',
                status='completed'
            ).order_by(Payment.created_at.desc()).first()
            
            if payment and not subscription:
                # Создаем подписку, если платеж есть
                now = datetime.now()
                tariff_info = Config.TARIFFS.get('12_months', {})
                duration_days = tariff_info.get('duration_days', 365)
                
                subscription = Subscription(
                    user_id=db_user.id,
                    tariff='12_months',
                    start_date=now,
                    end_date=now + timedelta(days=duration_days),
                    is_active=True,
                    join_month=now.month,
                    join_year=now.year,
                    created_at=now
                )
                session.add(subscription)
                session.commit()
                logger.info(f"✅ Создана подписка для пользователя {user_id} по существующему платежу")
            else:
                await query.message.edit_text(
                    "❌ У вас нет активной годовой подписки для получения подарков.\n"
                    "Если вы оплатили годовой тариф, дождитесь подтверждения платежа или используйте /payment_status",
                    reply_markup=get_back_to_main_keyboard()
                )
                return
        
        # Проверяем, не заполнены ли уже данные
        if db_user.full_name and db_user.shipping_address:
            await query.message.edit_text(
                "✅ **Данные для подарков уже заполнены!**\n\n"
                f"👤 **ФИО:** {db_user.full_name}\n"
                f"📍 **Адрес:** {db_user.shipping_address}\n\n"
                "Если нужно изменить данные, обратитесь к администратору.",
                parse_mode='Markdown',
                reply_markup=get_back_to_main_keyboard()
            )
            return
        
        # Сохраняем состояние ожидания данных
        context.user_data['awaiting_shipping_info'] = True
        context.user_data['awaiting_full_name'] = True
        context.user_data['active_subscription_id'] = subscription.id
        context.user_data['active_tariff'] = '12_months'
        
        # Запрашиваем ФИО
        text = "📦 **Заполнение данных для получения подарков**\n\nДля отправки рабочей тетради А4 и наклеек нам нужны ваши данные:\n\n✍️ **Введите ваше ФИО (полностью):**\n<code>Иванова Мария Сергеевна</code>"
        
        try:
            await query.message.edit_text(
                text,
                parse_mode='Markdown'
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("📝 Сообщение не изменилось, отправляем новое")
                await context.bot.send_message(
                    chat_id=user_id,
                    text=text,
                    parse_mode='Markdown'
                )
            else:
                raise e
        
    except Exception as e:
        logger.error(f"❌ Ошибка при запросе данных для подарков: {e}")
        try:
            await query.message.edit_text(
                "❌ Произошла ошибка. Пожалуйста, попробуйте еще раз или обратитесь к администратору.",
                reply_markup=get_back_to_main_keyboard()
            )
        except:
            await context.bot.send_message(
                chat_id=user_id,
                text="❌ Произошла ошибка. Пожалуйста, попробуйте еще раз или обратитесь к администратору.",
                reply_markup=get_back_to_main_keyboard()
            )
    finally:
        session.close()


# ========== ОБРАБОТЧИК ДЛЯ РУЧНОЙ АКТИВАЦИИ ПОДПИСКИ ==========
async def handle_manual_activation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик ручной активации подписки"""
    query = update.callback_query
    await query.answer()
    
    try:
        payment_id = int(query.data.split('_')[-1])
        logger.info(f"🔄 Ручная активация подписки для платежа ID={payment_id}")
        
        engine = context.bot_data.get('engine')
        if not engine:
            await query.message.edit_text("❌ Ошибка подключения к базе данных.")
            return
        
        session = get_session(engine)
        
        try:
            payment = session.query(Payment).filter_by(id=payment_id).first()
            if not payment:
                await query.message.edit_text("❌ Платеж не найден.")
                return
            
            if payment.status != 'completed':
                payment.status = 'completed'
                payment.completed_at = datetime.now()
                
                # Создаем подписку
                db_user = session.query(User).filter_by(id=payment.user_id).first()
                
                now = datetime.now()
                tariff_info = Config.TARIFFS.get(payment.tariff, {})
                duration_days = tariff_info.get('duration_days', 30)
                
                subscription = Subscription(
                    user_id=db_user.id,
                    tariff=payment.tariff,
                    start_date=now,
                    end_date=now + timedelta(days=duration_days),
                    is_active=True,
                    join_month=now.month,
                    join_year=now.year,
                    created_at=now
                )
                session.add(subscription)
                session.commit()
                
                await query.message.edit_text(
                    f"✅ **Подписка успешно активирована!**\n\n"
                    f"Тариф: {payment.tariff}\n"
                    f"Действует до: {(now + timedelta(days=duration_days)).strftime('%d.%m.%Y')}",
                    parse_mode='Markdown',
                    reply_markup=get_back_to_main_keyboard()
                )
                
                logger.info(f"✅ Подписка активирована вручную для пользователя {db_user.telegram_id}")
                
            else:
                await query.message.edit_text(
                    "✅ Подписка уже активирована.",
                    reply_markup=get_back_to_main_keyboard()
                )
                
        except Exception as e:
            logger.error(f"❌ Ошибка при ручной активации: {e}")
            session.rollback()
            await query.message.edit_text(
                "❌ Ошибка при активации подписки.",
                reply_markup=get_back_to_main_keyboard()
            )
        finally:
            session.close()
            
    except Exception as e:
        logger.error(f"❌ Ошибка в handle_manual_activation: {e}")
        await query.message.edit_text("❌ Ошибка при обработке запроса.")


# ========== ФУНКЦИЯ: ПРОВЕРКА И ПРОДОЛЖЕНИЕ ПРЕРВАННОГО ПРОЦЕССА ==========
async def continue_interrupted_process(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Проверяет, есть ли прерванный процесс, и продолжает его"""
    user_id = update.effective_user.id
    
    # Проверяем, есть ли незавершенный процесс в user_data
    if context.user_data.get('awaiting_shipping_info'):
        if context.user_data.get('awaiting_full_name'):
            # Запрашиваем ФИО
            await update.message.reply_text(
                "📦 **Продолжим заполнение данных для подарков**\n\n"
                "✍️ **Введите ваше ФИО (полностью):**\n"
                "<code>Иванова Мария Сергеевна</code>",
                parse_mode='Markdown'
            )
            return True
        elif context.user_data.get('awaiting_address'):
            # Запрашиваем адрес
            await update.message.reply_text(
                "📦 **Продолжим заполнение данных для подарков**\n\n"
                "📍 **Введите ваш адрес для отправки подарков:**\n"
                "<b>Формат:</b> индекс, город, улица, дом, квартира\n"
                "<b>Пример:</b> <code>123456, Москва, ул. Примерная, д. 10, кв. 25</code>",
                parse_mode='HTML'
            )
            return True
    
    return False


# ========== ОБРАБОТЧИК ДЛЯ КНОПКИ ПОВТОРНОЙ ПРОВЕРКИ ==========
async def handle_check_status_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик кнопки повторной проверки статуса платежа"""
    query = update.callback_query
    await query.answer()
    
    logger.info(f"🔄 handle_check_status_button вызван: {query.data}")
    
    try:
        # Получаем ID платежа из callback_data (формат: check_status_button_123)
        payment_id = query.data.split('_')[-1]
        logger.info(f"🔍 Проверка статуса по кнопке для PaymentId: {payment_id}")
        
        if not tbank:
            await query.message.edit_text(
                "❌ Тинькофф оплата временно недоступна.\n"
                "Пожалуйста, попробуйте позже или свяжитесь с администратором."
            )
            return
        
        engine = context.bot_data.get('engine')
        if not engine:
            await query.message.edit_text("❌ Ошибка подключения к базе данных.")
            return
        
        session = get_session(engine)
        
        try:
            # Проверяем статус в Тинькофф по PaymentId
            status_result = tbank.check_payment_status(payment_id)
            
            if not status_result or not status_result.get("success"):
                error_msg = status_result.get('error', 'Неизвестная ошибка') if status_result else 'Не удалось проверить статус'
                
                # Пробуем найти платеж в БД и показать текущий статус
                payment_record = session.query(Payment).filter(
                    (Payment.provider_payment_charge_id == payment_id) | 
                    (Payment.order_id == payment_id)
                ).first()
                
                if payment_record:
                    status_text = {
                        'pending': '⏳ Ожидает подтверждения',
                        'completed': '✅ Оплачен',
                        'failed': '❌ Ошибка оплаты',
                        'cancelled': '🚫 Отменен',
                        'refunded': '💰 Возвращен'
                    }.get(payment_record.status, '❓ Неизвестный статус')
                    
                    message = f"""💳 **Статус платежа**

📊 **Текущий статус:** {status_text}
💰 **Сумма:** {payment_record.amount/100} ₽
📅 **Дата:** {payment_record.created_at.strftime('%d.%m.%Y %H:%M')}

❌ Не удалось проверить статус в Тинькофф.
Причина: {error_msg}"""
                    
                    keyboard = InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔄 Проверить еще раз", callback_data=f'check_status_button_{payment_id}')],
                        [InlineKeyboardButton("🏠 Главное меню", callback_data='back_to_main')]
                    ])
                    
                    await query.message.edit_text(
                        message,
                        parse_mode='Markdown',
                        reply_markup=keyboard
                    )
                else:
                    await query.message.edit_text(
                        f"❌ Ошибка проверки статуса: {error_msg}",
                        reply_markup=get_back_to_main_keyboard()
                    )
                return
            
            status = status_result["status"]
            status_text = status_result.get("status_text", status)
            amount = status_result.get("amount", 0)
            
            if status in ["CONFIRMED", "AUTHORIZED"]:
                # Платеж успешен - обрабатываем
                await process_tinkoff_successful_payment(update, context, payment_id, status_result)
                
            elif status == "REJECTED":
                message = """❌ **Платеж отклонен банком**

Возможные причины:
• Недостаточно средств на карте
• Карта заблокирована для онлайн-платежей
• Превышен лимит операций
• Ошибка при вводе данных

Пожалуйста, попробуйте снова или свяжитесь с менеджером."""
                
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("💰 Выбрать другой тариф", callback_data='back_to_tariffs')],
                    [InlineKeyboardButton("✍️ Связаться с менеджером", callback_data='contact_manager')]
                ])
                
                await query.message.edit_text(
                    message,
                    parse_mode='Markdown',
                    reply_markup=keyboard
                )
                
            elif status in ["CANCELED", "DEADLINE_EXPIRED"]:
                message = f"""❌ **Платеж отменен**

Статус: {status_text}
Сумма: {amount:.0f} ₽

Вы можете создать новый платеж."""
                
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("💰 Выбрать тариф", callback_data='back_to_tariffs')],
                    [InlineKeyboardButton("✍️ Связаться с менеджером", callback_data='contact_manager')]
                ])
                
                await query.message.edit_text(
                    message,
                    parse_mode='Markdown',
                    reply_markup=keyboard
                )
                
            elif status == "FORM_SHOWED":
                message = f"""⏳ **Ожидание оплаты**

Статус: {status_text}
Сумма: {amount:.0f} ₽

Платеж еще не завершен. Пожалуйста, проверьте, прошла ли оплата в вашем банке."""
                
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Проверить еще раз", callback_data=f'check_status_button_{payment_id}')],
                    [InlineKeyboardButton("🏠 Главное меню", callback_data='back_to_main')]
                ])
                
                await query.message.edit_text(
                    message,
                    parse_mode='Markdown',
                    reply_markup=keyboard
                )
                
            else:
                message = f"""⏳ **Платеж обрабатывается**

Статус: {status_text}
Сумма: {amount:.0f} ₽

Платеж еще обрабатывается. Проверьте статус через несколько минут."""
                
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Проверить еще раз", callback_data=f'check_status_button_{payment_id}')],
                    [InlineKeyboardButton("🏠 Главное меню", callback_data='back_to_main')]
                ])
                
                await query.message.edit_text(
                    message,
                    parse_mode='Markdown',
                    reply_markup=keyboard
                )
                
        except Exception as e:
            logger.error(f"❌ Ошибка при проверке статуса: {e}", exc_info=True)
            await query.message.edit_text(
                "❌ Произошла ошибка при проверке статуса.",
                reply_markup=get_back_to_main_keyboard()
            )
        finally:
            session.close()
            
    except Exception as e:
        logger.error(f"❌ Ошибка в handle_check_status_button: {e}", exc_info=True)
        await query.message.edit_text("❌ Ошибка при обработке запроса.")


# ========== ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ ==========
def get_tariff_name(tariff_key):
    """Вспомогательная функция для получения названия тарифа"""
    tariffs = {
        '1_month': '1 месяц - 5000 ₽',
        '3_months': '3 месяца - 13500 ₽',
        '12_months': '12 месяцев - 40000 ₽',
        'creative': 'Творческий - 5000 ₽'
    }
    return tariffs.get(tariff_key, tariff_key)


# ========== ОСТАЛЬНЫЕ ФУНКЦИИ ==========

async def handle_tariff_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик выбора тарифа - запрашивает email для чека"""
    query = update.callback_query
    await query.answer()
    
    if query.data.startswith('promocode_'):
        logger.info(f"⏭️ Игнорируем callback от промокода: {query.data}")
        return
    
    tariff_key = query.data.replace('tariff_', '')
    tariff_info = Config.TARIFFS.get(tariff_key)
    
    if not tariff_info:
        await query.message.reply_text("Извините, выбранный тариф недоступен.")
        return
    
    context.user_data['selected_tariff'] = tariff_key
    context.user_data['selected_tariff_info'] = tariff_info
    
    logger.info(f"✅ Пользователь {query.from_user.id} выбрал тариф: {tariff_key}")
    
    price = tariff_info['price'] / 100
    
    text = f"""<b>Выбран тариф:</b> {tariff_info['label']}
    
<b>Описание:</b> {tariff_info['description']}
    
<b>Цена:</b> {price:,.0f} ₽
    
<b>Для отправки электронного чека 54-ФЗ, пожалуйста, введите ваш email:</b>
    
<code>example@email.com</code>"""
    
    if tariff_key == '12_months':
        text += "\n\n🎁 <b>Бонусы:</b> рабочая тетрадь А4 и наклейки (потребуются данные для отправки)"
    
    try:
        await query.message.delete()
    except:
        pass
    
    await context.bot.send_message(
        chat_id=query.message.chat_id,
        text=text,
        parse_mode='HTML'
    )
    
    context.user_data['awaiting_email_for_receipt'] = True
    logger.info(f"📧 Запрошен email для чека у пользователя {query.from_user.id}")

async def handle_email_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик ввода email для чека 54-ФЗ"""
    if not update.message or not update.message.text:
        return
    
    user = update.effective_user
    email = update.message.text.strip().lower()
    
    if '@' not in email or '.' not in email or len(email) < 5:
        await update.message.reply_text(
            "❌ <b>Пожалуйста, введите корректный email адрес.</b>\n\n"
            "Пример: <code>name@example.com</code>\n\n"
            "Email необходим для отправки электронного чека 54-ФЗ.",
            parse_mode='HTML'
        )
        return
    
    context.user_data['receipt_email'] = email
    
    engine = context.bot_data.get('engine')
    if engine:
        session = get_session(engine)
        try:
            db_user = session.query(User).filter_by(telegram_id=user.id).first()
            if db_user:
                db_user.email = email
                session.commit()
                logger.info(f"✅ Email сохранен в БД для пользователя {user.id}: {email}")
            else:
                logger.warning(f"Пользователь {user.id} не найден в БД при сохранении email")
        except Exception as e:
            logger.error(f"❌ Ошибка сохранения email в БД: {e}")
            session.rollback()
        finally:
            session.close()
    
    tariff_key = context.user_data.get('selected_tariff')
    tariff_info = context.user_data.get('selected_tariff_info')
    
    if not tariff_key or not tariff_info:
        await update.message.reply_text(
            "❌ Произошла ошибка. Пожалуйста, выберите тариф заново через меню.",
            parse_mode='HTML'
        )
        for key in ['selected_tariff', 'selected_tariff_info', 'receipt_email', 'awaiting_email_for_receipt']:
            if key in context.user_data:
                del context.user_data[key]
        return
    
    price = tariff_info['price'] / 100
    
    text = f"""✅ <b>Email для чека сохранен:</b> <code>{email}</code>
    
<b>Выбран тариф:</b> {tariff_info['label']}
    
<b>Цена:</b> {price:,.0f} ₽
    
<b>Входит в тариф:</b>
• Еженедельные лекции и встречи в Zoom
• Доступ к записям
• Закрытое сообщество клуба
• Дополнительные материалы"""
    
    if tariff_key == '12_months':
        text += "\n\n🎁 <b>Бонусы:</b> рабочая тетрадь А4 и наклейки"
    
    text += "\n\nВы можете применить промокод или перейти к оплате."
    
    from keyboards import get_payment_keyboard
    keyboard = get_payment_keyboard(tariff_key)
    
    await update.message.reply_text(
        text,
        reply_markup=keyboard,
        parse_mode='HTML'
    )
    
    if 'awaiting_email_for_receipt' in context.user_data:
        del context.user_data['awaiting_email_for_receipt']
    
    logger.info(f"✅ Email введен пользователем {user.id}, показаны кнопки оплаты")

async def handle_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик оплаты через Тинькофф"""
    query = update.callback_query
    await query.answer()
    
    logger.info(f"💳 Пользователь {query.from_user.id} начал оплату: {query.data}")
    
    if query.data == 'installment_payment':
        admin = Config.ADMIN_USERNAMES[0] if Config.ADMIN_USERNAMES else 'skrepka_service'
        
        text = f"""💳 <b>Оплата долями</b>

Для оформления оплаты частями напишите нашему менеджеру: @{admin.replace('@', '')}"""
        
        keyboard = [
            [InlineKeyboardButton("✍️ Написать менеджеру", 
                                url=f"https://t.me/{admin.replace('@', '')}")],
            [InlineKeyboardButton("◀️ Назад", callback_data='back_to_tariffs')]
        ]
        
        try:
            await query.message.edit_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
        except Exception as e:
            logger.warning(f"Не удалось отредактировать сообщение: {e}. Отправляем новое.")
            await query.message.reply_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
        return
    
    elif query.data.startswith('pay_'):
        tariff_key = query.data.replace('pay_', '')
        tariff_info = Config.TARIFFS.get(tariff_key)
        
        if not tariff_info:
            try:
                await query.message.edit_text("Ошибка: тариф не найден.")
            except:
                await query.message.reply_text("Ошибка: тариф не найден.")
            return
        
        if 'receipt_email' not in context.user_data:
            try:
                await query.message.edit_text(
                    "❌ <b>Email для чека не указан.</b>\n\n"
                    "Пожалуйста, введите email для отправки электронного чека 54-ФЗ.",
                    parse_mode='HTML'
                )
            except:
                await query.message.reply_text(
                    "❌ Email для чека не указан. Пожалуйста, введите email для отправки электронного чека 54-ФЗ.",
                    parse_mode='HTML'
                )
            context.user_data['awaiting_email_for_receipt'] = True
            context.user_data['selected_tariff'] = tariff_key
            context.user_data['selected_tariff_info'] = tariff_info
            return
        
        email = context.user_data['receipt_email']
        
        promocode_text = context.user_data.get('applied_promocode')
        promocode_data = context.user_data.get('promocode_data', {})
        discount = 0
        
        if promocode_text and promocode_data:
            original_price = tariff_info['price']
            
            if promocode_data.get('discount_amount', 0) > 0:
                discount = promocode_data['discount_amount']
            elif promocode_data.get('discount_percent', 0) > 0:
                discount = original_price * (promocode_data['discount_percent'] / 100)
            
            logger.info(f"💰 Применена скидка: {discount/100:.0f} ₽")
        
        original_price = tariff_info['price']
        final_price = max(100, original_price - discount)
        final_price_rub = final_price / 100
        
        order_id = f"order_{query.from_user.id}_{int(time.time())}"
        
        context.user_data['payment_data'] = {
            'tariff': tariff_key,
            'original_price': original_price,
            'discount': discount,
            'final_price': final_price,
            'promocode': promocode_text,
            'promocode_id': promocode_data.get('id'),
            'order_id': order_id,
            'user_id': query.from_user.id,
            'email': email
        }
        
        description = f"Подписка «Бестужевки» - {tariff_info['label']}"
        
        customer_data = {
            "email": email,
            "phone": ""
        }
        
        result = tbank.create_payment(
            order_id=order_id,
            amount=final_price_rub,
            description=description,
            customer_data=customer_data
        )
        
        if result["success"]:
            payment_url = result["payment_url"]
            payment_id = result["payment_id"]
            order_id_from_response = result["order_id"]
            
            try:
                engine = context.bot_data.get('engine')
                if engine:
                    session = get_session(engine)
                    
                    db_user = session.query(User).filter_by(telegram_id=query.from_user.id).first()
                    if not db_user:
                        db_user = User(
                            telegram_id=query.from_user.id,
                            username=query.from_user.username,
                            first_name=query.from_user.first_name,
                            last_name=query.from_user.last_name,
                            email=email,
                            settings={'reminders': True}
                        )
                        session.add(db_user)
                        session.flush()
                    else:
                        if not db_user.email:
                            db_user.email = email
                    
                    payment_record = Payment(
                        user_id=db_user.id,
                        amount=final_price,
                        original_amount=original_price,
                        discount=discount,
                        currency='RUB',
                        tariff=tariff_key,
                        promocode=promocode_text,
                        invoice_payload=json.dumps({
                            'order_id': order_id_from_response,
                            'payment_id': payment_id,
                            'user_id': query.from_user.id,
                            'tariff': tariff_key,
                            'email': email
                        }),
                        status='pending',
                        order_id=order_id_from_response,
                        provider_payment_charge_id=payment_id
                    )
                    session.add(payment_record)
                    session.commit()
                    
                    context.user_data['payment_data']['payment_id'] = payment_id
                    context.user_data['payment_data']['order_id'] = order_id_from_response
                    
                    logger.info(f"💾 Платеж сохранен в БД: OrderId={order_id_from_response}, PaymentId={payment_id}, сумма={final_price_rub:.0f} руб, email={email}")
                    
            except Exception as e:
                logger.error(f"Ошибка сохранения платежа в БД: {e}")
            
            if discount > 0:
                price_text = f"""<b>Исходная цена:</b> {original_price/100:,.0f} ₽
<b>Скидка:</b> {discount/100:,.0f} ₽
<b>Итоговая цена:</b> {final_price_rub:,.0f} ₽"""
            else:
                price_text = f"<b>Сумма к оплате:</b> {final_price_rub:,.0f} ₽"
            
            text = f"""✅ <b>Платеж создан</b>

<b>Тариф:</b> {tariff_info['label']}
<b>Email для чека:</b> {email}
{price_text}
           
Для оплаты перейдите по ссылке ниже:

После успешной оплаты нажмите "🔄 Проверить статус" чтобы подтвердить оплату"""
            
            keyboard = [
                [InlineKeyboardButton("💳 Перейти к оплате", url=payment_url)],
                [InlineKeyboardButton("🔄 Проверить статус", callback_data=f'check_status_button_{payment_id}')],
                [InlineKeyboardButton("◀️ Назад к тарифам", callback_data='back_to_tariffs')]
            ]
            
            try:
                await query.message.edit_text(
                    text,
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='HTML'
                )
            except Exception as e:
                logger.warning(f"Не удалось отредактировать сообщение: {e}. Отправляем новое.")
                await query.message.reply_text(
                    text,
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode='HTML'
                )
            
        else:
            error_msg = result.get('error', 'Неизвестная ошибка')
            logger.error(f"Ошибка создания платежа: {error_msg}")
            
            error_text = f"""❌ <b>Ошибка создания платежа</b>

Не удалось создать платеж в Тинькофф.

<b>Ошибка:</b> {error_msg}"""
            
            if result.get('diagnosis'):
                error_text += f"\n\n<b>Рекомендация:</b> {result['diagnosis']}"
            
            error_text += "\n\nПожалуйста, попробуйте снова или свяжитесь с менеджером."
            
            try:
                await query.message.edit_text(
                    error_text,
                    parse_mode='HTML'
                )
            except:
                await query.message.reply_text(
                    error_text,
                    parse_mode='HTML'
                )

async def handle_tinkoff_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик для кнопок Тинькофф"""
    query = update.callback_query
    await query.answer()
    
    parts = query.data.split('_')
    if len(parts) >= 3:
        tariff_key = parts[2]
        query.data = f'pay_{tariff_key}'
        await handle_payment(update, context)
    else:
        try:
            await query.message.edit_text(
                "❌ Не удалось обработать запрос оплаты",
                parse_mode='HTML'
            )
        except:
            await query.message.reply_text(
                "❌ Не удалось обработать запрос оплаты",
                parse_mode='HTML'
            )

async def check_payment_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Проверка статуса платежа Тинькофф по PaymentId (старая версия)"""
    if not tbank:
        await update.callback_query.answer("Тинькофф оплата временно недоступна", show_alert=True)
        return
    
    query = update.callback_query
    await query.answer()
    
    payment_id = query.data.replace('check_status_', '')
    logger.info(f"🔄 Проверка статуса платежа по PaymentId: {payment_id} (старая версия)")
    
    query.data = f'check_status_button_{payment_id}'
    await handle_check_status_button(update, context)

async def process_tinkoff_successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE, payment_id, status_result):
    """Обработка успешного платежа Тинькофф с учетом разных тарифов и запросом данных для подарков"""
    query = update.callback_query
    engine = context.bot_data.get('engine')
    
    if not engine:
        logger.error("Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        payment_record = session.query(Payment).filter_by(provider_payment_charge_id=payment_id).first()
        
        if not payment_record:
            order_id = status_result.get("order_id", "")
            if order_id:
                payment_record = session.query(Payment).filter_by(order_id=order_id).first()
        
        if not payment_record:
            logger.error(f"Платеж PaymentId={payment_id} не найден в БД")
            try:
                await query.message.edit_text(
                    "Платеж успешен, но возникла ошибка при обновлении данных. Обратитесь к администратору.",
                    parse_mode='HTML'
                )
            except:
                await query.message.reply_text(
                    "Платеж успешен, но возникла ошибка при обновлении данных. Обратитесь к администратору.",
                    parse_mode='HTML'
                )
            return
        
        if payment_record.status == 'completed':
            try:
                await query.message.edit_text(
                    "✅ Этот платеж уже был успешно обработан ранее.",
                    parse_mode='HTML'
                )
            except:
                await query.message.reply_text(
                    "✅ Этот платеж уже был успешно обработан ранее.",
                    parse_mode='HTML'
                )
            return
        
        payment_record.status = 'completed'
        payment_record.completed_at = datetime.now()
        payment_record.provider_payment_charge_id = payment_id
        
        email = None
        if 'receipt_email' in context.user_data:
            email = context.user_data['receipt_email']
        elif payment_record.invoice_payload:
            try:
                payload = json.loads(payment_record.invoice_payload)
                email = payload.get('email')
            except:
                pass
        
        promocode_text = payment_record.promocode
        if promocode_text:
            promocode = session.query(Promocode).filter_by(code=promocode_text).first()
            if promocode:
                promocode.used_count += 1
                logger.info(f"📈 Промокод использован: {promocode_text} ({promocode.used_count}/{promocode.max_uses})")
        
        db_user = session.query(User).filter_by(id=payment_record.user_id).first()
        
        if email and not db_user.email:
            db_user.email = email
            logger.info(f"📧 Email пользователя обновлен: {db_user.telegram_id} -> {email}")
        
        existing_subscription = session.query(Subscription).filter_by(
            user_id=db_user.id, 
            is_active=True
        ).first()
        
        if existing_subscription:
            tariff_info = Config.TARIFFS.get(payment_record.tariff, {})
            duration_days = tariff_info.get('duration_days', 30)
            
            if existing_subscription.end_date > datetime.now():
                new_end_date = existing_subscription.end_date + timedelta(days=duration_days)
            else:
                new_end_date = datetime.now() + timedelta(days=duration_days)
            
            existing_subscription.end_date = new_end_date
            existing_subscription.tariff = payment_record.tariff
            
            logger.info(f"📅 Продлена существующая подписка пользователя {db_user.telegram_id} до {new_end_date.strftime('%d.%m.%Y')}")
            
            success_text = f"""🎉 <b>Ты с нами 🤍</b>

<b>Подписка продлена!</b>

Ваша подписка на тариф «{payment_record.tariff}» успешно продлена.

<b>Доступ продлен до: {new_end_date.strftime('%d.%m.%Y')}</b>

Не удаляй бот — здесь мы будем напоминать о встречах и важных событиях."""
            
            keyboard = get_after_payment_keyboard_with_main_menu(payment_record.tariff)
            
            await query.message.edit_text(
                success_text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
        else:
            now = datetime.now()
            tariff_info = Config.TARIFFS.get(payment_record.tariff, {})
            duration_days = tariff_info.get('duration_days', 30)
            
            start_date = now
            end_date = now + timedelta(days=duration_days)
            
            subscription = Subscription(
                user_id=db_user.id,
                tariff=payment_record.tariff,
                start_date=start_date,
                end_date=end_date,
                is_active=True,
                join_month=start_date.month,
                join_year=start_date.year,
                created_at=now
            )
            session.add(subscription)
            session.flush()
            
            logger.info(f"📅 Создана новая подписка пользователя {db_user.telegram_id} с доступом с {start_date.strftime('%d.%m.%Y')} до {end_date.strftime('%d.%m.%Y')}")
            
            if payment_record.tariff == '12_months':
                success_text = f"""🎉 <b>Ты с нами 🤍</b>

Добро пожаловать в клуб «Бестужевки»!

<b>Ваш доступ к тарифу «{payment_record.tariff}» активирован!</b>
<b>Действует до: {end_date.strftime('%d.%m.%Y')}</b>

🎁 <b>Вы выбрали годовой тариф с бонусами!</b>

Для отправки подарков (рабочая тетрадь А4 и наклейки) нам нужны ваши данные:

✍️ <b>Введите ваше ФИО (полностью):</b>
<code>Иванова Мария Сергеевна</code>"""
                
                context.user_data['awaiting_shipping_info'] = True
                context.user_data['awaiting_full_name'] = True
                context.user_data['active_subscription_id'] = subscription.id
                context.user_data['active_tariff'] = payment_record.tariff
                
                await query.message.edit_text(
                    success_text,
                    parse_mode='HTML'
                )
                
            else:
                success_text = f"""🎉 <b>Ты с нами 🤍</b>

Добро пожаловать в клуб «Бестужевки»!

<b>Ваш доступ к тарифу «{payment_record.tariff}» активирован!</b>
<b>Действует до: {end_date.strftime('%d.%m.%Y')}</b>

Не удаляй бот — здесь мы будем напоминать о встречах и важных событиях."""
                
                keyboard = get_after_payment_keyboard_with_main_menu(payment_record.tariff)
                
                await query.message.edit_text(
                    success_text,
                    reply_markup=keyboard,
                    parse_mode='HTML'
                )
        
        if payment_record.promocode:
            promo_usage = PromoUsage(
                user_id=db_user.id,
                promocode=payment_record.promocode,
                discount_amount=payment_record.discount,
                payment_id=payment_record.id
            )
            session.add(promo_usage)
        
        session.commit()
        
        keys_to_clear = ['payment_data', 'applied_promocode', 'selected_tariff', 'selected_tariff_info', 'receipt_email']
        if payment_record.tariff != '12_months':
            keys_to_clear.extend(['awaiting_shipping_info', 'awaiting_full_name', 'active_subscription_id', 'active_tariff'])
        
        for key in keys_to_clear:
            if key in context.user_data:
                del context.user_data[key]
        
        logger.info(f"✅ Успешная оплата обработана: пользователь {db_user.telegram_id}, тариф {payment_record.tariff}, PaymentId={payment_id}")
        
        admin_message = f"""💸 {'ПРОДЛЕНА ПОДПИСКА' if existing_subscription else 'НОВАЯ ПОДПИСКА'} - Успешный платеж Тинькофф

👤 Пользователь: @{db_user.username or 'без username'} ({db_user.first_name or ''})
📧 Email для чека: {email or 'не указан'}
💰 Сумма: {payment_record.amount/100:.0f} ₽
📋 Тариф: {payment_record.tariff}
🎫 Промокод: {payment_record.promocode or 'нет'}
🆔 Order ID: {payment_record.order_id}
🆔 Payment ID: {payment_id}
📅 Доступ ДО: {(existing_subscription.end_date if existing_subscription else end_date).strftime('%d.%m.%Y')}
✅ Доступ активирован СРАЗУ после оплаты"""
        
        if payment_record.tariff == '12_months' and not existing_subscription:
            admin_message += "\n🎁 Годовой тариф - ожидаются данные для подарков"
        
        for admin_id in Config.ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=admin_message
                )
            except Exception as e:
                logger.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
        
    except Exception as e:
        logger.error(f"❌ Ошибка обработки платежа: {e}", exc_info=True)
        session.rollback()
        try:
            await query.message.edit_text(
                "Произошла ошибка при обработке платежа. Мы уже работаем над ее устранением.",
                parse_mode='HTML'
            )
        except:
            await query.message.reply_text(
                "Произошла ошибка при обработке платежа. Мы уже работаем над ее устранением.",
                parse_mode='HTML'
            )
    finally:
        session.close()

async def handle_shipping_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка данных для отправки подарков (ФИО и адрес)"""
    if not update.message or not update.message.text:
        return
    
    user = update.effective_user
    text = update.message.text.strip()
    
    if not context.user_data.get('awaiting_shipping_info'):
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        return
    
    session = get_session(engine)
    
    try:
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if not db_user:
            logger.error(f"Пользователь {user.id} не найден в БД при обработке данных для подарков")
            await update.message.reply_text("❌ Произошла ошибка. Пожалуйста, обратитесь к администратору.")
            return
        
        if context.user_data.get('awaiting_full_name'):
            if len(text) < 5:
                await update.message.reply_text(
                    "❌ <b>Пожалуйста, введите полное ФИО.</b>\n\n"
                    "Пример: <code>Иванова Мария Сергеевна</code>",
                    parse_mode='HTML'
                )
                return
            
            db_user.full_name = text
            session.commit()
            
            context.user_data['awaiting_address'] = True
            del context.user_data['awaiting_full_name']
            
            await update.message.reply_text(
                "✅ <b>ФИО сохранено!</b>\n\n"
                "📍 <b>Теперь введите ваш адрес для отправки подарков:</b>\n\n"
                "<b>Формат:</b> индекс, город, улица, дом, квартира\n"
                "<b>Пример:</b> <code>123456, Москва, ул. Примерная, д. 10, кв. 25</code>",
                parse_mode='HTML'
            )
            
            logger.info(f"✅ ФИО сохранено для пользователя {user.id}: {text}")
            
        elif context.user_data.get('awaiting_address'):
            if len(text) < 10:
                await update.message.reply_text(
                    "❌ <b>Пожалуйста, введите полный адрес.</b>\n\n"
                    "Пример: <code>123456, Москва, ул. Примерная, д. 10, кв. 25</code>",
                    parse_mode='HTML'
                )
                return
            
            db_user.shipping_address = text
            session.commit()
            
            subscription_id = context.user_data.get('active_subscription_id')
            subscription = None
            if subscription_id:
                from database import Subscription
                subscription = session.query(Subscription).filter_by(id=subscription_id).first()
                if subscription:
                    subscription.bonuses_shipping = "ожидает отправки"
                    subscription.bonuses_sent = False
                    session.commit()
            
            del context.user_data['awaiting_shipping_info']
            del context.user_data['awaiting_address']
            tariff = context.user_data.get('active_tariff', '12_months')
            
            from keyboards import get_after_payment_keyboard_with_main_menu
            
            end_date_str = subscription.end_date.strftime('%d.%m.%Y') if subscription and subscription.end_date else 'дата не определена'
            
            success_text = f"""🎉 <b>Ты с нами 🤍</b>

<b>Спасибо! Все данные сохранены!</b>

<b>Ваш доступ к тарифу «{tariff}» активирован!</b>
<b>Действует до: {end_date_str}</b>

<b>Для отправки подарков:</b>
👤 <b>ФИО:</b> {db_user.full_name}
📦 <b>Адрес:</b> {db_user.shipping_address}

🎁 <b>Бонусы:</b> рабочая тетрадь А4 и наклейки
📮 <b>Статус отправки:</b> ожидает отправки

Подарки будут отправлены в течение 14 рабочих дней.
Вы получите уведомление с трек-номером.

Не удаляй бот — здесь мы будем напоминать о встречах и важных событиях."""
            
            keyboard = get_after_payment_keyboard_with_main_menu(tariff)
            
            await update.message.reply_text(
                success_text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            for key in ['active_subscription_id', 'active_tariff']:
                if key in context.user_data:
                    del context.user_data[key]
            
            logger.info(f"✅ Данные для подарков сохранены: пользователь {user.id}, ФИО: {db_user.full_name}, адрес: {db_user.shipping_address}")
            
            admin_message = f"""🎁 ПОЛУЧЕНЫ ДАННЫЕ ДЛЯ ОТПРАВКИ ПОДАРКОВ

👤 Пользователь: @{db_user.username or 'без username'} ({db_user.first_name or ''})
📧 Email: {db_user.email or 'не указан'}
📞 Телефон: {db_user.phone_number or 'не указан'}
👤 ФИО: {db_user.full_name}
📍 Адрес: {db_user.shipping_address}
📦 Тариф: {tariff}
📅 Доступ до: {end_date_str}

✅ Готово к отправке!"""
            
            for admin_id in Config.ADMIN_IDS:
                try:
                    await context.bot.send_message(
                        chat_id=admin_id,
                        text=admin_message
                    )
                except Exception as e:
                    logger.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
        
    except Exception as e:
        logger.error(f"❌ Ошибка сохранения данных для подарков: {e}", exc_info=True)
        session.rollback()
        await update.message.reply_text(
            "❌ Произошла ошибка при сохранении данных. Пожалуйста, попробуйте еще раз или обратитесь к администратору."
        )
    finally:
        session.close()

async def handle_promocode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик кнопок промокодов"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    if query.data == 'enter_promocode':
        text = "🎫 Введите промокод:"
        
        try:
            await query.message.edit_text(
                text,
                reply_markup=get_back_keyboard('tariff_selection')
            )
        except:
            await query.message.reply_text(
                text,
                reply_markup=get_back_keyboard('tariff_selection')
            )
        
        context.user_data['awaiting_promocode'] = True
    
    elif query.data == 'remove_promocode':
        if 'applied_promocode' in context.user_data:
            del context.user_data['applied_promocode']
        if 'promocode_data' in context.user_data:
            del context.user_data['promocode_data']
        
        tariff = context.user_data.get('selected_tariff')
        if tariff:
            tariff_info = Config.TARIFFS.get(tariff)
            if tariff_info:
                price = tariff_info['price'] / 100
                
                text = f"""<b>Выбран тариф:</b> {tariff_info['label']}
                
<b>Цена:</b> {price:,.0f} ₽
                
Промокод удален."""
                
                try:
                    await query.message.edit_text(
                        text,
                        reply_markup=get_payment_keyboard(tariff),
                        parse_mode='HTML'
                    )
                except:
                    await query.message.reply_text(
                        text,
                        reply_markup=get_payment_keyboard(tariff),
                        parse_mode='HTML'
                    )