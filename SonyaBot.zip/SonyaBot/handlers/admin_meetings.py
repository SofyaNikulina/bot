# admin_meetings.py - ПОЛНОСТЬЮ ИСПРАВЛЕННЫЙ
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, ConversationHandler, CommandHandler, MessageHandler, filters, CallbackQueryHandler
from database import get_session, Meeting, User, Subscription, Reminder
from keyboards import (
    get_back_keyboard,
    get_cancel_keyboard,
    get_meeting_selection_keyboard,
    get_meeting_detail_keyboard,
    get_meetings_list_keyboard,
    get_zoom_mode_keyboard,
    get_zoom_success_keyboard,
    get_zoom_share_keyboard,
    get_status_change_keyboard,
    get_delete_confirmation_keyboard
)
import logging
import traceback
from datetime import datetime
from config import Config
import asyncio

logger = logging.getLogger(__name__)

# States для ConversationHandler
ADD_TITLE, ADD_DATE, ADD_DURATION, ADD_DESCRIPTION, ADD_ZOOM = range(5)

class MeetingsManager:
    """Менеджер управления встречами"""
    
    @staticmethod
    async def send_reminder_manually(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Ручная отправка напоминаний для тестирования"""
        user = update.effective_user
        
        if user.id not in Config.ADMIN_IDS:
            return
        
        args = context.args
        if not args or len(args) < 2:
            await update.message.reply_text(
                "❌ Использование: /send_reminder <meeting_id> <type>\n"
                "   type: 15min, live, day\n"
                "   Пример: /send_reminder 123 15min"
            )
            return
        
        try:
            meeting_id = int(args[0])
            reminder_type = args[1]
            
            engine = context.bot_data.get('engine')
            if not engine:
                await update.message.reply_text("❌ Engine не найден.")
                return
            
            session = get_session(engine)
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            
            if not meeting:
                await update.message.reply_text("❌ Встреча не найдена.")
                session.close()
                return
            
            await update.message.reply_text(f"🔄 Отправляю напоминание для встречи: {meeting.title}")
            
            if reminder_type == '15min':
                from scheduler import SchedulerManager
                scheduler = SchedulerManager(context.bot, engine)
                await scheduler.send_15_min_reminder(meeting, session)
            elif reminder_type == 'live':
                from scheduler import SchedulerManager
                scheduler = SchedulerManager(context.bot, engine)
                await scheduler.send_zoom_during_stream(meeting, session)
            elif reminder_type == 'day':
                from scheduler import SchedulerManager
                scheduler = SchedulerManager(context.bot, engine)
                await scheduler.send_day_reminder(meeting, session)
            else:
                await update.message.reply_text("❌ Неизвестный тип напоминания.")
                session.close()
                return
            
            await update.message.reply_text("✅ Напоминание отправлено!")
            session.close()
            
        except Exception as e:
            logger.error(f"❌ Ошибка ручной отправки: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    @staticmethod
    async def show_meetings_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать список встреч"""
        query = update.callback_query
        await query.answer()
        
        logger.debug(f"🔄 show_meetings_list вызван для callback_data: {query.data}")
        
        engine = context.bot_data.get('engine')
        if not engine:
            logger.error("❌ Engine не найден в bot_data")
            await query.message.edit_text("❌ Ошибка подключения к базе данных.")
            return
        
        session = get_session(engine)
        
        try:
            meetings = session.query(Meeting).order_by(Meeting.date_time).all()
            logger.debug(f"📊 Найдено встреч в БД: {len(meetings)}")
            
            if not meetings:
                text = "<b>📭 Список встреч пуст</b>\n\nСоздайте первую встречу."
                keyboard = get_meetings_list_keyboard()
                logger.debug("📭 Список встреч пуст")
            else:
                text = "<b>📅 Список всех встреч:</b>\n\n"
                
                for i, meeting in enumerate(meetings, 1):
                    status = "✅" if meeting.is_active else "⏸️"
                    date_str = meeting.date_time.strftime('%d.%m.%Y %H:%M')
                    
                    text += f"{i}. {status} <b>{meeting.title}</b>\n"
                    text += f"   📅 {date_str}\n"
                    text += f"   ⏱️ {meeting.duration} мин\n"
                    text += f"   🔗 {'✅' if meeting.zoom_link else '❌'}\n"
                    text += f"   🆔 ID: {meeting.id}\n\n"
            
            from keyboards import get_meetings_list_with_options_keyboard
            keyboard = get_meetings_list_with_options_keyboard() if meetings else get_meetings_list_keyboard()
            
            try:
                await query.message.edit_text(
                    text,
                    reply_markup=keyboard,
                    parse_mode='HTML'
                )
                logger.debug(f"✅ Список встреч успешно показан ({len(meetings)} встреч)")
            except Exception as edit_error:
                if "Message is not modified" in str(edit_error):
                    logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
                else:
                    logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                    await query.message.reply_text(
                        text,
                        reply_markup=keyboard,
                        parse_mode='HTML'
                    )
            
        except Exception as e:
            logger.error(f"❌ Ошибка при отображении списка встреч: {e}", exc_info=True)
            await query.message.edit_text("❌ Ошибка при загрузке списка встреч.")
        finally:
            session.close()
            logger.debug("🔒 Сессия БД закрыта")
    
    @staticmethod
    async def handle_send_zoom_to_all(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Отправить Zoom ссылку всем активным подписчикам"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"📨 handle_send_zoom_to_all вызван: {query.data}")
        
        try:
            parts = query.data.split('_')
            meeting_id = int(parts[3])  # send_zoom_to_all_123
            
            logger.info(f"🆔 Рассылка Zoom для встречи ID: {meeting_id}")
            
            engine = context.bot_data.get('engine')
            if not engine:
                logger.error("❌ Engine не найден в bot_data")
                await query.message.edit_text("❌ Ошибка подключения к базе данных.")
                return
            
            session = get_session(engine)
            
            try:
                meeting = session.query(Meeting).filter_by(id=meeting_id).first()
                if not meeting:
                    await query.message.edit_text("❌ Встреча не найдена.")
                    return
                
                if not meeting.zoom_link:
                    await query.message.edit_text("❌ У этой встречи нет Zoom ссылки.")
                    return
                
                subscribers = session.query(User).join(Subscription).filter(
                    Subscription.is_active == True,
                    Subscription.end_date >= datetime.now()
                ).all()
                
                logger.info(f"📊 Найдено активных подписчиков: {len(subscribers)}")
                
                await query.message.edit_text(
                    f"🔄 **Рассылка Zoom ссылки...**\n\n"
                    f"Встреча: {meeting.title}\n"
                    f"Пользователей: {len(subscribers)}\n\n"
                    f"<i>Это может занять несколько минут...</i>",
                    parse_mode='HTML'
                )
                
                sent_count = 0
                error_count = 0
                
                for user in subscribers:
                    try:
                        text = f"""📅 **Приглашение на встречу клуба «Бестужевки»**

**Тема:** {meeting.title}
**Время:** {meeting.date_time.strftime('%d.%m.%Y в %H:%M')}
**Ссылка для входа:** {meeting.zoom_link}
**Пароль:** {meeting.zoom_password or 'не требуется'}

Ждём вас на встрече!"""
                        
                        await context.bot.send_message(
                            chat_id=user.telegram_id,
                            text=text,
                            parse_mode='Markdown'
                        )
                        sent_count += 1
                        
                        if sent_count % 10 == 0:
                            await asyncio.sleep(1)
                        
                    except Exception as e:
                        error_count += 1
                        logger.error(f"Ошибка отправки Zoom ссылки пользователю {user.id}: {e}")
                
                for admin_id in Config.ADMIN_IDS:
                    try:
                        report_text = f"""📊 **Отчет по рассылке Zoom ссылки**

✅ **Завершена рассылка для встречи:**
• Тема: {meeting.title}
• Время: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
• Отправлено: {sent_count} пользователям
• Ошибок: {error_count}

Ссылка: {meeting.zoom_link}"""
                        
                        await context.bot.send_message(
                            chat_id=admin_id,
                            text=report_text,
                            parse_mode='Markdown'
                        )
                    except Exception as e:
                        logger.error(f"Не удалось отправить отчет админу {admin_id}: {e}")
                
                result_text = f"""✅ **Рассылка завершена**

📊 **Результаты:**
• Встреча: {meeting.title}
• Время: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
• Успешно отправлено: {sent_count}
• Ошибок отправки: {error_count}

Отчет отправлен всем администраторам."""
                
                await query.message.edit_text(
                    result_text,
                    parse_mode='Markdown',
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("◀️ Назад к встрече", callback_data=f'edit_{meeting_id}')]
                    ])
                )
                
                logger.info(f"✅ Рассылка Zoom завершена: отправлено {sent_count}, ошибок {error_count}")
                
            except Exception as e:
                logger.error(f"❌ Ошибка при рассылке Zoom: {e}", exc_info=True)
                await query.message.edit_text("❌ Произошла ошибка при рассылке.")
            finally:
                session.close()
                
        except Exception as e:
            logger.error(f"❌ Ошибка в handle_send_zoom_to_all: {e}", exc_info=True)
            await query.message.edit_text("❌ Произошла ошибка при обработке запроса.")
    
    @staticmethod
    async def handle_meeting_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик выбора встречи для редактирования/удаления"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"🎯 handle_meeting_selection: {query.data}")
        
        try:
            parts = query.data.split('_')
            logger.debug(f"📝 Разобраны части callback_data: {parts}")
            
            if len(parts) < 2:
                logger.error(f"❌ Неправильный формат callback_data: {query.data}")
                await query.message.edit_text("❌ Ошибка: неправильный формат данных.")
                return
            
            action = parts[0]  # edit, delete, select
            
            if len(parts) == 3 and parts[1] == 'meeting':
                meeting_id_str = parts[2]
            elif len(parts) == 2:
                meeting_id_str = parts[1]
            else:
                logger.error(f"❌ Неправильный формат callback_data: {query.data}")
                await query.message.edit_text("❌ Ошибка: неправильный формат данных.")
                return
            
            if not meeting_id_str.isdigit():
                logger.error(f"❌ ID встречи не является числом: {meeting_id_str}")
                await query.message.edit_text("❌ Ошибка: неправильный ID встречи.")
                return
            
            meeting_id = int(meeting_id_str)
            logger.debug(f"🆔 Получен ID встречи: {meeting_id}")
            
            engine = context.bot_data.get('engine')
            if not engine:
                logger.error("❌ Engine не найден в bot_data")
                await query.message.edit_text("❌ Ошибка подключения к базе данных.")
                return
            
            session = get_session(engine)
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            
            if not meeting:
                logger.error(f"❌ Встреча не найдена в БД: ID {meeting_id}")
                await query.message.edit_text("❌ Встреча не найдена.")
                session.close()
                return
            
            logger.debug(f"✅ Встреча найдена: '{meeting.title}' (ID: {meeting.id})")
            
            if action == 'edit':
                from keyboards import get_meeting_detail_keyboard
                
                text = f"""<b>📅 Детали встречи:</b>

🏷️ <b>Название:</b> {meeting.title}
📅 <b>Дата и время:</b> {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
⏱️ <b>Продолжительность:</b> {meeting.duration} мин
📝 <b>Описание:</b> {meeting.description or 'нет'}
🔗 <b>Zoom ссылка:</b> {'✅ есть' if meeting.zoom_link else '❌ нет'}
📊 <b>Статус:</b> {'✅ активна' if meeting.is_active else '⏸️ неактивна'}

🆔 <b>ID встречи:</b> {meeting.id}"""
                
                try:
                    await query.message.edit_text(
                        text,
                        reply_markup=get_meeting_detail_keyboard(meeting_id),
                        parse_mode='HTML'
                    )
                    logger.debug(f"✅ Детали встречи показаны для редактирования")
                except Exception as edit_error:
                    if "Message is not modified" in str(edit_error):
                        logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
                    else:
                        logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                        await query.message.reply_text(
                            text,
                            reply_markup=get_meeting_detail_keyboard(meeting_id),
                            parse_mode='HTML'
                        )
            
            elif action == 'delete':
                text = f"""<b>⚠️ Подтверждение удаления</b>

Вы уверены, что хотите удалить встречу?

<b>Название:</b> {meeting.title}
<b>Дата:</b> {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
<b>ID:</b> {meeting.id}

<b>Это действие нельзя отменить!</b>"""
                
                try:
                    await query.message.edit_text(
                        text,
                        reply_markup=get_delete_confirmation_keyboard(meeting_id),
                        parse_mode='HTML'
                    )
                    logger.debug(f"✅ Запрос подтверждения удаления показан")
                except Exception as edit_error:
                    if "Message is not modified" in str(edit_error):
                        logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
                    else:
                        logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                        await query.message.reply_text(
                            text,
                            reply_markup=get_delete_confirmation_keyboard(meeting_id),
                            parse_mode='HTML'
                        )
            
            elif action == 'select':
                text = f"""<b>📅 Детали встречи:</b>

🏷️ <b>Название:</b> {meeting.title}
📅 <b>Дата и время:</b> {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
⏱️ <b>Продолжительность:</b> {meeting.duration} мин
📝 <b>Описание:</b> {meeting.description or 'нет'}
🔗 <b>Zoom ссылка:</b> {'✅ есть' if meeting.zoom_link else '❌ нет'}

🆔 <b>ID встречи:</b> {meeting.id}"""
                
                try:
                    await query.message.edit_text(
                        text,
                        reply_markup=get_back_keyboard('meetings_list'),
                        parse_mode='HTML'
                    )
                    logger.debug(f"✅ Детали встречи показаны для просмотра")
                except Exception as edit_error:
                    if "Message is not modified" in str(edit_error):
                        logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
                    else:
                        logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                        await query.message.reply_text(
                            text,
                            reply_markup=get_back_keyboard('meetings_list'),
                            parse_mode='HTML'
                        )
            
            session.close()
            logger.debug("🔒 Сессия БД закрыта")
            
        except Exception as e:
            if "Message is not modified" not in str(e):
                logger.error(f"❌ Ошибка при обработке выбора встречи: {e}", exc_info=True)
                await query.message.edit_text("❌ Ошибка при обработке запроса.")
    
    @staticmethod
    async def add_zoom_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Добавление Zoom ссылки - выбор режима"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"🔗 add_zoom_link вызван: {query.data}")
        
        try:
            parts = query.data.split('_')
            logger.debug(f"📝 Разобраны части callback_data: {parts}")
            
            if len(parts) < 3:
                logger.error(f"❌ Неправильный формат для добавления Zoom: {query.data}")
                await query.message.edit_text("❌ Ошибка: неправильный формат данных.")
                return
            
            meeting_id = int(parts[2])
            logger.debug(f"🆔 Получен ID встречи для Zoom: {meeting_id}")
            
            engine = context.bot_data.get('engine')
            if not engine:
                logger.error("❌ Engine не найден в bot_data")
                await query.message.edit_text("❌ Ошибка подключения к базе данных.")
                return
            
            session = get_session(engine)
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            
            if not meeting:
                logger.error(f"❌ Встреча не найдена: ID {meeting_id}")
                await query.message.edit_text("❌ Встреча не найдена.")
                session.close()
                return
            
            logger.info(f"✅ Встреча для Zoom найдена: '{meeting.title}'")
            
            from zoom_integration import get_zoom_instance
            zoom = get_zoom_instance()
            
            logger.debug(f"📡 Zoom instance получен: {zoom is not None}")
            
            text = f"""<b>🔗 Добавление Zoom ссылки</b>

Для встречи: <b>{meeting.title}</b>
Дата: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}

<b>Выберите способ:</b>

1. <b>🤖 Автосоздание через API</b>
   • Создаст встречу в Zoom автоматически
   • Сгенерирует безопасный пароль
   • Настроит автоматическую запись"""
            
            if not zoom:
                text += "\n\n⚠️ <i>Zoom API не настроен. Доступен только ручной ввод.</i>"
                logger.warning("⚠️ Zoom API не настроен, показываем только ручной ввод")
            
            text += """

2. <b>👤 Ввести ссылку вручную</b>
   • Используйте существующую ссылку
   • Можно добавить ссылку из личного аккаунта"""

            keyboard = get_zoom_mode_keyboard(meeting_id)
            
            try:
                await query.message.edit_text(
                    text,
                    reply_markup=keyboard,
                    parse_mode='HTML'
                )
            except Exception as edit_error:
                if "Message is not modified" in str(edit_error):
                    logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
                else:
                    logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                    await query.message.reply_text(
                        text,
                        reply_markup=keyboard,
                        parse_mode='HTML'
                    )
            
            logger.info(f"✅ Меню выбора режима Zoom показано для встречи {meeting_id}")
            session.close()
            
        except Exception as e:
            logger.error(f"❌ Ошибка при добавлении Zoom: {e}", exc_info=True)
            await query.message.edit_text("❌ Ошибка при обработке запроса.")
    
    @staticmethod
    async def handle_auto_zoom(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Автоматическое создание Zoom встречи через API"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"🤖 НАЧАЛО handle_auto_zoom: callback_data = {query.data}")
        
        try:
            parts = query.data.split('_')
            logger.debug(f"📝 Разобраны части callback_data: {parts}")
            
            if len(parts) < 3:
                logger.error(f"❌ Неправильный формат для auto_zoom: {query.data}")
                await query.message.edit_text("❌ Ошибка: неправильный формат данных.")
                return
            
            meeting_id = int(parts[2])
            logger.info(f"🆔 ID встречи для автосоздания Zoom: {meeting_id}")
            
            engine = context.bot_data.get('engine')
            if not engine:
                logger.error("❌ Engine не найден в bot_data")
                await query.message.edit_text("❌ Ошибка подключения к базе данных.")
                return
            
            session = get_session(engine)
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            
            if not meeting:
                logger.error(f"❌ Встреча не найдена: ID {meeting_id}")
                await query.message.edit_text("❌ Встреча не найдена.")
                session.close()
                return
            
            logger.info(f"✅ Встреча найдена: '{meeting.title}'")
            
            try:
                await query.message.edit_text(
                    f"🔄 <b>Создаю Zoom встречу...</b>\n\n"
                    f"Тема: {meeting.title}\n"
                    f"Время: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}\n\n"
                    f"<i>Это может занять несколько секунд.</i>",
                    parse_mode='HTML'
                )
            except Exception as edit_error:
                if "Message is not modified" not in str(edit_error):
                    logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                    await query.message.reply_text(
                        f"🔄 <b>Создаю Zoom встречу...</b>\n\n"
                        f"Тема: {meeting.title}\n"
                        f"Время: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}\n\n"
                        f"<i>Это может занять несколько секунд.</i>",
                        parse_mode='HTML'
                    )
            
            from zoom_integration import create_zoom_meeting
            
            try:
                zoom_result = await create_zoom_meeting(
                    topic=meeting.title,
                    start_time=meeting.date_time,
                    duration=meeting.duration
                )
                
                if not zoom_result:
                    logger.error("❌ zoom_result пустой (None)")
                    error_text = """❌ <b>Ошибка создания Zoom встречи</b>

Возможные причины:
1. Неправильные API ключи в .env
2. Проблемы с сетью
3. Ошибка API Zoom
4. Нет платного аккаунта Zoom

Проверьте логи бота для деталей.
Попробуйте ввести ссылку вручную."""
                    
                    try:
                        await query.message.edit_text(
                            error_text,
                            reply_markup=get_cancel_keyboard('meetings_list'),
                            parse_mode='HTML'
                        )
                    except:
                        await query.message.reply_text(
                            error_text,
                            reply_markup=get_cancel_keyboard('meetings_list'),
                            parse_mode='HTML'
                        )
                    session.close()
                    return
                
                meeting.zoom_link = zoom_result['join_url']
                meeting.zoom_meeting_id = zoom_result['id']
                meeting.zoom_password = zoom_result['password']
                
                session.commit()
                logger.info(f"✅ Данные сохранены в БД:")
                logger.info(f"   Zoom ID: {zoom_result['id']}")
                logger.info(f"   Ссылка: {zoom_result['join_url']}")
                logger.info(f"   Пароль: {zoom_result['password']}")
                
                text = f"""✅ <b>Zoom встреча создана!</b>

🏷️ <b>Тема:</b> {zoom_result['topic']}
🔗 <b>Ссылка для участников:</b>
<code>{zoom_result['join_url']}</code>

🔑 <b>Пароль:</b> <code>{zoom_result['password']}</code>

⏰ <b>Дата:</b> {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
⏱️ <b>Длительность:</b> {meeting.duration} мин

<b>Дополнительно:</b>
• Запись будет сохранена в облако
• Участники не смогут зайти до хоста
• Можно добавить в календарь через ссылку"""

                keyboard = get_zoom_success_keyboard(meeting_id)
                
                try:
                    await query.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')
                except:
                    await query.message.reply_text(text, reply_markup=keyboard, parse_mode='HTML')
                    
                logger.info(f"🎉 Zoom встреча создана для meeting_id {meeting_id}: {zoom_result['id']}")
                
            except Exception as zoom_error:
                logger.error(f"❌ Ошибка при вызове create_zoom_meeting: {zoom_error}", exc_info=True)
                error_details = str(zoom_error)[:200]
                error_text = f"""❌ <b>Исключение при создании Zoom:</b>
{error_details}

Попробуйте ввести ссылку вручную."""
                
                try:
                    await query.message.edit_text(
                        error_text,
                        reply_markup=get_cancel_keyboard('meetings_list'),
                        parse_mode='HTML'
                    )
                except:
                    await query.message.reply_text(
                        error_text,
                        reply_markup=get_cancel_keyboard('meetings_list'),
                        parse_mode='HTML'
                    )
            
            session.close()
            
        except Exception as e:
            logger.error(f"❌ Общая ошибка в handle_auto_zoom: {e}", exc_info=True)
            error_details = str(e)[:100]
            error_text = f"""❌ <b>Ошибка:</b> {error_details}

Попробуйте ввести ссылку вручную."""
            
            try:
                await query.message.edit_text(
                    error_text,
                    reply_markup=get_cancel_keyboard('meetings_list'),
                    parse_mode='HTML'
                )
            except:
                await query.message.reply_text(
                    error_text,
                    reply_markup=get_cancel_keyboard('meetings_list'),
                    parse_mode='HTML'
                )
    
    @staticmethod
    async def handle_manual_zoom(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Ручной ввод Zoom ссылки"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"👤 handle_manual_zoom вызван: {query.data}")
        
        try:
            meeting_id = int(query.data.split('_')[2])
            logger.debug(f"🆔 Получен ID встречи для ручного Zoom: {meeting_id}")
            
            engine = context.bot_data.get('engine')
            if not engine:
                logger.error("❌ Engine не найден в bot_data")
                await query.message.edit_text("❌ Ошибка подключения к базе данных.")
                return
            
            session = get_session(engine)
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            
            if not meeting:
                logger.error(f"❌ Встреча не найдена: ID {meeting_id}")
                await query.message.edit_text("❌ Встреча не найдена.")
                session.close()
                return
            
            logger.info(f"✅ Встреча для ручного Zoom найдена: '{meeting.title}'")
            
            text = f"""<b>🔗 Ввод Zoom ссылки вручную</b>

Для встречи: <b>{meeting.title}</b>
Дата: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}

<b>Отправьте Zoom ссылку в следующем сообщении.</b>

<b>Формат ссылки:</b>
<code>https://zoom.us/j/1234567890</code>
<code>https://us04web.zoom.us/j/1234567890</code>

<b>Пароль можно добавить через пробел:</b>
<code>https://zoom.us/j/1234567890 пароль123</code>

<b>Или добавить пароль позже.</b>"""
            
            context.user_data['adding_zoom_to'] = meeting_id
            context.user_data['zoom_mode'] = 'manual'
            
            logger.debug(f"📝 Сохранено в user_data: adding_zoom_to={meeting_id}, zoom_mode=manual")
            
            try:
                await query.message.edit_text(
                    text,
                    reply_markup=get_cancel_keyboard('meetings_list'),
                    parse_mode='HTML'
                )
            except Exception as edit_error:
                if "Message is not modified" not in str(edit_error):
                    logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                    await query.message.reply_text(
                        text,
                        reply_markup=get_cancel_keyboard('meetings_list'),
                        parse_mode='HTML'
                    )
            
            logger.info(f"✅ Запрос ручного ввода Zoom отправлен для встречи {meeting_id}")
            session.close()
            
        except Exception as e:
            logger.error(f"❌ Ошибка при запросе ручного ввода Zoom: {e}", exc_info=True)
            await query.message.edit_text("❌ Ошибка при обработке запроса.")
    
    @staticmethod
    async def process_manual_zoom_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка текста с Zoom ссылкой от пользователя"""
        user_id = update.effective_user.id
        text = update.message.text.strip()
        
        logger.info(f"📝 process_manual_zoom_text: сообщение от {user_id}: '{text}'")
        
        if 'adding_zoom_to' not in context.user_data or 'zoom_mode' not in context.user_data:
            logger.warning(f"⚠️ Нет ожидания Zoom ссылки в user_data")
            return False
        
        meeting_id = context.user_data['adding_zoom_to']
        zoom_mode = context.user_data['zoom_mode']
        
        if zoom_mode != 'manual':
            logger.warning(f"⚠️ Неправильный режим Zoom: {zoom_mode}")
            return False
        
        logger.info(f"📝 Обработка Zoom ссылки для встречи {meeting_id}: {text}")
        
        engine = context.bot_data.get('engine')
        if not engine:
            await update.message.reply_text("❌ Ошибка подключения к базе данных.")
            return True
        
        session = get_session(engine)
        
        try:
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            if not meeting:
                await update.message.reply_text("❌ Встреча не найдена.")
                return True
            
            zoom_link = text
            zoom_password = None
            
            if ' ' in text:
                parts = text.split(' ', 1)
                zoom_link = parts[0].strip()
                zoom_password = parts[1].strip()
                logger.debug(f"📝 Извлечен пароль: {zoom_password}")
            
            if not (zoom_link.startswith('http://') or zoom_link.startswith('https://')):
                zoom_link = f"https://{zoom_link}"
                logger.debug(f"📝 Добавлен протокол: {zoom_link}")
            
            if 'zoom.us' not in zoom_link and 'zoom.com' not in zoom_link:
                await update.message.reply_text(
                    "❌ Это не похоже на Zoom ссылку. "
                    "Ссылка должна содержать 'zoom.us' или 'zoom.com'.\n"
                    "Попробуйте еще раз:"
                )
                return True
            
            meeting.zoom_link = zoom_link
            if zoom_password:
                meeting.zoom_password = zoom_password
            session.commit()
            
            logger.info(f"✅ Zoom ссылка сохранена для встречи {meeting_id}: {zoom_link}")
            
            del context.user_data['adding_zoom_to']
            del context.user_data['zoom_mode']
            
            await update.message.reply_text(
                f"✅ <b>Zoom ссылка сохранена!</b>\n\n"
                f"Для встречи: <b>{meeting.title}</b>\n"
                f"Ссылка: {zoom_link}\n"
                f"Пароль: {zoom_password or 'не указан'}\n\n"
                f"Можете поделиться ссылкой с участниками.",
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("📤 Поделиться ссылкой", callback_data=f'zoom_share_{meeting_id}')],
                    [InlineKeyboardButton("◀️ Назад к встрече", callback_data=f'edit_{meeting_id}')]
                ])
            )
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка при сохранении Zoom: {e}", exc_info=True)
            await update.message.reply_text(f"❌ Ошибка при сохранении: {str(e)[:100]}")
            return True
        finally:
            session.close()
    
    @staticmethod
    async def handle_zoom_share(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Поделиться Zoom ссылкой"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"📤 handle_zoom_share вызван: {query.data}")
        
        try:
            meeting_id = int(query.data.split('_')[2])
            logger.debug(f"🆔 Получен ID встречи для шаринга: {meeting_id}")
            
            engine = context.bot_data.get('engine')
            if not engine:
                logger.error("❌ Engine не найден в bot_data")
                await query.message.edit_text("❌ Ошибка подключения к базе данных.")
                return
            
            session = get_session(engine)
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            
            if not meeting:
                logger.error(f"❌ Встреча не найдена: ID {meeting_id}")
                await query.message.edit_text("❌ Встреча не найдена.")
                session.close()
                return
            
            if not meeting.zoom_link:
                logger.warning(f"⚠️ У встречи {meeting_id} нет Zoom ссылки")
                await query.message.edit_text(
                    "❌ У этой встречи нет Zoom ссылки.\n"
                    "Сначала добавьте ссылку через меню.",
                    reply_markup=get_back_keyboard('meetings_list')
                )
                session.close()
                return
            
            logger.info(f"✅ Найдена встреча с Zoom: '{meeting.title}'")
            
            text = f"""<b>📋 Информация для участников</b>

<b>Тема:</b> {meeting.title}
<b>Дата и время:</b> {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
<b>Длительность:</b> {meeting.duration} минут

<b>🔗 Ссылка для входа:</b>
<code>{meeting.zoom_link}</code>"""
            
            if meeting.zoom_password:
                text += f"\n\n<b>🔑 Пароль:</b> <code>{meeting.zoom_password}</code>"
                logger.debug(f"🔑 Пароль встречи: {meeting.zoom_password}")
            
            text += f"\n\n<b>📅 Добавьте в календарь:</b>"
            text += f"\n<code>{meeting.date_time.strftime('%Y-%m-%dT%H:%M:%S')}</code>"
            
            keyboard = get_zoom_share_keyboard(meeting_id)
            
            try:
                await query.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')
            except Exception as edit_error:
                if "Message is not modified" not in str(edit_error):
                    logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                    await query.message.reply_text(text, reply_markup=keyboard, parse_mode='HTML')
                    
            logger.info(f"✅ Информация о Zoom отправлена для встречи {meeting_id}")
            session.close()
            
        except Exception as e:
            logger.error(f"❌ Ошибка при показе Zoom информации: {e}", exc_info=True)
            await query.message.edit_text("❌ Ошибка при обработке запроса.")
    
    @staticmethod
    async def handle_edit_meeting_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Меню для редактирования встреч"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"✏️ handle_edit_meeting_menu вызван: {query.data}")
        
        engine = context.bot_data.get('engine')
        if not engine:
            logger.error("❌ Engine не найден в bot_data")
            await query.message.edit_text("❌ Ошибка подключения к базе данных.")
            return
        
        session = get_session(engine)
        
        try:
            meetings = session.query(Meeting).order_by(Meeting.date_time).all()
            logger.debug(f"📊 Найдено встреч для редактирования: {len(meetings)}")
            
            if not meetings:
                logger.warning("⚠️ Нет встреч для редактирования")
                try:
                    await query.message.edit_text(
                        "❌ Нет встреч для редактирования.",
                        reply_markup=get_meetings_list_keyboard()
                    )
                except Exception as edit_error:
                    if "Message is not modified" in str(edit_error):
                        logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
                    else:
                        logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                        await query.message.reply_text(
                            "❌ Нет встреч для редактирования.",
                            reply_markup=get_meetings_list_keyboard()
                        )
                return
            
            text = "<b>📋 Выберите встречу для редактирования:</b>\n\n"
            
            try:
                await query.message.edit_text(
                    text,
                    reply_markup=get_meeting_selection_keyboard(meetings, action_prefix='edit_'),
                    parse_mode='HTML'
                )
            except Exception as edit_error:
                if "Message is not modified" in str(edit_error):
                    logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
                else:
                    logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                    await query.message.reply_text(
                        text,
                        reply_markup=get_meeting_selection_keyboard(meetings, action_prefix='edit_'),
                        parse_mode='HTML'
                    )
            
            logger.info(f"✅ Меню редактирования показано ({len(meetings)} встреч)")
            
        except Exception as e:
            if "Message is not modified" not in str(e):
                logger.error(f"❌ Ошибка при отображении меню редактирования: {e}", exc_info=True)
                await query.message.edit_text("❌ Ошибка при загрузке списка встреч.")
        finally:
            session.close()
            logger.debug("🔒 Сессия БД закрыта")
    
    @staticmethod
    async def handle_delete_meeting_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Меню для удаления встреч"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"🗑️ handle_delete_meeting_menu вызван: {query.data}")
        
        engine = context.bot_data.get('engine')
        if not engine:
            logger.error("❌ Engine не найден в bot_data")
            await query.message.edit_text("❌ Ошибка подключения к базе данных.")
            return
        
        session = get_session(engine)
        
        try:
            meetings = session.query(Meeting).order_by(Meeting.date_time).all()
            logger.debug(f"📊 Найдено встреч для удаления: {len(meetings)}")
            
            if not meetings:
                logger.warning("⚠️ Нет встреч для удаления")
                try:
                    await query.message.edit_text(
                        "❌ Нет встреч для удаления.",
                        reply_markup=get_meetings_list_keyboard()
                    )
                except Exception as edit_error:
                    if "Message is not modified" in str(edit_error):
                        logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
                    else:
                        logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                        await query.message.reply_text(
                            "❌ Нет встреч для удаления.",
                            reply_markup=get_meetings_list_keyboard()
                        )
                return
            
            text = "<b>📋 Выберите встречу для удаления:</b>\n\n"
            
            try:
                await query.message.edit_text(
                    text,
                    reply_markup=get_meeting_selection_keyboard(meetings, action_prefix='delete_'),
                    parse_mode='HTML'
                )
            except Exception as edit_error:
                if "Message is not modified" in str(edit_error):
                    logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
                else:
                    logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                    await query.message.reply_text(
                        text,
                        reply_markup=get_meeting_selection_keyboard(meetings, action_prefix='delete_'),
                        parse_mode='HTML'
                    )
            
            logger.info(f"✅ Меню удаления показано ({len(meetings)} встреч)")
            
        except Exception as e:
            if "Message is not modified" not in str(e):
                logger.error(f"❌ Ошибка при отображении меню удаления: {e}", exc_info=True)
                await query.message.edit_text("❌ Ошибка при загрузке списка встреч.")
        finally:
            session.close()
            logger.debug("🔒 Сессия БД закрыта")
    
    @staticmethod
    async def handle_edit_meeting_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик действий редактирования встречи"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"🔧 handle_edit_meeting_action вызван: {query.data}")
        
        parts = query.data.split('_')
        logger.debug(f"📝 Разобраны части callback_data: {parts}")
        
        if len(parts) < 4:
            logger.error(f"❌ Неправильный формат для редактирования: {query.data}")
            await query.message.edit_text("❌ Ошибка: неправильный формат данных.")
            return
        
        action_type = parts[2]  # title, date, duration, description, status, zoom
        meeting_id_str = parts[3]
        
        logger.debug(f"🛠️ Тип действия: {action_type}, ID строкой: {meeting_id_str}")
        
        if not meeting_id_str.isdigit():
            logger.error(f"❌ ID встречи не является числом: {meeting_id_str}")
            await query.message.edit_text("❌ Ошибка: неправильный ID встречи.")
            return
        
        meeting_id = int(meeting_id_str)
        context.user_data['editing_meeting'] = meeting_id
        context.user_data['edit_action'] = action_type
        
        logger.debug(f"📝 Сохранено в user_data: editing_meeting={meeting_id}, edit_action={action_type}")
        
        engine = context.bot_data.get('engine')
        if not engine:
            logger.error("❌ Engine не найден в bot_data")
            await query.message.edit_text("❌ Ошибка подключения к базе данных.")
            return
        
        session = get_session(engine)
        meeting = session.query(Meeting).filter_by(id=meeting_id).first()
        
        if not meeting:
            logger.error(f"❌ Встреча не найдена: ID {meeting_id}")
            await query.message.edit_text("❌ Встреча не найдена.")
            session.close()
            return
        
        logger.info(f"✅ Встреча для редактирования найдена: '{meeting.title}'")
        
        if action_type == 'title':
            text = f"""<b>✏️ Редактирование названия</b>

Текущее название: <b>{meeting.title}</b>

Введите новое название встречи:"""
            
        elif action_type == 'date':
            text = f"""<b>📅 Редактирование даты и времени</b>

Текущая дата: <b>{meeting.date_time.strftime('%d.%m.%Y %H:%M')}</b>

Введите новую дату и время в формате:
<b>ДД.ММ.ГГГГ ЧЧ:ММ</b>
Пример: 25.12.2023 19:00"""
            
        elif action_type == 'duration':
            text = f"""<b>⏱️ Редактирование продолжительности</b>

Текущая продолжительность: <b>{meeting.duration} минут</b>

Введите новую продолжительность в минутах:"""
            
        elif action_type == 'description':
            text = f"""<b>📝 Редактирование описания</b>

Текущее описание:
{meeting.description or 'Нет описания'}

Введите новое описание:"""
            
        elif action_type == 'status':
            current_status = "активна" if meeting.is_active else "неактивна"
            new_status = "неактивна" if meeting.is_active else "активна"
            
            text = f"""<b>📊 Изменение статуса</b>

Текущий статус: <b>{current_status}</b>

Хотите изменить статус на <b>{new_status}</b>?"""
            
            try:
                await query.message.edit_text(
                    text,
                    reply_markup=get_status_change_keyboard(meeting_id),
                    parse_mode='HTML'
                )
            except Exception as edit_error:
                if "Message is not modified" not in str(edit_error):
                    logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                    await query.message.reply_text(
                        text,
                        reply_markup=get_status_change_keyboard(meeting_id),
                        parse_mode='HTML'
                    )
                    
            logger.info(f"✅ Меню изменения статуса показано для встречи {meeting_id}")
            session.close()
            return
            
        elif action_type == 'zoom':
            if meeting.zoom_link:
                text = f"""<b>🔗 Редактирование Zoom ссылки</b>

Текущая ссылка: <b>{meeting.zoom_link}</b>

Введите новую Zoom ссылку:"""
            else:
                text = """<b>🔗 Добавление Zoom ссылки</b>

У этой встречи еще нет Zoom ссылки.
Введите Zoom ссылку:"""
        
        try:
            await query.message.edit_text(
                text,
                reply_markup=get_cancel_keyboard('meetings_list'),
                parse_mode='HTML'
            )
        except Exception as edit_error:
            if "Message is not modified" not in str(edit_error):
                logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                await query.message.reply_text(
                    text,
                    reply_markup=get_cancel_keyboard('meetings_list'),
                    parse_mode='HTML'
                )
        
        logger.info(f"✅ Форма редактирования '{action_type}' показана для встречи {meeting_id}")
        session.close()
        logger.debug("🔒 Сессия БД закрыта")
    
    @staticmethod
    async def handle_delete_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик подтверждения удаления ВСТРЕЧИ"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"⚠️ handle_delete_confirmation (встреча) вызван: {query.data}")
        
        # ИСПРАВЛЕНО: Новый формат - confirm_delete_meeting_123
        parts = query.data.split('_')
        logger.debug(f"📝 Разобраны части callback_data: {parts}")
        
        # Проверяем, что это именно удаление встречи
        if len(parts) < 4 or parts[2] != 'meeting':
            logger.error(f"❌ Неправильный формат для удаления встречи: {query.data}")
            await query.message.edit_text("❌ Ошибка: неправильный формат данных.")
            return
        
        meeting_id_str = parts[3]
        
        if not meeting_id_str.isdigit():
            logger.error(f"❌ ID встречи не является числом: {meeting_id_str}")
            await query.message.edit_text("❌ Ошибка: неправильный ID встречи.")
            return
        
        meeting_id = int(meeting_id_str)
        logger.info(f"🆔 ID встречи для удаления: {meeting_id}")
        
        engine = context.bot_data.get('engine')
        if not engine:
            logger.error("❌ Engine не найден в bot_data")
            await query.message.edit_text("❌ Ошибка подключения к базе данных.")
            return
        
        session = get_session(engine)
        
        try:
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            
            if not meeting:
                logger.error(f"❌ Встреча не найдена: ID {meeting_id}")
                await query.message.edit_text("❌ Встреча не найдена.")
                return
            
            logger.info(f"✅ Встреча для удаления найдена: '{meeting.title}'")
            
            session.delete(meeting)
            session.commit()
            
            logger.info(f"🗑️ Встреча удалена: ID {meeting_id}, название: '{meeting.title}'")
            
            text = f"""✅ <b>Встреча успешно удалена</b>

<b>Название:</b> {meeting.title}
<b>Дата:</b> {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
<b>ID:</b> {meeting.id}"""
            
            try:
                await query.message.edit_text(
                    text,
                    reply_markup=get_back_keyboard('meetings_list'),
                    parse_mode='HTML'
                )
            except Exception as edit_error:
                if "Message is not modified" not in str(edit_error):
                    logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                    await query.message.reply_text(
                        text,
                        reply_markup=get_back_keyboard('meetings_list'),
                        parse_mode='HTML'
                    )
            
            logger.info(f"✅ Сообщение об удалении отправлено")
            
        except Exception as e:
            logger.error(f"❌ Ошибка при удалении встречи: {e}", exc_info=True)
            session.rollback()
            await query.message.edit_text("❌ Ошибка при удалении встречи.")
        finally:
            session.close()
            logger.debug("🔒 Сессия БД закрыта")
    
    @staticmethod
    async def handle_cancel_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Отмена удаления ВСТРЕЧИ"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"❌ handle_cancel_delete (встреча) вызван: {query.data}")
        
        try:
            await query.message.edit_text(
                "❌ Удаление встречи отменено.",
                reply_markup=get_back_keyboard('meetings_list')
            )
            logger.info(f"✅ Удаление встречи отменено")
        except Exception as edit_error:
            if "Message is not modified" in str(edit_error):
                logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
            else:
                logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                await query.message.reply_text(
                    "❌ Удаление встречи отменено.",
                    reply_markup=get_back_keyboard('meetings_list')
                )
    
    @staticmethod
    async def handle_cancel_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Отмена любого действия"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"❌ handle_cancel_action вызван: {query.data}")
        
        if 'editing_meeting' in context.user_data:
            logger.debug(f"🗑️ Удаляю из user_data: editing_meeting={context.user_data['editing_meeting']}")
            del context.user_data['editing_meeting']
        if 'edit_action' in context.user_data:
            logger.debug(f"🗑️ Удаляю из user_data: edit_action={context.user_data['edit_action']}")
            del context.user_data['edit_action']
        if 'adding_zoom_to' in context.user_data:
            logger.debug(f"🗑️ Удаляю из user_data: adding_zoom_to={context.user_data['adding_zoom_to']}")
            del context.user_data['adding_zoom_to']
        if 'zoom_mode' in context.user_data:
            logger.debug(f"🗑️ Удаляю из user_data: zoom_mode={context.user_data['zoom_mode']}")
            del context.user_data['zoom_mode']
        
        try:
            await query.message.edit_text(
                "❌ Действие отменено.",
                reply_markup=get_back_keyboard('meetings_list')
            )
            logger.info(f"✅ Действие отменено")
        except Exception as edit_error:
            if "Message is not modified" in str(edit_error):
                logger.debug("📝 Сообщение не изменилось, пропускаем ошибку")
            else:
                logger.error(f"❌ Ошибка при редактировании сообщения: {edit_error}")
                await query.message.reply_text(
                    "❌ Действие отменено.",
                    reply_markup=get_back_keyboard('meetings_list')
                )
    
    @staticmethod
    async def start_add_meeting_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Начало создания встречи через callback"""
        query = update.callback_query
        await query.answer()
        
        logger.info(f"📅 start_add_meeting_callback вызван: {query.data}")
        
        text = """<b>📅 Создание новой встречи</b>

Введите название встречи:"""
        
        try:
            await query.message.edit_text(text, parse_mode='HTML')
        except:
            await query.message.reply_text(text, parse_mode='HTML')
            
        logger.info(f"✅ Форма создания встречи показана")
        return ADD_TITLE

# Conversation handler для создания встречи
async def start_add_meeting(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начало создания новой встречи через команду"""
    logger.info(f"📅 start_add_meeting вызван пользователем {update.effective_user.id}")
    
    text = """<b>📅 Создание новой встречи</b>

Введите название встречи:"""
    
    await update.message.reply_text(text, parse_mode='HTML')
    logger.info(f"✅ Форма создания встречи показана (через команду)")
    return ADD_TITLE

async def add_meeting_title(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Добавление названия встречи"""
    title = update.message.text.strip()
    logger.debug(f"📝 Введено название: '{title}'")
    
    if len(title) < 2:
        logger.warning(f"⚠️ Слишком короткое название: '{title}'")
        await update.message.reply_text("❌ Название должно содержать хотя бы 2 символа. Попробуйте еще раз:")
        return ADD_TITLE
    
    context.user_data['meeting_title'] = title
    logger.debug(f"📝 Сохранено в user_data: meeting_title='{title}'")
    
    text = f"""✅ <b>Название сохранено:</b> {title}

Теперь введите дату и время встречи в формате:
<b>ДД.ММ.ГГГГ ЧЧ:ММ</b>
Пример: 25.12.2023 19:00"""
    
    await update.message.reply_text(text, parse_mode='HTML')
    logger.info(f"✅ Название сохранено, запрашиваю дату")
    return ADD_DATE

async def add_meeting_date(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Добавление даты и времени встречи"""
    date_str = update.message.text.strip()
    logger.debug(f"📝 Введена дата: '{date_str}'")
    
    try:
        formats = ['%d.%m.%Y %H:%M', '%d.%m.%Y %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d %H:%M:%S']
        
        date_time = None
        for fmt in formats:
            try:
                date_time = datetime.strptime(date_str, fmt)
                logger.debug(f"✅ Дата распознана в формате {fmt}")
                break
            except ValueError:
                continue
        
        if not date_time:
            raise ValueError("Неправильный формат даты")
        
        if date_time < datetime.now():
            logger.warning(f"⚠️ Дата в прошлом: {date_time}")
            await update.message.reply_text("❌ Дата должна быть в будущем. Введите корректную дату:")
            return ADD_DATE
        
        context.user_data['meeting_date'] = date_time
        logger.debug(f"📝 Сохранено в user_data: meeting_date={date_time}")
        
        text = f"""✅ <b>Дата сохранена:</b> {date_time.strftime('%d.%m.%Y %H:%M')}

Теперь введите продолжительность встречи в минутах:
Пример: 90 (для 1.5 часов)"""
        
        await update.message.reply_text(text, parse_mode='HTML')
        logger.info(f"✅ Дата сохранена, запрашиваю продолжительность")
        return ADD_DURATION
        
    except Exception as e:
        logger.error(f"❌ Ошибка при разборе даты '{date_str}': {e}")
        await update.message.reply_text("❌ Неправильный формат даты. Используйте формат ДД.ММ.ГГГГ ЧЧ:ММ\nПопробуйте еще раз:")
        return ADD_DATE

async def add_meeting_duration(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Добавление продолжительности встречи"""
    duration_str = update.message.text.strip()
    logger.debug(f"📝 Введена продолжительность: '{duration_str}'")
    
    try:
        duration = int(duration_str)
        
        if duration <= 0:
            logger.warning(f"⚠️ Некорректная продолжительность: {duration}")
            await update.message.reply_text("❌ Продолжительность должна быть положительным числом. Попробуйте еще раз:")
            return ADD_DURATION
        
        if duration > 1440:
            logger.warning(f"⚠️ Слишком большая продолжительность: {duration} мин")
            await update.message.reply_text("❌ Продолжительность не может превышать 24 часа (1440 минут). Попробуйте еще раз:")
            return ADD_DURATION
        
        context.user_data['meeting_duration'] = duration
        logger.debug(f"📝 Сохранено в user_data: meeting_duration={duration}")
        
        text = f"""✅ <b>Продолжительность сохранена:</b> {duration} минут

Теперь введите описание встречи (или отправьте /skip чтобы пропустить):"""
        
        await update.message.reply_text(text, parse_mode='HTML')
        logger.info(f"✅ Продолжительность сохранена, запрашиваю описание")
        return ADD_DESCRIPTION
        
    except ValueError:
        logger.error(f"❌ Продолжительность не является числом: '{duration_str}'")
        await update.message.reply_text("❌ Продолжительность должна быть числом. Попробуйте еще раз:")
        return ADD_DURATION

async def add_meeting_description(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Добавление описания встречи"""
    description = update.message.text.strip()
    logger.debug(f"📝 Введено описание (длина: {len(description)}): '{description[:50]}...'")
    
    if description == '/skip':
        description = ""
        logger.debug("📝 Пользователь пропустил описание")
    
    context.user_data['meeting_description'] = description
    logger.debug(f"📝 Сохранено в user_data: meeting_description (длина: {len(description)})")
    
    text = f"""✅ <b>Описание сохранено</b>

Теперь введите Zoom ссылку (или отправьте /skip чтобы пропустить):
Пример: https://zoom.us/j/1234567890"""
    
    await update.message.reply_text(text, parse_mode='HTML')
    logger.info(f"✅ Описание сохранено, запрашиваю Zoom ссылку")
    return ADD_ZOOM

async def add_meeting_zoom(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Добавление Zoom ссылки и сохранение встречи"""
    zoom_link = update.message.text.strip()
    logger.debug(f"📝 Введена Zoom ссылка: '{zoom_link}'")
    
    if zoom_link == '/skip':
        zoom_link = None
        logger.debug("📝 Пользователь пропустил Zoom ссылку")
    elif not (zoom_link.startswith('http://') or zoom_link.startswith('https://')):
        zoom_link = f"https://{zoom_link}"
        logger.debug(f"📝 Добавлен протокол к Zoom ссылке: '{zoom_link}'")
    
    context.user_data['meeting_zoom'] = zoom_link
    logger.debug(f"📝 Сохранено в user_data: meeting_zoom='{zoom_link}'")
    
    title = context.user_data.get('meeting_title')
    date_time = context.user_data.get('meeting_date')
    duration = context.user_data.get('meeting_duration')
    description = context.user_data.get('meeting_description', '')
    zoom = context.user_data.get('meeting_zoom')
    
    logger.info(f"📋 Все данные для встречи собраны:")
    logger.info(f"   Название: '{title}'")
    logger.info(f"   Дата: {date_time}")
    logger.info(f"   Длительность: {duration} мин")
    logger.info(f"   Описание длина: {len(description)}")
    logger.info(f"   Zoom ссылка: {zoom}")
    
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("❌ Engine не найден в bot_data")
        await update.message.reply_text("❌ Ошибка подключения к базе данных.")
        return ConversationHandler.END
    
    session = get_session(engine)
    
    try:
        meeting = Meeting(
            title=title,
            date_time=date_time,
            duration=duration,
            description=description if description else None,
            zoom_link=zoom,
            is_active=True
        )
        
        session.add(meeting)
        session.commit()
        
        logger.info(f"✅ Встреча создана в БД: ID {meeting.id}")
        
        text = f"""✅ <b>Встреча успешно создана!</b>

🏷️ <b>Название:</b> {title}
📅 <b>Дата и время:</b> {date_time.strftime('%d.%m.%Y %H:%M')}
⏱️ <b>Продолжительность:</b> {duration} мин
📝 <b>Описание:</b> {description or 'нет'}
🔗 <b>Zoom ссылка:</b> {'✅ есть' if zoom else '❌ нет'}
🆔 <b>ID встречи:</b> {meeting.id}"""
        
        if not zoom:
            from keyboards import get_meeting_detail_keyboard
            keyboard = get_meeting_detail_keyboard(meeting.id)
            logger.debug("📝 Zoom ссылки нет, показываю кнопку для добавления")
        else:
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад к списку", callback_data='meetings_list')]
            ])
        
        await update.message.reply_text(text, parse_mode='HTML', reply_markup=keyboard)
        logger.info(f"✅ Сообщение о создании встречи отправлено")
        
        context.user_data.clear()
        logger.debug("🗑️ User_data очищен")
        
    except Exception as e:
        logger.error(f"❌ Ошибка при создании встречи: {e}", exc_info=True)
        session.rollback()
        await update.message.reply_text("❌ Ошибка при создании встречи.")
    finally:
        session.close()
        logger.debug("🔒 Сессия БД закрыта")
    
    return ConversationHandler.END

async def cancel_add_meeting(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отмена создания встречи"""
    logger.info(f"❌ cancel_add_meeting вызван пользователем {update.effective_user.id}")
    
    await update.message.reply_text(
        "❌ Создание встречи отменено.",
        reply_markup=get_back_keyboard('meetings_list')
    )
    
    context.user_data.clear()
    logger.debug("🗑️ User_data очищен")
    
    return ConversationHandler.END

def get_meetings_conversation_handler():
    """Создание ConversationHandler для управления встречами"""
    from keyboards import get_back_keyboard
    
    logger.debug("🔄 Создание ConversationHandler для встреч")
    
    return ConversationHandler(
        entry_points=[
            CommandHandler('add_meeting', start_add_meeting),
            CallbackQueryHandler(MeetingsManager.start_add_meeting_callback, pattern='^add_meeting$'),
            CallbackQueryHandler(MeetingsManager.start_add_meeting_callback, pattern='^create_meeting$')
        ],
        states={
            ADD_TITLE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_meeting_title)],
            ADD_DATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_meeting_date)],
            ADD_DURATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_meeting_duration)],
            ADD_DESCRIPTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_meeting_description),
                            CommandHandler('skip', add_meeting_description)],
            ADD_ZOOM: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_meeting_zoom),
                      CommandHandler('skip', add_meeting_zoom)],
        },
        fallbacks=[CommandHandler('cancel', cancel_add_meeting)],
        per_message=True
    )

async def handle_manual_zoom_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка ручного ввода Zoom ссылки"""
    return await MeetingsManager.process_manual_zoom_text(update, context)