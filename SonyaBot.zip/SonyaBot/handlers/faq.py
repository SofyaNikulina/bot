from telegram import Update
from telegram.ext import ContextTypes
from keyboards import get_back_keyboard
from config import Config
import logging

logger = logging.getLogger(__name__)

async def handle_faq(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик FAQ"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'faq_frequency':
        answer = """<b>Как часто выходят лекции?</b>

1 раз в неделю по одному из предметов (Zoom).
Длительность 1-1,5 часа. В течение 24 ч будет опубликована запись."""
        
        await query.message.edit_text(
            answer,
            reply_markup=get_back_keyboard('faq'),
            parse_mode='HTML'
        )
    
    elif query.data == 'faq_platform':
        answer = """<b>На какой платформе происходит обучение?</b>

Лекции проходят в Zoom, запись будет выложена в закрытом канале клуба в Telegram. Чат клуба также находится в Telegram."""
        
        await query.message.edit_text(
            answer,
            reply_markup=get_back_keyboard('faq'),
            parse_mode='HTML'
        )
    
    elif query.data == 'faq_recording':
        answer = """<b>Можно ли смотреть в записи?</b>

Да, в течение 24 ч после эфира мы предоставляем лекции в видео - и аудиоформате, а также конспекты."""
        
        await query.message.edit_text(
            answer,
            reply_markup=get_back_keyboard('faq'),
            parse_mode='HTML'
        )
    
    elif query.data == 'faq_homework':
        answer = """<b>Будут ли домашние задания?</b>

Домашние задания не являются обязательными, вы можете выполнять их по желанию в любое удобное время."""
        
        await query.message.edit_text(
            answer,
            reply_markup=get_back_keyboard('faq'),
            parse_mode='HTML'
        )
    
    elif query.data == 'faq_join_time':
        answer = """<b>Когда можно присоединиться к клубу?</b>

Вступить в клуб можно в любой момент.
Доступ к клубу открывается сразу после оплаты."""
        
        await query.message.edit_text(
            answer,
            reply_markup=get_back_keyboard('faq'),
            parse_mode='HTML'
        )
    
    elif query.data == 'faq_refund':
        answer = """<b>Можно ли отказаться от подписки?</b>

Если вы оплатили тариф заранее, вы можете вернуть всю сумму до вступления в клуб (т.е. до 1 числа календарного месяца старта вашего членства)."""
        
        await query.message.edit_text(
            answer,
            reply_markup=get_back_keyboard('faq'),
            parse_mode='HTML'
        )
    
    elif query.data == 'faq_installment':
        answer = """<b>Можно ли оплатить в рассрочку?</b>

Есть возможность оплаты частями через сервис "Долями".
Для оформления рассрочки напишите нашему менеджеру."""
        
        await query.message.edit_text(
            answer,
            reply_markup=get_back_keyboard('faq'),
            parse_mode='HTML'
        )
    
    elif query.data == 'faq_bonuses':
        answer = """<b>Как получить бонусы?</b>

Рабочая тетрадь А4 и наклейки доступны только для участников годового тарифа.
После оплаты менеджер свяжется с вами для уточнения адреса доставки (СДЭК)."""
       
        try:
            # Фото для раздела "Как получить бонусы"
            photo_url = "https://s6.iimage.su/s/17/uKUUwZxx7aSFj3Gt921EvoDj3EjAWmwQQE9FyCOp.jpg"
            
            # Сначала удаляем предыдущее сообщение с кнопками FAQ
            await query.message.delete()
            
            # Отправляем фото с текстом как подписью
            await context.bot.send_photo(
                chat_id=query.message.chat_id,
                photo=photo_url,
                caption=answer,
                parse_mode='HTML',
                reply_markup=get_back_keyboard('faq')
            )
            
        except Exception as e:
            logger.error(f"Ошибка отправки фото: {e}")
            # Если фото не загрузится, отправляем текст без фото
            await query.message.edit_text(
                text=answer,
                parse_mode='HTML',
                reply_markup=get_back_keyboard('faq')
            )