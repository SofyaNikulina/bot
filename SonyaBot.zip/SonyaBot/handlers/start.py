# handlers/start.py - ПОЛНОСТЬЮ ИСПРАВЛЕННАЯ ВЕРСИЯ

from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import get_session, User
from keyboards import (
    get_privacy_consent_keyboard, 
    get_main_menu_keyboard, 
    get_cities_keyboard, 
    get_professions_keyboard,
    get_other_city_keyboard
)
from config import Config
import logging
import re
from datetime import datetime

logger = logging.getLogger(__name__)

# Состояния для ConversationHandler
CITY, OTHER_CITY, PROFESSION, EMAIL, SHIPPING_INFO = range(5)

# Словарь профессий для преобразования ID в название
PROFESSIONS_DICT = {
    'entrepreneur': 'Предпринимательница',
    'manager': 'Работаю на линейной должности (менеджер)',
    'executive': 'Работаю на управляющей позиции',
    'self_employed': 'Самозанятая',
    'student': 'Учусь / студентка',
    'not_working': 'Не работаю',
    'maternity': 'В декрете'
}

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /start"""
    user = update.effective_user
    
    # Получаем engine из контекста
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        # Проверяем, есть ли пользователь в базе
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        
        if not db_user:
            # Инициализируем настройки при создании пользователя
            db_user = User(
                telegram_id=user.id,
                username=user.username,
                first_name=user.first_name,
                last_name=user.last_name,
                joined_at=update.message.date,
                # Инициализируем настройки по умолчанию
                settings={
                    'reminders': True,
                    'notifications': True,
                    'timezone': 'Europe/Moscow'
                }
            )
            session.add(db_user)
            session.commit()
            logger.info(f"Новый пользователь: {user.id} - @{user.username}")
        else:
            # Если пользователь уже существует, проверяем наличие настроек
            if not db_user.settings:
                db_user.settings = {
                    'reminders': True,
                    'notifications': True,
                    'timezone': 'Europe/Moscow'
                }
                session.commit()
            
            # ЕСЛИ ПОЛЬЗОВАТЕЛЬ УЖЕ ЗАРЕГИСТРИРОВАН (дал согласие и телефон) - показываем главное меню
            if db_user.agreed_to_policy and db_user.phone_number:
                welcome_text = """🎉 **Добро пожаловать в «Бестужевки»!** 💙

**Вы уже зарегистрированы в клубе!**

Выберите раздел в меню ниже 👇"""
                
                await update.message.reply_text(
                    welcome_text,
                    reply_markup=get_main_menu_keyboard(),
                    parse_mode='Markdown'
                )
                
                db_user.last_activity = update.message.date
                session.commit()
                return
        
        # Если пользователь новый или не завершил регистрацию - показываем согласие
        welcome_text = """Привет! Это чат-бот клуба «Бестужевки» 💙

Пространство для тех, кому важно не просто знать, а чувствовать и понимать: историю, искусство, философию и культуру общения.

Прежде чем продолжить 🤍

**Для регистрации необходимо:**
1. Ознакомиться с документами
2. Дать согласие на обработку персональных данных
3. Поделиться номером телефона для связи

**Ваши данные защищены и используются только для:**
• Связи по вопросам клуба
• Напоминаний о встречах
• Доступа к материалам

**Нажмите кнопки ниже, чтобы ознакомиться с документами:**"""
        
        # Ссылка на фото 
        photo_url = "https://s6.iimage.su/s/17/uPtHeMRx2hKC14TCDcf6Id6rBB6r41KOXOsi6NfF.jpg"
        
        try:
            await update.message.reply_photo(
                photo=photo_url,
                caption=welcome_text,
                reply_markup=get_privacy_consent_keyboard(),
                parse_mode='Markdown'
            )
        except Exception as photo_error:
            logger.warning(f"Не удалось отправить фото: {photo_error}. Отправляем только текст.")
            await update.message.reply_text(
                welcome_text,
                reply_markup=get_privacy_consent_keyboard(),
                parse_mode='Markdown'
            )
        
        # Обновляем время последней активности
        if db_user:
            db_user.last_activity = update.message.date
            session.commit()
        
    except Exception as e:
        logger.error(f"Ошибка в start_command: {e}")
        session.rollback()
    finally:
        session.close()


async def handle_privacy_policy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик согласия с политикой"""
    query = update.callback_query
    user = query.from_user
    
    logger.info(f"🟢 handle_privacy_policy ВЫЗВАНА! Данные: {query.data}")
    
    # ОБЯЗАТЕЛЬНО: отвечаем на callback query
    await query.answer()
    
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("❌ Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        # Находим пользователя
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if not db_user:
            await query.message.reply_text("Пожалуйста, начните с команды /start")
            return
        
        logger.info(f"📋 Обрабатываем callback_data: {query.data}")
        
        if query.data == 'agree_policy':
            logger.info(f"✅ Пользователь {user.id} согласился с политикой")
            db_user.agreed_to_policy = True
            db_user.agreed_at = query.message.date
            
            if not db_user.settings:
                db_user.settings = {
                    'reminders': True,
                    'notifications': True,
                    'timezone': 'Europe/Moscow'
                }
            
            # Пытаемся удалить старое сообщение с фото
            try:
                await query.message.delete()
                logger.info("✅ Удалили старое сообщение с фото")
            except Exception as delete_error:
                logger.warning(f"⚠️ Не удалось удалить сообщение: {delete_error}")
            
            # Отправляем сообщение с благодарностью
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text="✅ **Спасибо за доверие!** 🤍\n\n"
                     "**Вы дали согласие на обработку персональных данных.**\n\n"
                     "Пожалуйста, нажмите кнопку ниже, чтобы поделиться номером телефона.",
                parse_mode='Markdown'
            )
            
            # Создаем ReplyKeyboardMarkup для запроса телефона
            phone_keyboard = ReplyKeyboardMarkup(
                [[KeyboardButton("📱 Поделиться номером", request_contact=True)]],
                resize_keyboard=True,
                one_time_keyboard=True
            )
            
            # Отправляем сообщение с кнопкой для телефона
            phone_text = """**Пожалуйста, поделитесь своим номером телефона**, нажав кнопку ниже.

**Телефон необходим для:**
• Связи по вопросам клуба
• Напоминаний о встречах
• Доступа к материалам
• Восстановления доступа при необходимости

**Гарантируем:**
• Конфиденциальность ваших данных
• Нет рассылке рекламы или спама
• Использование только для целей клуба «Бестужевки»"""
            
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=phone_text,
                reply_markup=phone_keyboard,
                parse_mode='Markdown'
            )
            
            # Устанавливаем состояние ожидания телефона
            context.user_data['awaiting_phone'] = True
            logger.info(f"📱 Запрошен телефон у пользователя {user.id}")
            
        elif query.data == 'decline_policy':
            logger.info(f"❌ Пользователь {user.id} отказался от политики")
            
            try:
                await query.message.delete()
            except Exception as delete_error:
                logger.warning(f"⚠️ Не удалось удалить сообщение: {delete_error}")
            
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text="❌ **Для регистрации в клубе «Бестужевки» необходимо дать согласие на обработку персональных данных.**\n\n"
                     "Без этого мы не сможем:\n"
                     "• Зарегистрировать вас в клубе\n"
                     "• Обеспечить доступ к материалам\n"
                     "• Связаться с вами по вопросам встреч\n\n"
                     "Если вы передумаете, начните регистрацию заново командой /start\n\n"
                     "С уважением,\n"
                     "Команда «Бестужевки» 💙",
                parse_mode='Markdown'
            )
        
        session.commit()
        
    except Exception as e:
        logger.error(f"❌ Ошибка в handle_privacy_policy: {e}")
        session.rollback()
    finally:
        session.close()


async def handle_contact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик получения номера телефона"""
    if not update.message.contact:
        return
    
    user = update.effective_user
    contact = update.message.contact
    
    logger.info(f"📞 Пользователь {user.id} поделился телефоном: {contact.phone_number}")
    
    # Проверяем, что контакт принадлежит пользователю
    if contact.user_id != user.id:
        await update.message.reply_text("Пожалуйста, поделитесь своим номером телефона.")
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        return
    
    session = get_session(engine)
    
    try:
        # Находим пользователя
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if not db_user:
            await update.message.reply_text("Пожалуйста, начните с команды /start")
            return
        
        # Сохраняем номер телефона
        db_user.phone_number = contact.phone_number
        
        # Убеждаемся, что настройки установлены
        if not db_user.settings:
            db_user.settings = {
                'reminders': True,
                'notifications': True,
                'timezone': 'Europe/Moscow'
            }
        
        session.commit()
        
        # Убираем клавиатуру с кнопкой телефона
        remove_keyboard = ReplyKeyboardMarkup([[]], resize_keyboard=True)
        await update.message.reply_text(
            "✅ **Телефон сохранен!**",
            reply_markup=remove_keyboard,
            parse_mode='Markdown'
        )
        
        # Убираем состояние ожидания телефона
        if 'awaiting_phone' in context.user_data:
            del context.user_data['awaiting_phone']
        
        # ЗАПРАШИВАЕМ ГОРОД
        # Сохраняем ID сообщения с запросом города, чтобы потом удалить
        msg = await update.message.reply_text(
            "⏳ Загружаем информацию...",
            reply_markup=ReplyKeyboardMarkup([[]], resize_keyboard=True)
        )
        context.user_data['last_city_message_id'] = msg.message_id
        await msg.delete()
        
        await ask_city(update, context)
        
        logger.info(f"✅ Пользователь {user.id} сохранил телефон, переходим к запросу города")
        
    except Exception as e:
        logger.error(f"❌ Ошибка в handle_contact: {e}")
        session.rollback()
    finally:
        session.close()


async def ask_city(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Запрос города проживания"""
    # Определяем, откуда вызвана функция
    if update.callback_query:
        chat_id = update.callback_query.message.chat_id
        message = update.callback_query.message
        user = update.callback_query.from_user
    else:
        chat_id = update.message.chat_id
        message = update.message
        user = update.effective_user
    
    text = """📍 <b>Пожалуйста, укажите ваш город проживания:</b>

• Москва
• Санкт-Петербург
• 🏙️ Другой город (ввести вручную)

Это поможет нам лучше понимать нашу аудиторию и планировать офлайн-встречи."""

    # Если есть callback_query, редактируем существующее сообщение
    if update.callback_query:
        await update.callback_query.edit_message_text(
            text,
            reply_markup=get_cities_keyboard(),
            parse_mode='HTML'
        )
    else:
        await update.message.reply_text(
            text,
            reply_markup=get_cities_keyboard(),
            parse_mode='HTML'
        )
    
    context.user_data['awaiting_city'] = True
    logger.info(f"🏙️ Запрошен город у пользователя {user.id}")
    
    return CITY


async def handle_city_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик выбора города из callback query"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    callback_data = query.data
    
    logger.info(f"📍 Пользователь {user.id} выбрал город: {callback_data}")
    
    # ИСПРАВЛЕНО: Проверяем на city_other
    if callback_data == 'city_other':
        # Запрашиваем ввод другого города
        text = """🏙️ <b>Введите название вашего города</b>

Напишите название города в сообщении ниже:"""
        
        await query.message.edit_text(
            text,
            parse_mode='HTML',
            reply_markup=get_other_city_keyboard()
        )
        
        # Устанавливаем состояние ожидания ввода города
        context.user_data['awaiting_city_input'] = True
        if 'awaiting_city' in context.user_data:
            del context.user_data['awaiting_city']
        
        logger.info(f"✏️ Запрошен ручной ввод города у пользователя {user.id}")
        return OTHER_CITY
    
    else:
        # ИЗВЛЕКАЕМ ГОРОД: ожидаем формат city_Москва или city_Санкт-Петербург
        # Убираем префикс 'city_' и получаем название города
        city = callback_data.replace('city_', '')
        
        # Сохраняем город
        engine = context.bot_data.get('engine')
        if not engine:
            await query.message.reply_text("❌ Ошибка подключения к базе данных.")
            return
        
        session = get_session(engine)
        
        try:
            # Находим пользователя
            db_user = session.query(User).filter_by(telegram_id=user.id).first()
            if not db_user:
                await query.message.reply_text("Пожалуйста, начните с команды /start")
                return
            
            # Сохраняем город
            db_user.city = city
            session.commit()
            
            logger.info(f"✅ Город сохранен для пользователя {user.id}: {city}")
            
            # Удаляем сообщение с выбором города
            try:
                await query.message.delete()
            except Exception as e:
                logger.warning(f"Не удалось удалить сообщение: {e}")
            
            # Отправляем новое сообщение с запросом профессии
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=f"✅ Выбран город: <b>{city}</b>\n\n"
                     f"<b>Следующий шаг:</b> Выберите вашу профессиональную сферу:",
                reply_markup=get_professions_keyboard(),
                parse_mode='HTML'
            )
            
            # Убираем состояние ожидания города
            if 'awaiting_city' in context.user_data:
                del context.user_data['awaiting_city']
            
            return PROFESSION
            
        except Exception as e:
            logger.error(f"❌ Ошибка при сохранении города: {e}")
            session.rollback()
            await query.message.reply_text("❌ Произошла ошибка. Попробуйте позже.")
        finally:
            session.close()


async def handle_other_city_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик ручного ввода города"""
    user = update.effective_user
    
    # Проверяем, что это текстовое сообщение
    if not update.message or not update.message.text:
        return OTHER_CITY
    
    city_text = update.message.text.strip()
    
    if not city_text:
        await update.message.reply_text(
            "❌ Название города не может быть пустым. Пожалуйста, введите название города:"
        )
        return OTHER_CITY
    
    # Очищаем текст от лишних пробелов и спецсимволов
    city_text = re.sub(r'[^\w\s\-]', '', city_text)
    city_text = city_text.strip()
    
    # Валидация
    if len(city_text) < 2:
        await update.message.reply_text(
            "❌ Название города слишком короткое. Пожалуйста, введите корректное название:"
        )
        return OTHER_CITY
    
    if len(city_text) > 50:
        await update.message.reply_text(
            "❌ Название города слишком длинное. Пожалуйста, используйте не более 50 символов:"
        )
        return OTHER_CITY
    
    logger.info(f"✏️ Пользователь {user.id} ввел город: {city_text}")
    
    # Сохраняем город в БД
    engine = context.bot_data.get('engine')
    if not engine:
        await update.message.reply_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        # Находим пользователя
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if not db_user:
            await update.message.reply_text("Пожалуйста, начните с команды /start")
            return
        
        # Сохраняем город
        db_user.city = city_text
        session.commit()
        
        logger.info(f"✅ Город сохранен для пользователя {user.id}: {city_text}")
        
        # Убираем состояние ожидания
        context.user_data['awaiting_city_input'] = False
        if 'awaiting_city' in context.user_data:
            del context.user_data['awaiting_city']
        
        # Убираем клавиатуру с выбором города
        try:
            # Пытаемся удалить предыдущее сообщение с запросом города
            if 'last_city_message_id' in context.user_data:
                await context.bot.delete_message(
                    chat_id=update.effective_chat.id,
                    message_id=context.user_data['last_city_message_id']
                )
        except Exception as e:
            logger.warning(f"Не удалось удалить сообщение: {e}")
        
        # Отправляем подтверждение и запрашиваем профессию
        await update.message.reply_text(
            f"✅ <b>Город сохранен:</b> {city_text}\n\n"
            f"<b>Следующий шаг:</b> Выберите вашу профессиональную сферу:",
            parse_mode='HTML',
            reply_markup=get_professions_keyboard()
        )
        
        return PROFESSION
        
    except Exception as e:
        logger.error(f"❌ Ошибка при сохранении города: {e}")
        session.rollback()
        await update.message.reply_text("❌ Произошла ошибка. Попробуйте позже.")
        return OTHER_CITY
    finally:
        session.close()


async def handle_back_to_cities(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Возврат к выбору города"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    logger.info(f"🔙 Пользователь {user.id} вернулся к выбору города")
    
    text = """📍 <b>Пожалуйста, укажите ваш город проживания:</b>

• Москва
• Санкт-Петербург
• 🏙️ Другой город (ввести вручную)"""
    
    await query.message.edit_text(
        text,
        parse_mode='HTML',
        reply_markup=get_cities_keyboard()
    )
    
    context.user_data['awaiting_city'] = True
    if 'awaiting_city_input' in context.user_data:
        del context.user_data['awaiting_city_input']
    
    return CITY


async def handle_profession_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик выбора профессии из callback query"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    # Получаем ID профессии, а не полное название
    profession_id = query.data.replace('prof_', '')
    
    logger.info(f"💼 Пользователь {user.id} выбрал профессию ID: {profession_id}")
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.reply_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        # Находим пользователя
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if not db_user:
            await query.message.reply_text("Пожалуйста, начните с команды /start")
            return
        
        # Получаем название профессии по ID из словаря
        profession_name = PROFESSIONS_DICT.get(profession_id, profession_id)
        
        # Сохраняем профессию
        db_user.profession = profession_name
        session.commit()
        
        logger.info(f"✅ Профессия сохранена для пользователя {user.id}: {profession_name}")
        
        # Удаляем сообщение с выбором профессии
        try:
            await query.message.delete()
        except Exception as e:
            logger.warning(f"Не удалось удалить сообщение: {e}")
        
        # Отправляем сообщение об успехе
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=f"✅ Выбрана сфера: <b>{profession_name}</b>",
            parse_mode='HTML'
        )
        
        # Завершаем регистрацию
        await complete_registration(update, context)
        
    except Exception as e:
        logger.error(f"❌ Ошибка при сохранении профессии: {e}")
        session.rollback()
        await query.message.reply_text("❌ Произошла ошибка. Попробуйте позже.")
    finally:
        session.close()


async def complete_registration(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Завершение регистрации и показ главного меню"""
    # Проверяем, откуда вызвана функция
    if update.callback_query:
        user = update.callback_query.from_user
        chat_id = update.callback_query.message.chat_id
    else:
        user = update.effective_user
        chat_id = update.message.chat_id
    
    engine = context.bot_data.get('engine')
    if not engine:
        return
    
    session = get_session(engine)
    
    try:
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if not db_user:
            return
        
        # Отправляем финальное приветственное сообщение
        welcome_text = """🎉 **Добро пожаловать в «Бестужевки»!** 💙

**Регистрация успешно завершена!** 🤍

**«Бестужевки»** — это онлайн-клуб, где раз в неделю проходят **лекции и живые встречи в Zoom** на темы:

🏛️ История России
🖼️ Русское искусство
👑 Этикет и культура общения
🚀 Философия предпринимательства

**Что дальше?**
• Изучите раздел **«О клубе»** — узнайте подробнее о формате
• Посмотрите **«Тарифы»** — выберите подходящий вариант
• Ознакомьтесь с **«Спикерами»** — познакомьтесь с преподавателями
• Изучите **«Программы»** — увидите план занятий

**Выберите раздел в меню ниже 👇**"""
        
        # Отправляем новое сообщение
        await context.bot.send_message(
            chat_id=chat_id,
            text=welcome_text,
            reply_markup=get_main_menu_keyboard(),
            parse_mode='Markdown'
        )
        
        logger.info(f"✅ Пользователь {user.id} завершил регистрацию")
        
    except Exception as e:
        logger.error(f"❌ Ошибка в complete_registration: {e}")
    finally:
        session.close()


def get_registration_conversation_handler():
    """Возвращает ConversationHandler для регистрации"""
    from telegram.ext import ConversationHandler, CallbackQueryHandler, MessageHandler, filters
    
    return ConversationHandler(
        entry_points=[
            CallbackQueryHandler(handle_city_selection, pattern='^city_'),
            MessageHandler(filters.CONTACT, handle_contact)
        ],
        states={
            CITY: [
                CallbackQueryHandler(handle_city_selection, pattern='^city_'),
                CallbackQueryHandler(handle_back_to_cities, pattern='^back_to_cities$')
            ],
            OTHER_CITY: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_other_city_input),
                CallbackQueryHandler(handle_back_to_cities, pattern='^back_to_cities$')
            ],
            PROFESSION: [
                CallbackQueryHandler(handle_profession_selection, pattern='^prof_')
            ]
        },
        fallbacks=[],
        name="registration_conversation",
        persistent=False,
        per_user=True,
        per_chat=True,
        per_message=False
    )