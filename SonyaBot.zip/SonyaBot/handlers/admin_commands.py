from telegram import Update
from telegram.ext import ContextTypes, CommandHandler
from database import get_session, UserMessage, User  # ← ДОБАВЛЕН User
from config import Config
import logging

logger = logging.getLogger(__name__)

async def admin_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /messages для просмотра непрочитанных сообщений"""
    
    # ДОБАВЬТЕ ОТЛАДОЧНЫЙ ВЫВОД
    logger.info(f"🛠️ Вызвана команда /messages от пользователя {update.message.from_user.id}")
    
    # Проверяем, что команду вызвал админ
    if update.message.from_user.id not in Config.ADMIN_IDS:
        logger.warning(f"Пользователь {update.message.from_user.id} попытался вызвать /messages без прав")
        await update.message.reply_text("⛔ Эта команда доступна только администраторам.")
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data при вызове /messages")
        await update.message.reply_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        # Получаем непрочитанные сообщения
        unread_messages = session.query(UserMessage).filter_by(
            forwarded_to_admins=True,
            admin_replied=False
        ).order_by(UserMessage.created_at.desc()).limit(10).all()
        
        logger.info(f"Найдено {len(unread_messages)} непрочитанных сообщений")
        
        if not unread_messages:
            await update.message.reply_text("📭 Нет непрочитанных сообщений.")
            return
        
        text = "📋 <b>Последние непрочитанные сообщения:</b>\n\n"
        
        for msg in unread_messages:
            # Получаем информацию о пользователе из таблицы users
            user = session.query(User).filter_by(telegram_id=msg.telegram_id).first()
            
            # Формируем информацию о пользователе
            if user:
                user_info = f"👤 {user.first_name or ''}"
                if user.last_name:
                    user_info += f" {user.last_name}"
                if user.username:
                    user_info += f" (@{user.username})"
                user_info += f" (#{msg.telegram_id})"
            else:
                user_info = f"👤 Пользователь #{msg.telegram_id}"
            
            # Формируем превью сообщения
            preview = ""
            if msg.message_text:
                if len(msg.message_text) > 100:
                    preview = msg.message_text[:100] + "..."
                else:
                    preview = msg.message_text
            elif msg.message_type != 'text':
                preview = f"[{msg.message_type.upper()}]"
            else:
                preview = "[Нет текста]"
            
            text += f"🔢 <b>#{msg.id}</b> - {user_info}\n"
            text += f"📅 {msg.created_at.strftime('%d.%m.%Y %H:%M')}\n"
            text += f"💬 {preview}\n"
            text += "─" * 30 + "\n"
        
        text += f"\n📊 <b>Всего непрочитанных:</b> {len(unread_messages)}"
        
        await update.message.reply_text(text, parse_mode='HTML')
        logger.info(f"✅ Команда /messages выполнена успешно")
        
    except Exception as e:
        logger.error(f"Ошибка в команде /messages: {e}", exc_info=True)
        await update.message.reply_text("❌ Произошла ошибка при получении сообщений.")
    finally:
        session.close()