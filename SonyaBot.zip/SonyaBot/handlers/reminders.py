# handlers/reminders.py
"""
Модуль для обработки напоминаний о встречах
"""
import logging
from datetime import datetime, timedelta
from database import get_session, User, Subscription, Meeting, Reminder
from config import Config

logger = logging.getLogger(__name__)

async def send_zoom_during_stream(meeting, session, bot):
    """
    Отправка Zoom ссылки во время трансляции
    """
    try:
        if not meeting.zoom_link:
            logger.error(f"У встречи {meeting.id} нет Zoom ссылки")
            return False
        
        # Находим активных подписчиков
        subscribers = session.query(User).join(Subscription).filter(
            Subscription.is_active == True,
            Subscription.end_date >= datetime.now()
        ).all()
        
        logger.info(f"Отправка Zoom ссылки во время трансляции встречи '{meeting.title}': найдено {len(subscribers)} подписчиков")
        
        sent_count = 0
        error_count = 0
        
        for user in subscribers:
            try:
                text = f"""🎥 **Трансляция началась!**

**Тема:** {meeting.title}
**Ссылка для входа:** {meeting.zoom_link}
**Пароль:** {meeting.zoom_password or 'не требуется'}

Присоединяйтесь к встрече!"""
                
                await bot.send_message(
                    chat_id=user.telegram_id,
                    text=text,
                    parse_mode='Markdown'
                )
                sent_count += 1
                
                # Создаем запись о напоминании
                reminder = Reminder(
                    user_id=user.id,
                    meeting_id=meeting.id,
                    reminder_type='during_stream',
                    scheduled_time=datetime.now(),
                    sent=True,
                    sent_at=datetime.now()
                )
                session.add(reminder)
                
            except Exception as e:
                error_count += 1
                logger.error(f"Ошибка отправки Zoom ссылки пользователю {user.id}: {e}")
        
        # Отправляем уведомление админам
        await notify_admins_about_stream(meeting, sent_count, error_count, bot)
        
        logger.info(f"Zoom ссылка во время трансляции отправлена: {sent_count} успешно, {error_count} ошибок")
        session.commit()
        return True
        
    except Exception as e:
        logger.error(f"Ошибка в send_zoom_during_stream: {e}")
        return False

async def notify_admins_about_stream(meeting, sent_count, error_count, bot):
    """
    Уведомление админов о начале трансляции
    """
    try:
        for admin_id in Config.ADMIN_IDS:
            try:
                text = f"""📊 **Уведомление от бота**

🎥 **Началась трансляция:**
• Тема: {meeting.title}
• Время: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
• Отправлено пользователям: {sent_count}
• Ошибок отправки: {error_count}

✅ Система уведомлений работает."""
                
                await bot.send_message(
                    chat_id=admin_id,
                    text=text,
                    parse_mode='Markdown'
                )
                logger.info(f"Уведомление о трансляции отправлено админу {admin_id}")
            except Exception as e:
                logger.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
    except Exception as e:
        logger.error(f"Ошибка в notify_admins_about_stream: {e}")

async def notify_admins_about_reminder(meeting, reminder_type, sent_count, error_count, bot):
    """
    Дублирование уведомлений админам о напоминаниях
    """
    try:
        reminder_names = {
            'day_before': 'За 24 часа',
            '15_min_before': 'За 15 минут',
            'during_stream': 'Во время трансляции'
        }
        
        reminder_name = reminder_names.get(reminder_type, reminder_type)
        
        for admin_id in Config.ADMIN_IDS:
            try:
                text = f"""📊 **Уведомление от бота**

⏰ **Отправлено напоминание ({reminder_name}):**
• Тема: {meeting.title}
• Время: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
• Отправлено пользователям: {sent_count}
• Ошибок отправки: {error_count}

✅ Система уведомлений работает."""
                
                await bot.send_message(
                    chat_id=admin_id,
                    text=text,
                    parse_mode='Markdown'
                )
                logger.info(f"Уведомление о напоминании {reminder_type} отправлено админу {admin_id}")
            except Exception as e:
                logger.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
    except Exception as e:
        logger.error(f"Ошибка в notify_admins_about_reminder: {e}")