# handlers/__init__.py - ПОЛНОСТЬЮ ИСПРАВЛЕННЫЙ

from .start import start_command, handle_privacy_policy, handle_contact
from .menu import handle_main_menu, handle_back_button, handle_after_payment, handle_speaker_detail, handle_program_selection
from .payment import (
    handle_tariff_selection, 
    handle_payment, 
    handle_promocode,
    handle_tinkoff_payment, 
    check_payment_status,
    handle_shipping_info  # ДОБАВЛЕНО
)
from .faq import handle_faq
from .admin import admin_command, handle_admin
from .utils import (
    handle_text_message, 
    help_command, 
    handle_unknown_command,
    handle_city_selection,  # ДОБАВЛЕНО
    handle_profession_selection,  # ДОБАВЛЕНО
    handle_back_to_cities,  # ДОБАВЛЕНО
    handle_email_input_text,  # ДОБАВЛЕНО
    handle_shipping_info_text,  # ДОБАВЛЕНО
    handle_promocode_text,  # ДОБАВЛЕНО
    handle_other_city_input,  # ДОБАВЛЕНО
    handle_back_to_tariffs,  # ДОБАВЛЕНО
    handle_back_to_main,  # ДОБАВЛЕНО
    handle_zoom_link  # ДОБАВЛЕНО
)
from .messages import forward_user_message
from .admin_commands import admin_messages
from .admin_reply import get_reply_conversation_handler
from .admin_meetings import get_meetings_conversation_handler, MeetingsManager
from .admin_broadcast import broadcast_all, broadcast_subscribed, broadcast_active, broadcast_ids
from .admin_promocodes import (
    manage_promocodes, 
    get_promocodes_conversation_handler,
    list_promocodes,
    active_promocodes,  # ДОБАВЛЕНО
    expired_promocodes,  # ДОБАВЛЕНО
    edit_promocode_menu,
    delete_promocode_menu
)

# Импортируем функции отчетов из корневого reports.py
from reports import handle_admin_report_request, handle_excel_export

# Импортируем модуль reminders для уведомлений о встречах и Zoom
from .reminders import (
    send_zoom_during_stream,
    notify_admins_about_stream,
    notify_admins_about_reminder
)

__all__ = [
    'start_command',
    'handle_privacy_policy',
    'handle_contact',
    'handle_main_menu',
    'handle_back_button',
    'handle_after_payment',
    'handle_speaker_detail',
    'handle_program_selection',
    'handle_tariff_selection',
    'handle_payment',
    'handle_promocode',
    'handle_faq',
    'admin_command',
    'handle_admin',
    'handle_text_message',
    'help_command',
    'handle_tinkoff_payment',
    'check_payment_status',
    'forward_user_message',
    'admin_messages',
    'get_reply_conversation_handler',
    'get_meetings_conversation_handler',
    'MeetingsManager',
    'handle_zoom_link',
    'handle_unknown_command',
    'broadcast_all',
    'broadcast_subscribed',
    'broadcast_active',
    'broadcast_ids',
    'manage_promocodes',
    'get_promocodes_conversation_handler',
    'list_promocodes',
    'active_promocodes',
    'expired_promocodes',
    'edit_promocode_menu',
    'delete_promocode_menu',
    'handle_admin_report_request',
    'handle_excel_export',
    'send_zoom_during_stream',
    'notify_admins_about_stream',
    'notify_admins_about_reminder',
    # ДОБАВЛЕННЫЕ ФУНКЦИИ
    'handle_city_selection',
    'handle_profession_selection',
    'handle_back_to_cities',
    'handle_email_input_text',
    'handle_shipping_info_text',
    'handle_shipping_info',
    'handle_promocode_text',
    'handle_other_city_input',
    'handle_back_to_tariffs',
    'handle_back_to_main'
]