# fix_payments_null.py
import sqlite3

print("🔄 ИСПРАВЛЕНИЕ NULL ЗНАЧЕНИЙ В ТАБЛИЦЕ payments")
print("="*70)

conn = sqlite3.connect('bestuzhevki.db')
cursor = conn.cursor()

# Проверяем структуру таблицы payments
cursor.execute("PRAGMA table_info(payments)")
columns = cursor.fetchall()
print("\n📋 КОЛОНКИ В ТАБЛИЦЕ payments:")
for col in columns:
    print(f"  {col[1]} ({col[2]}) - NOT NULL: {col[3]}")

# Находим записи с NULL значениями в важных полях
fields_to_check = ['amount', 'discount', 'original_amount']

for field in fields_to_check:
    cursor.execute(f"SELECT COUNT(*) FROM payments WHERE {field} IS NULL")
    null_count = cursor.fetchone()[0]
    if null_count > 0:
        print(f"\n⚠️ Найдено {null_count} записей с NULL в поле {field}")
        
        # Покажем несколько примеров
        cursor.execute(f"SELECT id, user_id, {field} FROM payments WHERE {field} IS NULL LIMIT 3")
        examples = cursor.fetchall()
        for ex in examples:
            print(f"  Платеж ID {ex[0]}, user_id {ex[1]}, {field} = {ex[2]}")
        
        # Исправляем NULL значения
        if field == 'discount':
            cursor.execute(f"UPDATE payments SET {field} = 0 WHERE {field} IS NULL")
            print(f"  ✅ Исправлено: NULL -> 0")
        elif field == 'original_amount':
            cursor.execute(f"UPDATE payments SET {field} = amount WHERE {field} IS NULL")
            print(f"  ✅ Исправлено: original_amount = amount")
        elif field == 'amount':
            print(f"  ❌ Критично! amount не может быть NULL, нужно проверить вручную")

# Также проверяем другие поля, которые могут быть NULL
cursor.execute("SELECT COUNT(*) FROM payments WHERE discount IS NULL")
if cursor.fetchone()[0] > 0:
    cursor.execute("UPDATE payments SET discount = 0 WHERE discount IS NULL")

cursor.execute("SELECT COUNT(*) FROM payments WHERE original_amount IS NULL")
if cursor.fetchone()[0] > 0:
    cursor.execute("UPDATE payments SET original_amount = amount WHERE original_amount IS NULL")

conn.commit()

# Проверяем, что исправили
print("\n🔍 ПРОВЕРКА ПОСЛЕ ИСПРАВЛЕНИЯ:")
for field in fields_to_check:
    cursor.execute(f"SELECT COUNT(*) FROM payments WHERE {field} IS NULL")
    null_count = cursor.fetchone()[0]
    print(f"  {field}: {null_count} NULL записей")

# Покажем несколько платежей для проверки
print("\n📊 ПРИМЕРЫ ПЛАТЕЖЕЙ (последние 5):")
cursor.execute("""
    SELECT id, user_id, amount, discount, original_amount, tariff, status
    FROM payments
    ORDER BY id DESC
    LIMIT 5
""")
payments = cursor.fetchall()
for p in payments:
    print(f"  ID {p[0]}: amount={p[1]} руб., discount={p[2]} руб., original={p[3]} руб., tariff={p[4]}, status={p[5]}")

conn.close()
print("\n✅ Исправление завершено!")