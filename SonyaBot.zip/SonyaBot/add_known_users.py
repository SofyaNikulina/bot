# add_known_users.py
import sqlite3
from datetime import datetime

print("🔄 ДОБАВЛЕНИЕ ИЗВЕСТНЫХ ПОЛЬЗОВАТЕЛЕЙ")
print("="*70)

conn = sqlite3.connect('bestuzhevki.db')
cursor = conn.cursor()

# Данные из ваших сообщений
users_data = [
    {
        'username': 'Dasha_Alvik',
        'first_name': 'Даша',
        'amount': 5000,
        'tariff': '1_month',
        'date': '2026-02-18',
        'order_id': 'order_518872345_1771140724',
        'payment_id': '7978345951'
    },
    {
        'username': 'asswxa',
        'first_name': 'А',
        'amount': 5000,
        'tariff': '1_month',
        'date': '2026-02-18',
        'order_id': 'order_1000643480_1771239558',
        'payment_id': '7985379937'
    },
    {
        'username': 'YuliaSu',
        'first_name': 'Юлия',
        'amount': 5000,
        'tariff': '1_month',
        'date': '2026-02-16',
        'order_id': 'order_298057879_1771079417',
        'payment_id': '7975004183'
    },
    {
        'username': 'katesoshnikova',
        'first_name': 'Kate S.',
        'amount': 25000,
        'tariff': '12_months',
        'date': '2026-02-13',
        'order_id': 'order_35291558_1770913375',
        'payment_id': '7962739246',
        'promocode': 'BEST1'
    },
    {
        'username': 'mariyapoptsova',
        'first_name': 'Mariya Poptsova',
        'amount': 5000,
        'tariff': '1_month',
        'date': '2026-02-12',
        'order_id': 'order_839464550_1770749615',
        'payment_id': '7950993153'
    },
    {
        'username': 'reginamuhkitdinova',
        'first_name': 'Регина',
        'amount': 30000,
        'tariff': '12_months',
        'date': '2026-02-08',
        'order_id': 'order_995694636_1770555416',
        'payment_id': '7937162067',
        'promocode': 'GOOD2'
    },
    {
        'username': 'anyaprocherk',
        'first_name': 'Anya',
        'amount': 5000,
        'tariff': '1_month',
        'date': '2026-02-09',
        'order_id': 'order_339454363_1770417817',
        'payment_id': '7927958180'
    },
    {
        'username': 's_svetasveta',
        'first_name': 'Светлана',
        'amount': 30000,
        'tariff': '12_months',
        'date': '2026-02-06',
        'order_id': 'order_830221885_1770374024',
        'payment_id': '7924529383',
        'promocode': 'BEST002'
    },
    {
        'username': 'anastasia0986',
        'first_name': 'N',
        'amount': 1,
        'tariff': '1_month',
        'date': '2026-02-05',
        'order_id': 'order_700098815_1770116217',
        'payment_id': '7904799006',
        'promocode': 'LETO2'
    }
]

print(f"📋 Всего пользователей для добавления: {len(users_data)}")

# Получаем существующих пользователей по username
cursor.execute("SELECT username, telegram_id FROM users")
existing_users = {row[0]: row[1] for row in cursor.fetchall()}
print(f"👥 Существующих пользователей в базе: {len(existing_users)}")

# Счетчик для временных ID
temp_id_counter = 1
added_users = 0
added_payments = 0
skipped = 0

for user in users_data:
    # Проверяем, есть ли пользователь по username
    if user['username'] in existing_users:
        print(f"⏭️ Пользователь @{user['username']} уже существует")
        
        # Проверяем, есть ли уже такой платеж
        cursor.execute("""
            SELECT id FROM payments WHERE order_id = ? OR telegram_payment_charge_id = ?
        """, (user['order_id'], user['payment_id']))
        
        if cursor.fetchone():
            print(f"   Платеж уже есть")
            skipped += 1
            continue
        
        # Добавляем платеж существующему пользователю
        cursor.execute("SELECT id FROM users WHERE username = ?", (user['username'],))
        user_id = cursor.fetchone()[0]
        
        cursor.execute("""
            INSERT INTO payments (
                user_id, amount, tariff, status, created_at, 
                order_id, telegram_payment_charge_id, promocode
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id,
            user['amount'] * 100,
            user['tariff'],
            'completed',
            user['date'],
            user['order_id'],
            user['payment_id'],
            user.get('promocode', '')
        ))
        added_payments += 1
        print(f"   ✅ Добавлен платеж для @{user['username']} ({user['amount']} руб.)")
        
    else:
        # Генерируем уникальный временный ID
        temp_telegram_id = -temp_id_counter
        temp_id_counter += 1
        
        # Добавляем нового пользователя
        cursor.execute("""
            INSERT INTO users (
                telegram_id, username, first_name, joined_at, last_activity,
                is_active, settings, city, profession, full_name, shipping_address
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            temp_telegram_id,  # временный отрицательный ID
            user['username'],
            user['first_name'],
            user['date'],
            user['date'],
            1,
            '{}',
            '', '', '', ''
        ))
        
        user_id = cursor.lastrowid
        added_users += 1
        print(f"✅ Добавлен пользователь: @{user['username']} ({user['first_name']}) с временным ID {temp_telegram_id}")
        
        # Добавляем платеж
        cursor.execute("""
            INSERT INTO payments (
                user_id, amount, tariff, status, created_at,
                order_id, telegram_payment_charge_id, promocode
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id,
            user['amount'] * 100,
            user['tariff'],
            'completed',
            user['date'],
            user['order_id'],
            user['payment_id'],
            user.get('promocode', '')
        ))
        added_payments += 1
        print(f"   💳 Добавлен платеж: {user['amount']} руб.")

conn.commit()

print("\n" + "="*70)
print("📊 ИТОГИ:")
print(f"  ✅ Добавлено новых пользователей: {added_users}")
print(f"  💳 Добавлено новых платежей: {added_payments}")
print(f"  ⏭️ Пропущено дубликатов: {skipped}")

# Проверяем итог
cursor.execute("SELECT COUNT(*) FROM users")
total_users = cursor.fetchone()[0]
cursor.execute("SELECT COUNT(*) FROM payments")
total_payments = cursor.fetchone()[0]
cursor.execute("SELECT SUM(amount)/100 FROM payments")
total_sum = cursor.fetchone()[0]

print(f"\n📈 ТЕПЕРЬ В БАЗЕ:")
print(f"  👥 Всего пользователей: {total_users}")
print(f"  💳 Всего платежей: {total_payments}")
print(f"  💰 Общая сумма: {total_sum:.2f} руб.")

# Показываем пользователей с временными ID
print("\n📋 Пользователи с временными ID (нужно обновить telegram_id):")
cursor.execute("""
    SELECT id, telegram_id, username, first_name
    FROM users
    WHERE telegram_id < 0
    ORDER BY id DESC
""")
temp_users = cursor.fetchall()
for user in temp_users:
    print(f"  ID: {user[0]}, Временный ID: {user[1]}, @{user[2]}, {user[3]}")

conn.close()
print("\n✅ Готово!")
print("\n⚠️  Когда узнаете реальные Telegram ID, запустите скрипт update_telegram_ids.py")