import logging

# Настройка максимально подробного логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.DEBUG,
    handlers=[
        logging.FileHandler('debug_bot.log', encoding='utf-8', mode='w'),
        logging.StreamHandler()
    ]
)

# Запустите бот через этот файл
from bot import main

if __name__ == '__main__':
    main()