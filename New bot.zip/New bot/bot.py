import sys
import io
import os
import logging
import asyncio
import traceback
from datetime import datetime
import pytz
from telegram import Update
from telegram.ext import (
    Application, 
    ApplicationBuilder, 
    CommandHandler, 
    CallbackQueryHandler, 
    MessageHandler, 
    filters, 
    ContextTypes
)
from handlers.reminders import (
    send_zoom_during_stream,
    notify_admins_about_stream,
    notify_admins_about_reminder
)
from telegram.error import NetworkError, TimedOut, BadRequest
from config import Config
from database import init_db

# Устанавливаем UTF-8 кодировку для вывода
if sys.platform == "win32":
    os.system('chcp 65001 > nul')
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=getattr(logging, Config.LOG_LEVEL),
    handlers=[
        logging.FileHandler(Config.LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Глобальный обработчик ошибок"""
    logger.error(f"Exception while handling update: {context.error}", exc_info=True)
    
    try:
        # Пропускаем сетевые ошибки - они временные
        if isinstance(context.error, NetworkError) or isinstance(context.error, TimedOut):
            logger.warning(f"Сетевая ошибка, пропускаем уведомление: {context.error}")
            return
            
        for admin_id in Config.ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=f"⚠️ Ошибка в боте: {str(context.error)[:200]}"
                )
            except Exception as e:
                logger.warning(f"Не удалось отправить уведомление админу {admin_id}: {e}")
    except Exception as e:
        logger.error(f"Ошибка в error_handler: {e}")

async def safe_send_message(bot, chat_id, text, **kwargs):
    """Безопасная отправка сообщения с обработкой ошибок"""
    try:
        return await bot.send_message(chat_id, text, **kwargs)
    except (NetworkError, TimedOut) as e:
        logger.warning(f"Сетевая ошибка при отправке сообщения: {e}")
        # Попробуем еще раз через 3 секунды
        await asyncio.sleep(3)
        try:
            return await bot.send_message(chat_id, text, **kwargs)
        except Exception as retry_error:
            logger.error(f"Ошибка при повторной отправке: {retry_error}")
            raise retry_error
    except Exception as e:
        logger.error(f"Ошибка при отправке сообщения: {e}")
        raise e

async def handle_copy_zoom(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик кнопки копирования Zoom ссылки"""
    query = update.callback_query
    await query.answer()
    
    logger.info(f"📋 handle_copy_zoom вызван: {query.data}")
    
    try:
        # Извлекаем ID встречи
        meeting_id = int(query.data.split('_')[2])
        
        engine = context.bot_data.get('engine')
        if not engine:
            logger.error("❌ Engine не найден в bot_data")
            return
        
        from database import get_session, Meeting
        session = None
        try:
            session = get_session(engine)
            meeting = session.query(Meeting).filter_by(id=meeting_id).first()
            
            if meeting and meeting.zoom_link:
                # Отправляем ссылку для копирования
                await query.message.reply_text(
                    f"🔗 **Zoom ссылка для копирования:**\n\n"
                    f"`{meeting.zoom_link}`\n\n"
                    f"Нажмите и удерживайте ссылку, чтобы скопировать.",
                    parse_mode='Markdown'
                )
            else:
                await query.message.reply_text("❌ У этой встречи нет Zoom ссылки.")
                
        except Exception as e:
            logger.error(f"❌ Ошибка при копировании Zoom: {e}")
            await query.message.reply_text("❌ Ошибка при получении Zoom ссылки.")
        finally:
            if session:
                session.close()
            
    except Exception as e:
        logger.error(f"❌ Ошибка в handle_copy_zoom: {e}")
        await query.message.reply_text("❌ Произошла ошибка при обработке запроса.")

async def test_scheduler_manually(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ручной тест планировщика"""
    user = update.effective_user
    
    if user.id not in Config.ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет прав для этой команды.")
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        await update.message.reply_text("❌ Engine не найден.")
        return
    
    await update.message.reply_text("🔧 Запускаю ручной тест планировщика...")
    
    # Запускаем проверку напоминаний вручную
    from scheduler import SchedulerManager
    
    # Создаем временный планировщик для теста
    test_scheduler = SchedulerManager(context.bot, engine)
    
    try:
        # Проверяем встречи через 15 минут
        await update.message.reply_text("⏰ Проверяю 15-минутные напоминания...")
        await test_scheduler.check_15_min_reminders()
        
        # Проверяем живые трансляции
        await update.message.reply_text("🎥 Проверяю живые трансляции...")
        await test_scheduler.check_live_streams()
        
        await update.message.reply_text("✅ Ручной тест завершен. Проверьте логи.")
        
    except Exception as e:
        logger.error(f"❌ Ошибка при ручном тесте: {e}")
        await update.message.reply_text(f"❌ Ошибка: {str(e)}")

async def check_bot_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Проверка статуса бота"""
    user = update.effective_user
    
    if user.id not in Config.ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет прав для этой команды.")
        return
    
    engine = context.bot_data.get('engine')
    
    status_text = f"""🤖 **Статус бота**

📊 **База данных:** {'✅ Подключена' if engine else '❌ Ошибка'}
👥 **Админы:** {len(Config.ADMIN_IDS)} чел.
💰 **Тинькофф:** {'✅ Настроен' if Config.TINKOFF_TERMINAL_ID else '❌ Не настроен'}
🔗 **Zoom:** {'✅ Настроен' if Config.ZOOM_ENABLED else '❌ Не настроен'}

📅 **Текущее время:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
🕐 **Московское время:** {datetime.now(pytz.timezone('Europe/Moscow')).strftime('%Y-%m-%d %H:%M:%S')}

Используйте /test_scheduler для проверки планировщика."""
    
    await update.message.reply_text(status_text, parse_mode='Markdown')

def setup_handlers(application):
    """Настройка всех обработчиков в правильном порядке"""
    
    logger.info("🔄 Настройка обработчиков...")
    
    try:
        # Импорт обработчиков ЛОКАЛЬНО, чтобы избежать циклических зависимостей
        from handlers import (
            start_command, handle_privacy_policy, handle_contact, handle_main_menu, 
            handle_back_button, handle_after_payment, handle_tariff_selection, 
            handle_payment, handle_promocode, handle_faq, admin_command, 
            handle_admin, handle_text_message, help_command,
            handle_tinkoff_payment, check_payment_status,
            handle_speaker_detail, handle_program_selection
        )
        from handlers.messages import forward_user_message
        from handlers.admin_reply import get_reply_conversation_handler
        from handlers.admin_commands import admin_messages
        from handlers.admin_meetings import get_meetings_conversation_handler, MeetingsManager
        from handlers.utils import handle_zoom_link, handle_unknown_command
        
        # Импорт функций рассылки
        from handlers.admin_broadcast import broadcast_all, broadcast_subscribed, broadcast_active, broadcast_ids
        
        # Импорт функций управления промокодами
        from handlers.admin_promocodes import (
            manage_promocodes,
            list_promocodes,
            active_promocodes,
            expired_promocodes,
            edit_promocode_menu,
            delete_promocode_menu,
            get_promocodes_conversation_handler
        )
        
        # Импорт отчетов
        try:
            from reports import handle_admin_report_request, handle_excel_export
            logger.info("✅ Импорт отчетов из reports.py успешен")
        except ImportError as e:
            logger.error(f"❌ Не удалось импортировать reports.py: {e}")
            traceback.print_exc()
            # Создаем заглушки
            async def handle_admin_report_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
                await update.callback_query.answer()
                await update.callback_query.message.edit_text(
                    "❌ Система отчетов временно недоступна",
                    parse_mode='Markdown'
                )
            
            async def handle_excel_export(update: Update, context: ContextTypes.DEFAULT_TYPE):
                await update.callback_query.answer()
                await update.callback_query.message.edit_text(
                    "❌ Excel выгрузка временно недоступна",
                    parse_mode='Markdown'
                )
        
        # ========== КОМАНДЫ ==========
        # Группа 0 - основные команды (высокий приоритет)
        
        application.add_handler(CommandHandler("start", start_command), group=0)
        application.add_handler(CommandHandler("admin", admin_command), group=0)
        application.add_handler(CommandHandler("help", help_command), group=0)
        application.add_handler(CommandHandler("messages", admin_messages), group=0)
        
        # Новые команды для отладки планировщика
        application.add_handler(CommandHandler("test_scheduler", test_scheduler_manually), group=0)
        application.add_handler(CommandHandler("status", check_bot_status), group=0)
        application.add_handler(CommandHandler("send_reminder", MeetingsManager.send_reminder_manually), group=0)
        
        # Команды рассылки
        application.add_handler(CommandHandler("broadcast_all", broadcast_all), group=0)
        application.add_handler(CommandHandler("broadcast_subscribed", broadcast_subscribed), group=0)
        application.add_handler(CommandHandler("broadcast_active", broadcast_active), group=0)
        application.add_handler(CommandHandler("broadcast_ids", broadcast_ids), group=0)

        # ========== CONVERSATION HANDLERS ==========
        # Группа 0 - обработчики диалогов
        
        application.add_handler(get_reply_conversation_handler(), group=0)
        application.add_handler(get_meetings_conversation_handler(), group=0)
        application.add_handler(get_promocodes_conversation_handler(), group=0)
        
        # ========== СПЕЦИАЛЬНЫЕ ТИПЫ СООБЩЕНИЙ ==========
        # Группа 0 - специальные типы сообщений
        
        application.add_handler(MessageHandler(filters.CONTACT, handle_contact), group=0)
        
        # ========== ОТЧЕТЫ И АНАЛИТИКА ==========
        # Группа 0 - обработчики отчетов (должны быть ДО общего обработчика admin_)
        
        # Сначала самые конкретные паттерны отчетов
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^admin_report_week$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^admin_report_month$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^admin_report_custom$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^admin_excel_export$'), group=0)
        
        # Затем более общие паттерны
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^admin_report_'), group=0)
        
        # Excel выгрузка
        application.add_handler(CallbackQueryHandler(handle_excel_export, pattern='^excel_'), group=0)
        
        # Обработчик для кастомных отчетов (custom_)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^custom_'), group=0)
        
        # Обработчик для периодов (period_)
        application.add_handler(CallbackQueryHandler(handle_admin_report_request, pattern='^period_'), group=0)
        
        # ========== CALLBACK QUERIES ==========
        # Группа 0 - обработчики нажатий на кнопки
        
        application.add_handler(CallbackQueryHandler(handle_privacy_policy, pattern='^(agree_policy|decline_policy)$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_main_menu, pattern='^(about_club|format_schedule|tariffs|speakers|faq|contact_manager|programm)$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_back_button, pattern='^back_to_'), group=0)
        application.add_handler(CallbackQueryHandler(handle_speaker_detail, pattern='^speaker_'), group=0)
        application.add_handler(CallbackQueryHandler(handle_tariff_selection, pattern='^tariff_'), group=0)
        application.add_handler(CallbackQueryHandler(handle_payment, pattern='^pay_|^installment_payment$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_promocode, pattern='^(enter_promocode|remove_promocode|apply_promocode)$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_faq, pattern='^faq_'), group=0)
        application.add_handler(CallbackQueryHandler(handle_after_payment, pattern='^(add_to_calendar|materials)$'), group=0)
        
        # Обработчики промокодов
        application.add_handler(CallbackQueryHandler(manage_promocodes, pattern='^admin_promocodes$'), group=0)
        application.add_handler(CallbackQueryHandler(list_promocodes, pattern='^list_promocodes$'), group=0)
        application.add_handler(CallbackQueryHandler(active_promocodes, pattern='^active_promocodes$'), group=0)
        application.add_handler(CallbackQueryHandler(expired_promocodes, pattern='^expired_promocodes$'), group=0)
        application.add_handler(CallbackQueryHandler(edit_promocode_menu, pattern='^edit_promocode_menu$'), group=0)
        application.add_handler(CallbackQueryHandler(delete_promocode_menu, pattern='^delete_promocode_menu$'), group=0)
        
        # Тинькофф оплата
        if Config.TINKOFF_TERMINAL_ID and Config.TINKOFF_TERMINAL_PASSWORD:
            application.add_handler(CallbackQueryHandler(handle_tinkoff_payment, pattern='^tinkoff_'), group=0)
            application.add_handler(CallbackQueryHandler(check_payment_status, pattern='^check_status_'), group=0)
        
        # ========== УПРАВЛЕНИЕ ВСТРЕЧАМИ И ZOOM ==========
        # Группа 0 - обработчики встреч и Zoom
        
        # Основные обработчики встреч
        application.add_handler(CallbackQueryHandler(MeetingsManager.show_meetings_list, pattern='^meetings_list$'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.add_zoom_link, pattern='^add_zoom_'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_edit_meeting_menu, pattern='^edit_meeting_menu$'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_delete_meeting_menu, pattern='^delete_meeting_menu$'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_meeting_selection, pattern='^(edit_|delete_|select_)'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_edit_meeting_action, pattern='^edit_action_'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_delete_confirmation, pattern='^confirm_delete_'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_cancel_delete, pattern='^cancel_delete$'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_cancel_action, pattern='^cancel_action$'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.start_add_meeting_callback, pattern='^add_meeting$'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.start_add_meeting_callback, pattern='^create_meeting$'), group=0)
        
        # Обработчики ZOOM
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_auto_zoom, pattern='^auto_zoom_'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_manual_zoom, pattern='^manual_zoom_'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_zoom_share, pattern='^zoom_share_'), group=0)
        application.add_handler(CallbackQueryHandler(MeetingsManager.handle_send_zoom_to_all, pattern='^send_zoom_to_all_'), group=0)
        
        # Обработчик для кнопки копирования Zoom ссылки
        application.add_handler(CallbackQueryHandler(handle_copy_zoom, pattern='^copy_zoom_'), group=0)
        
        # ========== ОБЩАЯ АДМИН-ПАНЕЛЬ ==========
        # Группа 0 - общие админские обработчики (ДОЛЖНЫ БЫТЬ ПОСЛЕ конкретных обработчиков)
        
        # Админ-панель - теперь разбиваем на конкретные обработчики, а не общий '^admin_'
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_stats$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_users$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_payments$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_meetings$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_reports$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_promocodes$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_broadcast$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_faq$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_metrics$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_back$'), group=0)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_panel$'), group=0)
        
        # Общий обработчик других admin_ запросов (должен быть ПОСЛЕ всех конкретных)
        application.add_handler(CallbackQueryHandler(handle_admin, pattern='^admin_'), group=0)
        
        application.add_handler(CallbackQueryHandler(handle_program_selection, pattern='^program_'), group=0)
        
        # ========== ТЕКСТОВЫЕ СООБЩЕНИЯ ==========
        # Группа 1 - текстовые сообщения (средний приоритет)
        
        logger.info("📝 Настройка текстовых обработчиков...")
        
        # Импортируем функции для текстовых обработчиков
        from handlers.utils import handle_zoom_link
        from handlers.admin_meetings import MeetingsManager
        
        # 1. Обработчик ручного ввода Zoom ссылок от админов
        async def handle_manual_zoom_text_wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
            """Обертка для обработки ручного ввода Zoom ссылки"""
            if update.effective_user.id not in Config.ADMIN_IDS:
                return
            
            # Проверяем, есть ли ожидание Zoom ссылки
            if 'adding_zoom_to' in context.user_data and 'zoom_mode' in context.user_data:
                text = update.message.text.strip()
                # Обрабатываем через MeetingsManager
                processed = await MeetingsManager.process_manual_zoom_text(update, context)
                if processed:
                    return
            
            # Если не обработали как Zoom ссылку, передаем дальше
            await handle_text_message(update, context)
        
        application.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND & filters.User(Config.ADMIN_IDS),
            handle_manual_zoom_text_wrapper
        ), group=1)
        
        # 2. Обработчик Zoom ссылок от админов
        application.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND & filters.User(Config.ADMIN_IDS),
            handle_zoom_link
        ), group=1)

        # 3. ОСНОВНОЙ обработчик текстовых сообщений (для всех пользователей)
        application.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            handle_text_message
        ), group=1)

        # 4. Переадресация медиафайлов
        application.add_handler(MessageHandler(
            filters.PHOTO | filters.VIDEO | filters.AUDIO | filters.VOICE,
            forward_user_message
        ), group=1)

        # 5. Для документов
        application.add_handler(MessageHandler(
            filters.Document.ALL,
            forward_user_message
        ), group=1)
        
        # ========== НЕИЗВЕСТНЫЕ КОМАНДЫ ==========
        # Группа 2 - обработчик неизвестных команд (низший приоритет)
        
        application.add_handler(MessageHandler(filters.COMMAND, handle_unknown_command), group=2)
        
        # ========== ОБРАБОТЧИК ОШИБОК ==========
        
        application.add_error_handler(error_handler)
        
        logger.info("✅ Обработчики настроены с правильным порядком и группами")
        
    except Exception as e:
        logger.error(f"❌ Ошибка настройки обработчиков: {e}")
        logger.error(traceback.format_exc())
        raise

async def setup_scheduler_async(application, engine):
    """Асинхронная настройка планировщика"""
    try:
        # Импортируем здесь, чтобы избежать циклических зависимостей
        from scheduler import setup_scheduler
        scheduler = setup_scheduler(application, engine)
        if scheduler:
            logger.info("✅ Планировщик настроен")
        else:
            logger.warning("⚠️ Планировщик не удалось настроить")
        return scheduler
    except Exception as e:
        logger.warning(f"⚠️ Ошибка настройки планировщика: {e}")
        return None

async def main_async():
    """Асинхронная основная функция запуска бота"""
    
    logger.info("=" * 60)
    logger.info("🚀 ИНИЦИАЛИЗАЦИЯ БОТА 'Бестужевки'")
    logger.info("=" * 60)
    
    # Проверка конфигурации
    if not Config.validate():
        logger.error("[ERROR] Конфигурация не прошла проверку. Исправьте .env файл.")
        return
    
    # Инициализация базы данных
    engine = None
    try:
        engine = init_db()
        logger.info("✅ База данных инициализирована")
    except Exception as e:
        logger.error(f"❌ Ошибка инициализации базы данных: {e}")
        logger.error(traceback.format_exc())
        return
    
    # Создание приложения с увеличенными таймаутами
    application = None
    try:
        application = ApplicationBuilder() \
            .token(Config.BOT_TOKEN) \
            .read_timeout(60) \
            .write_timeout(60) \
            .connect_timeout(60) \
            .pool_timeout(60) \
            .get_updates_read_timeout(60) \
            .http_version("1.1") \
            .build()
        
        application.bot_data['engine'] = engine
        logger.info("✅ Приложение Telegram создано с увеличенными таймаутами")
        
    except Exception as e:
        logger.error(f"❌ Ошибка создания приложения Telegram: {e}")
        logger.error(traceback.format_exc())
        return
    
    # Настройка обработчиков
    try:
        setup_handlers(application)
        logger.info("✅ Обработчики настроены")
    except Exception as e:
        logger.error(f"❌ Ошибка настройки обработчиков: {e}")
        logger.error(traceback.format_exc())
        return
    
    # Настройка планировщика (если есть)
    scheduler = None
    try:
        scheduler = await setup_scheduler_async(application, engine)
    except Exception as e:
        logger.warning(f"⚠️ Планировщик не настроен: {e}")
    
    logger.info("=" * 60)
    logger.info("📊 ИНФОРМАЦИЯ:")
    logger.info(f"   Клуб: {Config.CLUB_NAME}")
    logger.info(f"   Админов: {len(Config.ADMIN_IDS)}")
    logger.info(f"   Тинькофф оплата: {'✅' if Config.TINKOFF_TERMINAL_ID and Config.TINKOFF_TERMINAL_PASSWORD else '❌'}")
    logger.info(f"   Zoom интеграция: {'✅' if Config.ZOOM_ENABLED else '❌'}")
    logger.info(f"   Система отчетов: {'✅'}")
    logger.info(f"   Планировщик: {'✅' if scheduler else '❌'}")
    logger.info("=" * 60)
    
    # Уведомление админам с обработкой ошибок
    for admin_id in Config.ADMIN_IDS:
        try:
            await safe_send_message(
                application.bot,
                chat_id=admin_id,
                text=f"""🤖 Бот '{Config.CLUB_NAME}' запущен!

📊 **Доступна полная система отчетов:**
• 📈 Статистика в реальном времени
• 📊 Детальные отчеты (неделя/месяц)
• 📥 Excel выгрузка данных
• 🤖 Автоматические отчеты

🔧 **Новые команды для отладки:**
• /status - статус бота
• /test_scheduler - тест планировщика
• /send_reminder - ручная отправка напоминаний

🔄 Используйте /admin для управления."""
            )
        except Exception as e:
            logger.warning(f"Не удалось отправить уведомление админу {admin_id}: {e}")
    
    # Запуск бота
    try:
        logger.info("✅ Бот успешно запущен!")
        await application.initialize()
        await application.start()
        await application.updater.start_polling(
            drop_pending_updates=True,
            allowed_updates=["message", "callback_query"],
            read_timeout=60,
            write_timeout=60,
            connect_timeout=60,
            pool_timeout=60
        )
        
        logger.info("🔄 Бот работает... Нажмите Ctrl+C для остановки.")
        
        # Бесконечное ожидание
        while True:
            await asyncio.sleep(3600)  # Спим 1 час и проверяем
        
    except KeyboardInterrupt:
        logger.info("⏹️ Бот остановлен пользователем")
    except Exception as e:
        logger.error(f"❌ Фатальная ошибка при работе бота: {e}")
        logger.error(traceback.format_exc())
        raise
    finally:
        if application and application.running:
            try:
                logger.info("🔄 Останавливаем бота...")
                await application.stop()
                await application.shutdown()
                logger.info("✅ Бот остановлен")
            except Exception as e:
                logger.error(f"❌ Ошибка при остановке бота: {e}")
        
        if scheduler:
            try:
                scheduler.shutdown()
            except:
                pass

def main():
    """Основная функция запуска бота"""
    try:
        if sys.platform == 'win32':
            # Для Windows 3.8+ нужно установить политику event loop
            if sys.version_info >= (3, 8):
                asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        
        asyncio.run(main_async())
    except KeyboardInterrupt:
        logger.info("👋 Завершено пользователем")
    except Exception as e:
        logger.error(f"❌ Фатальная ошибка при запуске бота: {e}")
        logger.error(traceback.format_exc())

if __name__ == '__main__':
    main()