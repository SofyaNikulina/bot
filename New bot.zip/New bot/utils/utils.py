import logging
from datetime import datetime
from config import Config

logger = logging.getLogger(__name__)

def format_price(price_in_kopecks: int) -> str:
    """Форматирование цены"""
    rubles = price_in_kopecks / 100
    return f"{rubles:,.0f} ₽".replace(",", " ")

def format_date(date: datetime, include_time: bool = True) -> str:
    """Форматирование даты"""
    if include_time:
        return date.strftime("%d.%m.%Y %H:%M")
    else:
        return date.strftime("%d.%m.%Y")

def validate_phone(phone: str) -> bool:
    """Валидация номера телефона"""
    import re
    
    # Убираем все нецифровые символы
    digits = re.sub(r'\D', '', phone)
    
    # Российские номера: 11 цифр, начинается с 7 или 8
    if len(digits) == 11 and digits.startswith(('7', '8')):
        return True
    
    # Международный формат: начинается с +7
    if phone.startswith('+7') and len(digits) == 11:
        return True
    
    return False

def format_phone(phone: str) -> str:
    """Форматирование номера телефона"""
    import re
    
    digits = re.sub(r'\D', '', phone)
    
    if len(digits) == 11:
        if digits.startswith('8'):
            digits = '7' + digits[1:]
        
        return f"+7 ({digits[1:4]}) {digits[4:7]}-{digits[7:9]}-{digits[9:]}"
    
    return phone

def get_user_timezone_offset(user_tz: str = 'Europe/Moscow') -> int:
    """Получение смещения часового пояса"""
    from datetime import datetime
    import pytz
    
    try:
        tz = pytz.timezone(user_tz)
        now = datetime.now(tz)
        return now.utcoffset().total_seconds() / 3600
    except:
        return 3  # Московское время по умолчанию

def log_metric(session, metric_type: str, value: int, details: dict = None):
    """Логирование метрик"""
    from database import Metric
    
    metric = Metric(
        metric_type=metric_type,
        value=value,
        details=details or {}
    )
    session.add(metric)
    session.commit()

def check_zoom_config():
    """Проверка конфигурации Zoom"""
    if not Config.ZOOM_ENABLED:
        logger.warning("Zoom API не настроен. Встречи нужно будет создавать вручную.")
        return False
    
    # Проверяем наличие всех необходимых параметров
    required = ['ZOOM_ACCOUNT_ID', 'ZOOM_CLIENT_ID', 'ZOOM_CLIENT_SECRET']
    missing = [param for param in required if not getattr(Config, param)]
    
    if missing:
        logger.warning(f"Отсутствуют параметры Zoom: {', '.join(missing)}")
        return False
    
    return True