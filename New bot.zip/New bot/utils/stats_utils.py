# utils/stats_utils.py
from datetime import datetime, timedelta
from sqlalchemy import func, and_, or_
from database import get_session, User, Payment, Subscription, PromoUsage
import logging

logger = logging.getLogger(__name__)

async def get_user_stats(start_date, end_date):
    """Получение статистики пользователей"""
    session = get_session()
    try:
        # Новые пользователи
        new_users = session.query(User).filter(
            User.joined_at.between(start_date, end_date)
        ).count()
        
        # Активные пользователи (были активны за последние 3 дня)
        active_cutoff = datetime.now() - timedelta(days=3)
        active_users = session.query(User).filter(
            User.last_activity >= active_cutoff,
            User.is_active == True
        ).count()
        
        # Пользователи, завершившие регистрацию (согласились с политикой)
        completed_registration = session.query(User).filter(
            User.joined_at.between(start_date, end_date),
            User.agreed_to_policy == True
        ).count()
        
        return {
            'new_users': new_users,
            'active_users': active_users,
            'completed_registration': completed_registration
        }
    
    except Exception as e:
        logger.error(f"Ошибка получения статистики пользователей: {e}")
        return {'new_users': 0, 'active_users': 0, 'completed_registration': 0}
    finally:
        session.close()

async def get_payment_stats(start_date, end_date):
    """Получение статистики платежей"""
    session = get_session()
    try:
        # Новые завершенные платежи
        new_payments = session.query(Payment).filter(
            Payment.created_at.between(start_date, end_date),
            Payment.status == 'completed'
        ).count()
        
        # Общая выручка, средний и максимальный чек
        stats = session.query(
            func.sum(Payment.amount).label('total_revenue'),
            func.avg(Payment.amount).label('average_check'),
            func.max(Payment.amount).label('max_check')
        ).filter(
            Payment.created_at.between(start_date, end_date),
            Payment.status == 'completed'
        ).first()
        
        total_revenue = stats.total_revenue or 0
        average_check = stats.average_check or 0
        max_check = stats.max_check or 0
        
        # Использованные промокоды
        promocodes_used = session.query(PromoUsage).filter(
            PromoUsage.used_at.between(start_date, end_date)
        ).count()
        
        return {
            'new_payments': new_payments,
            'total_revenue': total_revenue,
            'average_check': average_check,
            'max_check': max_check,
            'promocodes_used': promocodes_used
        }
    
    except Exception as e:
        logger.error(f"Ошибка получения статистики платежей: {e}")
        return {
            'new_payments': 0,
            'total_revenue': 0,
            'average_check': 0,
            'max_check': 0,
            'promocodes_used': 0
        }
    finally:
        session.close()

async def get_subscription_stats(start_date, end_date):
    """Получение статистики подписок"""
    session = get_session()
    try:
        # Новые активные подписки
        new_subscriptions = session.query(Subscription).filter(
            Subscription.created_at.between(start_date, end_date),
            Subscription.is_active == True
        ).count()
        
        # Активные подписки
        active_subscriptions = session.query(Subscription).filter(
            Subscription.is_active == True,
            Subscription.end_date >= datetime.now()
        ).count()
        
        # Подписки, заканчивающиеся скоро (в течение 7 дней)
        expires_soon = datetime.now() + timedelta(days=7)
        expiring_soon = session.query(Subscription).filter(
            Subscription.is_active == True,
            Subscription.end_date.between(datetime.now(), expires_soon)
        ).count()
        
        # Подписки с автопродлением
        auto_renewal = session.query(Subscription).filter(
            Subscription.is_active == True,
            Subscription.auto_renewal == True
        ).count()
        
        # Распределение по тарифам
        tariff_distribution = {}
        tariffs = session.query(
            Subscription.tariff,
            func.count(Subscription.id).label('count')
        ).filter(
            Subscription.is_active == True
        ).group_by(Subscription.tariff).all()
        
        for tariff, count in tariffs:
            tariff_distribution[tariff or 'Не указан'] = count
        
        return {
            'new_subscriptions': new_subscriptions,
            'active_subscriptions': active_subscriptions,
            'expiring_soon': expiring_soon,
            'auto_renewal': auto_renewal,
            'tariff_distribution': tariff_distribution
        }
    
    except Exception as e:
        logger.error(f"Ошибка получения статистики подписок: {e}")
        return {
            'new_subscriptions': 0,
            'active_subscriptions': 0,
            'expiring_soon': 0,
            'auto_renewal': 0,
            'tariff_distribution': {}
        }
    finally:
        session.close()

async def get_promocode_stats(start_date, end_date):
    """Получение статистики промокодов"""
    session = get_session()
    try:
        from database import Promocode
        
        # Все активные промокоды
        active_promocodes = session.query(Promocode).filter(
            Promocode.is_active == True,
            or_(
                Promocode.valid_to >= datetime.now(),
                Promocode.valid_to == None
            )
        ).count()
        
        # Промокоды, использованные за период
        used_promocodes = session.query(
            PromoUsage.promocode,
            func.count(PromoUsage.id).label('usage_count'),
            func.sum(Payment.amount).label('total_amount')
        ).join(Payment, Payment.id == PromoUsage.payment_id).filter(
            PromoUsage.used_at.between(start_date, end_date),
            Payment.status == 'completed'
        ).group_by(PromoUsage.promocode).all()
        
        # Эффективность промокодов
        promocode_data = []
        for promocode, usage_count, total_amount in used_promocodes:
            promocode_data.append({
                'code': promocode,
                'usage_count': usage_count,
                'total_amount': total_amount / 100 if total_amount else 0
            })
        
        return {
            'active_promocodes': active_promocodes,
            'used_promocodes': len(used_promocodes),
            'promocode_details': promocode_data
        }
    
    except Exception as e:
        logger.error(f"Ошибка получения статистики промокодов: {e}")
        return {
            'active_promocodes': 0,
            'used_promocodes': 0,
            'promocode_details': []
        }
    finally:
        session.close()

async def get_abandoned_carts_stats(start_date, end_date):
    """Статистика брошенных корзин"""
    session = get_session()
    try:
        from database import AbandonedCart
        
        # Все брошенные корзины за период
        total_abandoned = session.query(AbandonedCart).filter(
            AbandonedCart.created_at.between(start_date, end_date)
        ).count()
        
        # Конвертированные корзины
        converted = session.query(AbandonedCart).filter(
            AbandonedCart.created_at.between(start_date, end_date),
            AbandonedCart.converted == True
        ).count()
        
        # Конверсия брошенных корзин
        conversion_rate = (converted / total_abandoned * 100) if total_abandoned > 0 else 0
        
        # По шагам
        steps = session.query(
            AbandonedCart.step,
            func.count(AbandonedCart.id).label('count')
        ).filter(
            AbandonedCart.created_at.between(start_date, end_date)
        ).group_by(AbandonedCart.step).all()
        
        steps_distribution = {step: count for step, count in steps}
        
        return {
            'total_abandoned': total_abandoned,
            'converted': converted,
            'conversion_rate': conversion_rate,
            'steps_distribution': steps_distribution
        }
    
    except Exception as e:
        logger.error(f"Ошибка получения статистики брошенных корзин: {e}")
        return {
            'total_abandoned': 0,
            'converted': 0,
            'conversion_rate': 0,
            'steps_distribution': {}
        }
    finally:
        session.close()