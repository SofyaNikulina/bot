# utils/excel_export.py
import logging
from datetime import datetime
from io import BytesIO
import pandas as pd
from database import get_session, User, Payment, Subscription, Meeting, PromoUsage, Promocode, AbandonedCart
from sqlalchemy import func, and_, or_
import matplotlib.pyplot as plt
from matplotlib import font_manager
import io
import numpy as np
from openpyxl.styles import Font

logger = logging.getLogger(__name__)

class ExcelExporter:
    """Класс для экспорта данных в Excel"""
    
    def __init__(self, engine):
        self.engine = engine
        self.session = get_session(engine)
    
    def create_full_report(self, start_date=None, end_date=None):
        """Создание полного отчета со всеми данными"""
        output = BytesIO()
        
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            workbook = writer.book
            
            # 1. Сводная информация
            self._create_summary_sheet(writer, start_date, end_date)
            
            # 2. Пользователи
            self._create_users_sheet(writer)
            
            # 3. Платежи
            self._create_payments_sheet(writer, start_date, end_date)
            
            # 4. Подписки
            self._create_subscriptions_sheet(writer)
            
            # 5. Встречи
            self._create_meetings_sheet(writer)
            
            # 6. Промокоды
            self._create_promocodes_sheet(writer, start_date, end_date)
            
            # 7. Брошенные корзины
            self._create_abandoned_carts_sheet(writer, start_date, end_date)
            
            # 8. Статистика и графики
            self._create_statistics_sheet(writer, start_date, end_date)
            
            # Автоширина колонок
            self._auto_adjust_columns(writer)
        
        output.seek(0)
        return output
    
    def create_users_report(self):
        """Отчет по пользователям"""
        output = BytesIO()
        
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            self._create_users_sheet(writer)
            self._create_users_statistics_sheet(writer)
            self._auto_adjust_columns(writer)
        
        output.seek(0)
        return output
    
    def create_payments_report(self, start_date=None, end_date=None):
        """Отчет по платежам"""
        output = BytesIO()
        
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            self._create_payments_sheet(writer, start_date, end_date)
            self._create_financial_statistics_sheet(writer, start_date, end_date)
            self._auto_adjust_columns(writer)
        
        output.seek(0)
        return output
    
    def create_subscriptions_report(self):
        """Отчет по подпискам"""
        output = BytesIO()
        
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            self._create_subscriptions_sheet(writer)
            self._create_subscriptions_statistics_sheet(writer)
            self._auto_adjust_columns(writer)
        
        output.seek(0)
        return output
    
    def create_promocodes_report(self, start_date=None, end_date=None):
        """Отчет по промокодам"""
        output = BytesIO()
        
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            self._create_promocodes_sheet(writer, start_date, end_date)
            self._create_promocodes_statistics_sheet(writer, start_date, end_date)
            self._auto_adjust_columns(writer)
        
        output.seek(0)
        return output
    
    def _create_summary_sheet(self, writer, start_date, end_date):
        """Создание листа со сводной информацией"""
        summary_data = []
        
        # Общая статистика
        total_users = self.session.query(User).count()
        active_users = self.session.query(User).filter(User.is_active == True).count()
        new_users_today = self.session.query(User).filter(
            func.date(User.joined_at) == datetime.now().date()
        ).count()
        
        # Платежи
        payments_query = self.session.query(Payment).filter(Payment.status == 'completed')
        if start_date and end_date:
            payments_query = payments_query.filter(
                Payment.created_at.between(start_date, end_date)
            )
        
        total_payments = payments_query.count()
        total_revenue = sum(p.amount for p in payments_query.all()) / 100
        
        # Подписки
        active_subscriptions = self.session.query(Subscription).filter(
            Subscription.is_active == True
        ).count()
        
        # Встречи
        upcoming_meetings = self.session.query(Meeting).filter(
            Meeting.date_time >= datetime.now(),
            Meeting.is_active == True
        ).count()
        
        summary_data.append(["КЛУБ «БЕСТУЖЕВКИ» - ПОЛНЫЙ ОТЧЕТ", ""])
        summary_data.append(["Дата формирования:", datetime.now().strftime('%d.%m.%Y %H:%M')])
        if start_date and end_date:
            summary_data.append(["Период:", f"{start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}"])
        summary_data.append(["", ""])
        
        summary_data.append(["ОБЩАЯ СТАТИСТИКА", "ЗНАЧЕНИЕ"])
        summary_data.append(["Всего пользователей", total_users])
        summary_data.append(["Активных пользователей", active_users])
        summary_data.append(["Новых пользователей сегодня", new_users_today])
        summary_data.append(["", ""])
        
        summary_data.append(["ФИНАНСЫ", ""])
        summary_data.append(["Всего оплат", total_payments])
        summary_data.append(["Общая выручка", f"{total_revenue:,.0f} ₽"])
        if total_payments > 0:
            summary_data.append(["Средний чек", f"{total_revenue/total_payments:,.0f} ₽"])
        summary_data.append(["", ""])
        
        summary_data.append(["ПОДПИСКИ", ""])
        summary_data.append(["Активных подписок", active_subscriptions])
        summary_data.append(["Заканчивается в течение недели", 
                           self.session.query(Subscription).filter(
                               Subscription.is_active == True,
                               Subscription.end_date.between(
                                   datetime.now(), 
                                   datetime.now() + pd.Timedelta(days=7)
                               )
                           ).count()])
        summary_data.append(["", ""])
        
        summary_data.append(["ВСТРЕЧИ", ""])
        summary_data.append(["Предстоящих встреч", upcoming_meetings])
        summary_data.append(["Всего встреч в базе", self.session.query(Meeting).count()])
        
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_excel(writer, sheet_name='Сводка', index=False, header=False)
        
        # Стилизация
        worksheet = writer.sheets['Сводка']
        # Заголовок
        worksheet['A1'].font = Font(bold=True, size=16)
        worksheet.merge_cells('A1:B1')
        # Подзаголовки
        for row in [5, 10, 15, 19]:
            cell = worksheet[f'A{row}']
            cell.font = Font(bold=True)
    
    def _create_users_sheet(self, writer):
        """Лист с пользователями"""
        users = self.session.query(User).order_by(User.joined_at.desc()).all()
        
        users_data = []
        for user in users:
            # Проверяем подписку
            has_active_sub = self.session.query(Subscription).filter(
                Subscription.user_id == user.id,
                Subscription.is_active == True
            ).first() is not None
            
            # Последняя активность
            last_activity = "Нет активности"
            if user.last_activity:
                days_diff = (datetime.now() - user.last_activity).days
                if days_diff == 0:
                    last_activity = "Сегодня"
                elif days_diff == 1:
                    last_activity = "Вчера"
                elif days_diff < 7:
                    last_activity = f"{days_diff} дня назад"
                else:
                    last_activity = user.last_activity.strftime('%d.%m.%Y')
            
            users_data.append([
                user.id,
                f"{user.first_name or ''} {user.last_name or ''}".strip() or "Без имени",
                f"@{user.username}" if user.username else "",
                user.phone_number or "",
                user.email or "",
                "Да" if user.agreed_to_policy else "Нет",
                user.joined_at.strftime('%d.%m.%Y %H:%M'),
                last_activity,
                "Да" if has_active_sub else "Нет",
                "Активен" if user.is_active else "Неактивен"
            ])
        
        if users_data:
            users_df = pd.DataFrame(users_data, columns=[
                'ID', 'Имя', 'Username', 'Телефон', 'Email', 
                'Согласие с политикой', 'Дата регистрации', 
                'Последняя активность', 'Активная подписка', 'Статус'
            ])
            users_df.to_excel(writer, sheet_name='Пользователи', index=False)
    
    def _create_users_statistics_sheet(self, writer):
        """Лист со статистикой пользователей"""
        stats_data = []
        
        # Регистрации по дням (последние 30 дней)
        thirty_days_ago = datetime.now() - pd.Timedelta(days=30)
        registrations = self.session.query(
            func.date(User.joined_at).label('date'),
            func.count(User.id).label('count')
        ).filter(
            User.joined_at >= thirty_days_ago
        ).group_by(func.date(User.joined_at)).order_by(func.date(User.joined_at)).all()
        
        stats_data.append(["РЕГИСТРАЦИИ ПО ДНЯМ (последние 30 дней)", ""])
        stats_data.append(["Дата", "Количество регистраций"])
        
        for date, count in registrations:
            # ИСПРАВЛЕНО: date может быть datetime.date, а не datetime.datetime
            if hasattr(date, 'strftime'):
                date_str = date.strftime('%d.%m.%Y')
            else:
                date_str = str(date)
            stats_data.append([date_str, count])
        
        stats_data.append(["", ""])
        
        # Распределение по источникам
        sources = self.session.query(
            User.source,
            func.count(User.id).label('count')
        ).filter(User.source.isnot(None)).group_by(User.source).all()
        
        stats_data.append(["ИСТОЧНИКИ ТРАФИКА", ""])
        stats_data.append(["Источник", "Количество"])
        
        for source, count in sources:
            stats_data.append([source or "Не указан", count])
        
        stats_df = pd.DataFrame(stats_data)
        stats_df.to_excel(writer, sheet_name='Статистика пользователей', index=False, header=False)
    
    def _create_payments_sheet(self, writer, start_date=None, end_date=None):
        """Лист с платежами"""
        payments_query = self.session.query(Payment).filter(Payment.status == 'completed')
        
        if start_date and end_date:
            payments_query = payments_query.filter(
                Payment.created_at.between(start_date, end_date)
            )
        
        payments = payments_query.order_by(Payment.created_at.desc()).all()
        
        payments_data = []
        for payment in payments:
            user_name = f"{payment.user.first_name or ''} {payment.user.last_name or ''}".strip()
            if not user_name:
                user_name = "Без имени"
            
            payments_data.append([
                payment.id,
                payment.user.telegram_id if payment.user else "",
                user_name,
                payment.amount / 100,
                payment.tariff,
                payment.promocode or "",
                "Да" if payment.discount > 0 else "Нет",
                payment.discount / 100 if payment.discount else 0,
                payment.created_at.strftime('%d.%m.%Y %H:%M'),
                payment.status
            ])
        
        if payments_data:
            payments_df = pd.DataFrame(payments_data, columns=[
                'ID платежа', 'Telegram ID', 'Имя', 'Сумма (₽)', 'Тариф',
                'Промокод', 'Скидка применена', 'Сумма скидки (₽)',
                'Дата оплаты', 'Статус'
            ])
            payments_df.to_excel(writer, sheet_name='Платежи', index=False)
    
    def _create_financial_statistics_sheet(self, writer, start_date=None, end_date=None):
        """Лист с финансовой статистикой"""
        stats_data = []
        
        # Выручка по дням
        revenue_query = self.session.query(
            func.date(Payment.created_at).label('date'),
            func.sum(Payment.amount).label('revenue'),
            func.count(Payment.id).label('count')
        ).filter(
            Payment.status == 'completed'
        )
        
        if start_date and end_date:
            revenue_query = revenue_query.filter(
                Payment.created_at.between(start_date, end_date)
            )
        else:
            # Последние 30 дней по умолчанию
            thirty_days_ago = datetime.now() - pd.Timedelta(days=30)
            revenue_query = revenue_query.filter(Payment.created_at >= thirty_days_ago)
        
        daily_revenue = revenue_query.group_by(func.date(Payment.created_at)).order_by(func.date(Payment.created_at)).all()
        
        stats_data.append(["ВЫРУЧКА ПО ДНЯМ", "", ""])
        stats_data.append(["Дата", "Выручка (₽)", "Количество оплат"])
        
        total_revenue = 0
        total_payments = 0
        
        for date, revenue, count in daily_revenue:
            revenue_rub = revenue / 100 if revenue else 0
            # ИСПРАВЛЕНО: проверка на наличие strftime
            if hasattr(date, 'strftime'):
                date_str = date.strftime('%d.%m.%Y')
            else:
                date_str = str(date)
            stats_data.append([date_str, revenue_rub, count])
            total_revenue += revenue_rub
            total_payments += count
        
        stats_data.append(["", "", ""])
        stats_data.append(["ИТОГО:", total_revenue, total_payments])
        stats_data.append(["", "", ""])
        
        # Выручка по тарифам
        tariff_revenue = self.session.query(
            Payment.tariff,
            func.sum(Payment.amount).label('revenue'),
            func.count(Payment.id).label('count')
        ).filter(
            Payment.status == 'completed'
        ).group_by(Payment.tariff).all()
        
        stats_data.append(["ВЫРУЧКА ПО ТАРИФАМ", "", ""])
        stats_data.append(["Тариф", "Выручка (₽)", "Количество"])
        
        for tariff, revenue, count in tariff_revenue:
            revenue_rub = revenue / 100 if revenue else 0
            tariff_name = self._get_tariff_name(tariff)
            stats_data.append([tariff_name, revenue_rub, count])
        
        stats_df = pd.DataFrame(stats_data)
        stats_df.to_excel(writer, sheet_name='Финансовая статистика', index=False, header=False)
    
    def _create_subscriptions_sheet(self, writer):
        """Лист с подписками"""
        subscriptions = self.session.query(Subscription).order_by(Subscription.end_date.desc()).all()
        
        subscriptions_data = []
        for sub in subscriptions:
            user_name = f"{sub.user.first_name or ''} {sub.user.last_name or ''}".strip()
            if not user_name:
                user_name = "Без имени"
            
            # Дней до окончания
            days_left = "Истекла"
            if sub.end_date and sub.end_date > datetime.now():
                days_left = (sub.end_date - datetime.now()).days
            
            subscriptions_data.append([
                sub.id,
                user_name,
                sub.user.telegram_id if sub.user else "",
                self._get_tariff_name(sub.tariff),
                sub.start_date.strftime('%d.%m.%Y') if sub.start_date else "",
                sub.end_date.strftime('%d.%m.%Y') if sub.end_date else "",
                days_left,
                "Да" if sub.auto_renewal else "Нет",
                "Активна" if sub.is_active else "Неактивна",
                sub.created_at.strftime('%d.%m.%Y %H:%M') if sub.created_at else ""
            ])
        
        if subscriptions_data:
            subscriptions_df = pd.DataFrame(subscriptions_data, columns=[
                'ID подписки', 'Имя', 'Telegram ID', 'Тариф', 'Дата начала',
                'Дата окончания', 'Дней до окончания', 'Автопродление',
                'Статус', 'Дата создания'
            ])
            subscriptions_df.to_excel(writer, sheet_name='Подписки', index=False)
    
    def _create_subscriptions_statistics_sheet(self, writer):
        """Лист со статистикой подписок"""
        stats_data = []
        
        # Распределение по тарифам
        tariff_stats = self.session.query(
            Subscription.tariff,
            func.count(Subscription.id).label('count')
        ).filter(Subscription.is_active == True).group_by(Subscription.tariff).all()
        
        stats_data.append(["РАСПРЕДЕЛЕНИЕ ПО ТАРИФАМ", ""])
        stats_data.append(["Тариф", "Количество активных подписок"])
        
        for tariff, count in tariff_stats:
            tariff_name = self._get_tariff_name(tariff)
            stats_data.append([tariff_name, count])
        
        stats_data.append(["", ""])
        
        # Подписки по месяцам окончания
        month_stats = self.session.query(
            func.extract('month', Subscription.end_date).label('month'),
            func.extract('year', Subscription.end_date).label('year'),
            func.count(Subscription.id).label('count')
        ).filter(
            Subscription.is_active == True,
            Subscription.end_date >= datetime.now()
        ).group_by(
            func.extract('year', Subscription.end_date),
            func.extract('month', Subscription.end_date)
        ).order_by('year', 'month').all()
        
        stats_data.append(["ОКОНЧАНИЕ ПОДПИСОК ПО МЕСЯЦАМ", ""])
        stats_data.append(["Месяц", "Количество подписок"])
        
        for month, year, count in month_stats:
            month_name = self._get_month_name(int(month))
            stats_data.append([f"{month_name} {int(year)}", count])
        
        stats_df = pd.DataFrame(stats_data)
        stats_df.to_excel(writer, sheet_name='Статистика подписок', index=False, header=False)
    
    def _create_meetings_sheet(self, writer):
        """Лист со встречами"""
        meetings = self.session.query(Meeting).order_by(Meeting.date_time).all()
        
        meetings_data = []
        for meeting in meetings:
            status = "Предстоящая" if meeting.date_time > datetime.now() else "Прошедшая"
            
            meetings_data.append([
                meeting.id,
                meeting.title,
                meeting.date_time.strftime('%d.%m.%Y %H:%M'),
                meeting.duration,
                status,
                "Да" if meeting.zoom_link else "Нет",
                "Активна" if meeting.is_active else "Неактивна",
                meeting.created_at.strftime('%d.%m.%Y %H:%M') if meeting.created_at else ""
            ])
        
        if meetings_data:
            meetings_df = pd.DataFrame(meetings_data, columns=[
                'ID встречи', 'Название', 'Дата и время', 'Длительность (мин)',
                'Статус', 'Есть Zoom', 'Активность', 'Дата создания'
            ])
            meetings_df.to_excel(writer, sheet_name='Встречи', index=False)
    
    def _create_promocodes_sheet(self, writer, start_date=None, end_date=None):
        """Лист с промокодами"""
        promocodes = self.session.query(Promocode).order_by(Promocode.created_at.desc()).all()
        
        promocodes_data = []
        for promo in promocodes:
            # Статус промокода
            status = "Активен"
            if not promo.is_active:
                status = "Неактивен"
            elif promo.valid_to and promo.valid_to < datetime.now():
                status = "Истек"
            elif promo.max_uses and promo.used_count >= promo.max_uses:
                status = "Исчерпан"
            
            promocodes_data.append([
                promo.code,
                promo.discount_amount / 100 if promo.discount_amount else 0,
                f"{promo.discount_percent}%" if promo.discount_percent else "0%",
                self._get_tariff_name(promo.tariff) if promo.tariff else "Все тарифы",
                promo.max_uses,
                promo.used_count,
                promo.valid_from.strftime('%d.%m.%Y') if promo.valid_from else "",
                promo.valid_to.strftime('%d.%m.%Y') if promo.valid_to else "Без ограничений",
                status,
                promo.description or ""
            ])
        
        if promocodes_data:
            promocodes_df = pd.DataFrame(promocodes_data, columns=[
                'Промокод', 'Скидка (₽)', 'Скидка (%)', 'Тариф', 
                'Макс. использований', 'Использовано', 'Действует с',
                'Действует до', 'Статус', 'Описание'
            ])
            promocodes_df.to_excel(writer, sheet_name='Промокоды', index=False)
    
    def _create_promocodes_statistics_sheet(self, writer, start_date=None, end_date=None):
        """Лист со статистикой промокодов"""
        stats_data = []
        
        # Использованные промокоды за период
        usage_query = self.session.query(
            PromoUsage.promocode,
            func.count(PromoUsage.id).label('usage_count'),
            func.sum(PromoUsage.discount_amount).label('total_discount')
        )
        
        if start_date and end_date:
            usage_query = usage_query.filter(
                PromoUsage.used_at.between(start_date, end_date)
            )
        
        usage_stats = usage_query.group_by(PromoUsage.promocode).all()
        
        stats_data.append(["ИСПОЛЬЗОВАНИЕ ПРОМОКОДОВ", "", ""])
        stats_data.append(["Промокод", "Использовано раз", "Общая скидка (₽)"])
        
        total_usage = 0
        total_discount = 0
        
        for promocode, usage_count, discount in usage_stats:
            discount_rub = discount / 100 if discount else 0
            stats_data.append([promocode, usage_count, discount_rub])
            total_usage += usage_count
            total_discount += discount_rub
        
        stats_data.append(["", "", ""])
        stats_data.append(["ИТОГО:", total_usage, total_discount])
        
        stats_df = pd.DataFrame(stats_data)
        stats_df.to_excel(writer, sheet_name='Статистика промокодов', index=False, header=False)
    
    def _create_abandoned_carts_sheet(self, writer, start_date=None, end_date=None):
        """Лист с брошенными корзинами"""
        carts_query = self.session.query(AbandonedCart)
        
        if start_date and end_date:
            carts_query = carts_query.filter(
                AbandonedCart.created_at.between(start_date, end_date)
            )
        
        carts = carts_query.order_by(AbandonedCart.created_at.desc()).all()
        
        carts_data = []
        for cart in carts:
            user_name = f"{cart.user.first_name or ''} {cart.user.last_name or ''}".strip()
            if not user_name:
                user_name = "Без имени"
            
            carts_data.append([
                cart.id,
                user_name,
                cart.user.telegram_id if cart.user else "",
                self._get_tariff_name(cart.tariff) if cart.tariff else "",
                cart.promocode or "",
                cart.step or "",
                cart.created_at.strftime('%d.%m.%Y %H:%M') if cart.created_at else "",
                "Да" if cart.reminded else "Нет",
                "Да" if cart.converted else "Нет"
            ])
        
        if carts_data:
            carts_df = pd.DataFrame(carts_data, columns=[
                'ID корзины', 'Имя', 'Telegram ID', 'Тариф', 'Промокод',
                'Шаг остановки', 'Дата создания', 'Напоминание отправлено',
                'Конвертировано'
            ])
            carts_df.to_excel(writer, sheet_name='Брошенные корзины', index=False)
    
    def _create_statistics_sheet(self, writer, start_date=None, end_date=None):
        """Лист со сводной статистикой и графиками"""
        stats_data = []
        
        # Конверсия
        all_users = self.session.query(User).count()
        paying_users = self.session.query(User).join(Payment).filter(
            Payment.status == 'completed'
        ).distinct(User.id).count()
        
        conversion_rate = (paying_users / all_users * 100) if all_users > 0 else 0
        
        stats_data.append(["КЛЮЧЕВЫЕ ПОКАЗАТЕЛИ", ""])
        stats_data.append(["Конверсия в оплату", f"{conversion_rate:.1f}%"])
        stats_data.append(["Всего пользователей", all_users])
        stats_data.append(["Уникальных оплативших", paying_users])
        
        # Удержание (пользователи с активной подпиской)
        active_subs = self.session.query(Subscription).filter(
            Subscription.is_active == True
        ).count()
        retention_rate = (active_subs / all_users * 100) if all_users > 0 else 0
        
        stats_data.append(["Удержание (активные подписки)", f"{retention_rate:.1f}%"])
        stats_data.append(["", ""])
        
        # Метрики за период
        if start_date and end_date:
            new_users_period = self.session.query(User).filter(
                User.joined_at.between(start_date, end_date)
            ).count()
            
            payments_period = self.session.query(Payment).filter(
                Payment.created_at.between(start_date, end_date),
                Payment.status == 'completed'
            ).count()
            
            revenue_period = sum(p.amount for p in self.session.query(Payment).filter(
                Payment.created_at.between(start_date, end_date),
                Payment.status == 'completed'
            ).all()) / 100
            
            stats_data.append(["МЕТРИКИ ЗА ПЕРИОД", ""])
            stats_data.append(["Новых пользователей", new_users_period])
            stats_data.append(["Оплат", payments_period])
            stats_data.append(["Выручка", f"{revenue_period:,.0f} ₽"])
        
        stats_df = pd.DataFrame(stats_data)
        stats_df.to_excel(writer, sheet_name='Ключевые показатели', index=False, header=False)
    
    def _get_tariff_name(self, tariff_code):
        """Получение читаемого имени тарифа"""
        tariff_names = {
            'creative': 'Творческий',
            '1_month': '1 месяц',
            '3_months': '3 месяца',
            '12_months': '12 месяцев'
        }
        return tariff_names.get(tariff_code, tariff_code)
    
    def _get_month_name(self, month_number):
        """Получение названия месяца"""
        months = [
            'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
            'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
        ]
        return months[month_number - 1] if 1 <= month_number <= 12 else str(month_number)
    
    def _auto_adjust_columns(self, writer):
        """Автоматическая настройка ширины колонок"""
        for sheet_name in writer.sheets:
            worksheet = writer.sheets[sheet_name]
            for column_cells in worksheet.columns:
                # Пропускаем merged cells
                try:
                    # Получаем первую ячейку в колонке (не merged)
                    first_cell = None
                    for cell in column_cells:
                        if not isinstance(cell, type(worksheet['A1'])):  # Если это MergedCell, пропускаем
                            continue
                        first_cell = cell
                        break
                    
                    if first_cell:
                        max_length = 0
                        column_letter = first_cell.column_letter
                        
                        for cell in column_cells:
                            try:
                                if cell.value:
                                    cell_value = str(cell.value)
                                    if len(cell_value) > max_length:
                                        max_length = len(cell_value)
                            except:
                                pass
                        
                        adjusted_width = min(max_length + 2, 50)
                        worksheet.column_dimensions[column_letter].width = adjusted_width
                except Exception as e:
                    # Пропускаем ошибки при настройке ширины
                    logger.debug(f"Не удалось настроить ширину колонки: {e}")
    
    def close(self):
        """Закрытие сессии"""
        self.session.close()