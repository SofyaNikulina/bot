import requests
import json
import hashlib

def test_tinkoff_api():
    """Тестирование API Тинькофф напрямую"""
    
    terminal_id = "1766571154905"
    terminal_password = "B9J0Zfp5j*SoJeVr"
    base_url = "https://securepay.tinkoff.ru/v2/"
    
    def generate_token(data_dict, password):
        """Генерация токена для Тинькофф"""
        params_list = []
        excluded_keys = ['DATA', 'Receipt', 'Token']
        
        for key, value in data_dict.items():
            if key not in excluded_keys:
                str_value = "" if value is None else str(value)
                params_list.append({key: str_value})
        
        params_list.append({"Password": password})
        params_list.sort(key=lambda x: list(x.keys())[0])
        
        token_string = ""
        for param in params_list:
            token_string += list(param.values())[0]
        
        return hashlib.sha256(token_string.encode('utf-8')).hexdigest()
    
    # Вариант 1: Минимальные параметры (исключаем URL)
    print("🔧 Тест 1: Минимальные параметры (без URL)...")
    data1 = {
        "TerminalKey": terminal_id,
        "Amount": 500000,  # 5000 рублей в копейках
        "OrderId": f"test_order_{int(time.time())}",
        "Description": "Тест платежа",
        "Currency": 643,
        "Recurrent": "N",
        "Language": "ru",
    }
    
    token1 = generate_token(data1, terminal_password)
    data1["Token"] = token1
    
    response1 = requests.post(
        f"{base_url}Init",
        json=data1,
        headers={'Content-Type': 'application/json'},
        timeout=10
    )
    
    print(f"✅ Ответ теста 1: {response1.status_code}")
    print(f"   Результат: {response1.text[:200]}")
    
    # Вариант 2: С URL (текущая конфигурация)
    print("\n🔧 Тест 2: С URL (текущая конфигурация)...")
    data2 = {
        "TerminalKey": terminal_id,
        "Amount": 500000,
        "OrderId": f"test_order_url_{int(time.time())}",
        "Description": "Тест с URL",
        "Currency": 643,
        "Recurrent": "N",
        "Language": "ru",
        "SuccessURL": "https://t.me/bestuzhevka_bot?start=payment_success",
        "FailURL": "https://t.me/bestuzhevka_bot?start=payment_failed",
    }
    
    token2 = generate_token(data2, terminal_password)
    data2["Token"] = token2
    
    response2 = requests.post(
        f"{base_url}Init",
        json=data2,
        headers={'Content-Type': 'application/json'},
        timeout=10
    )
    
    print(f"✅ Ответ теста 2: {response2.status_code}")
    print(f"   Результат: {response2.text}")
    
    # Вариант 3: Проверка терминала
    print("\n🔧 Тест 3: Проверка терминала...")
    data3 = {
        "TerminalKey": terminal_id,
    }
    
    token3 = generate_token(data3, terminal_password)
    data3["Token"] = token3
    
    response3 = requests.post(
        f"{base_url}CheckTerminal",
        json=data3,
        headers={'Content-Type': 'application/json'},
        timeout=10
    )
    
    print(f"✅ Ответ теста 3: {response3.status_code}")
    print(f"   Результат: {response3.text}")

if __name__ == "__main__":
    import time
    test_tinkoff_api()