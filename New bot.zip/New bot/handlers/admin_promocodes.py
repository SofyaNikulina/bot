from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, ConversationHandler, CommandHandler, MessageHandler, filters, CallbackQueryHandler
from database import get_session, Promocode
from keyboards import get_admin_back_keyboard, get_cancel_keyboard
from config import Config
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# States для ConversationHandler
PROMO_CODE, PROMO_DISCOUNT_TYPE, PROMO_DISCOUNT_VALUE, PROMO_TARIFF, PROMO_MAX_USES, PROMO_VALID_TO, PROMO_DESCRIPTION = range(7)

async def manage_promocodes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Управление промокодами"""
    query = update.callback_query
    await query.answer()
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        # Получаем все промокоды
        promocodes = session.query(Promocode).order_by(Promocode.created_at.desc()).all()
        
        text = "<b>🎫 Управление промокодами</b>\n\n"
        
        if not promocodes:
            text += "Нет созданных промокодов.\n"
        else:
            active_count = sum(1 for p in promocodes if p.is_active)
            expired_count = sum(1 for p in promocodes if p.valid_to and p.valid_to < datetime.now())
            text += f"<b>Статистика:</b>\n"
            text += f"• Всего промокодов: {len(promocodes)}\n"
            text += f"• Активных: {active_count}\n"
            text += f"• Просроченных: {expired_count}\n"
            text += f"• Использовано: {sum(p.used_count for p in promocodes)} раз\n\n"
        
        # Создаем клавиатуру
        keyboard = [
            [InlineKeyboardButton("➕ Создать промокод", callback_data='create_promocode')],
            [InlineKeyboardButton("📋 Список всех промокодов", callback_data='list_promocodes')],
            [InlineKeyboardButton("📊 Активные промокоды", callback_data='active_promocodes')],
            [InlineKeyboardButton("🕒 Просроченные промокоды", callback_data='expired_promocodes')],
            [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
        ]
        
        await query.message.edit_text(
            text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        
    except Exception as e:
        logger.error(f"Ошибка при отображении управления промокодами: {e}")
        await query.message.edit_text("❌ Ошибка при загрузке данных.")
    finally:
        session.close()

async def list_promocodes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать список всех промокодов"""
    query = update.callback_query
    await query.answer()
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        # Получаем все промокоды
        promocodes = session.query(Promocode).order_by(Promocode.created_at.desc()).all()
        
        if not promocodes:
            text = "<b>📋 Список промокодов</b>\n\nНет созданных промокодов."
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("➕ Создать промокод", callback_data='create_promocode')],
                [InlineKeyboardButton("◀️ Назад", callback_data='admin_promocodes')]
            ])
        else:
            text = "<b>📋 Список всех промокодов</b>\n\n"
            
            for i, promo in enumerate(promocodes, 1):
                # Определяем статус
                is_expired = promo.valid_to and promo.valid_to < datetime.now()
                is_active = promo.is_active and not is_expired
                
                if is_expired:
                    status = "🕒"
                elif is_active:
                    status = "✅"
                else:
                    status = "⏸️"
                
                # Определяем тип скидки
                if promo.discount_amount > 0:
                    discount = f"{promo.discount_amount/100:.0f} ₽"
                elif promo.discount_percent > 0:
                    discount = f"{promo.discount_percent}%"
                else:
                    discount = "0"
                
                # Определяем использование
                if promo.max_uses and promo.max_uses > 0:
                    uses = f"{promo.used_count}/{promo.max_uses}"
                else:
                    uses = f"{promo.used_count}/∞"
                
                text += f"{i}. {status} <code>{promo.code}</code>\n"
                text += f"   💰 <b>Скидка:</b> {discount}"
                if promo.tariff:
                    text += f" для <b>'{promo.tariff}'</b>"
                text += f"\n"
                text += f"   📊 <b>Использовано:</b> {uses}"
                if promo.valid_to:
                    valid_status = "🕒 " if is_expired else ""
                    text += f" | 📅 <b>До:</b> {valid_status}{promo.valid_to.strftime('%d.%m.%Y')}"
                else:
                    text += f" | 📅 <b>До:</b> бессрочно"
                text += f"\n"
                if promo.description:
                    text += f"   📝 {promo.description[:50]}"
                    if len(promo.description) > 50:
                        text += "..."
                text += f"\n\n"
            
            text += f"<b>Всего:</b> {len(promocodes)} промокодов"
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Создать промокод", callback_data='create_promocode')],
            [InlineKeyboardButton("📊 Только активные", callback_data='active_promocodes')],
            [InlineKeyboardButton("◀️ Назад", callback_data='admin_promocodes')]
        ])
        
        await query.message.edit_text(
            text,
            reply_markup=keyboard,
            parse_mode='HTML'
        )
        
    except Exception as e:
        logger.error(f"Ошибка при отображении списка промокодов: {e}")
        await query.message.edit_text("❌ Ошибка при загрузке списка промокодов.")
    finally:
        session.close()

async def active_promocodes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать только активные промокоды"""
    query = update.callback_query
    await query.answer()
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        # Получаем только активные промокоды
        now = datetime.now()
        promocodes = session.query(Promocode).filter(
            Promocode.is_active == True,
            (Promocode.valid_to.is_(None) | (Promocode.valid_to >= now))
        ).order_by(Promocode.created_at.desc()).all()
        
        if not promocodes:
            text = "<b>📊 Активные промокоды</b>\n\nНет активных промокодов."
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("➕ Создать промокод", callback_data='create_promocode')],
                [InlineKeyboardButton("📋 Все промокоды", callback_data='list_promocodes')],
                [InlineKeyboardButton("◀️ Назад", callback_data='admin_promocodes')]
            ])
        else:
            text = "<b>📊 Активные промокоды</b>\n\n"
            
            for i, promo in enumerate(promocodes, 1):
                # Определяем тип скидки
                if promo.discount_amount > 0:
                    discount = f"{promo.discount_amount/100:.0f} ₽"
                elif promo.discount_percent > 0:
                    discount = f"{promo.discount_percent}%"
                else:
                    discount = "0"
                
                # Определяем использование
                if promo.max_uses and promo.max_uses > 0:
                    uses = f"{promo.used_count}/{promo.max_uses}"
                else:
                    uses = f"{promo.used_count}/∞"
                
                text += f"{i}. ✅ <code>{promo.code}</code>\n"
                text += f"   💰 <b>Скидка:</b> {discount}"
                if promo.tariff:
                    text += f" для <b>'{promo.tariff}'</b>"
                text += f"\n"
                text += f"   📊 <b>Использовано:</b> {uses}"
                if promo.valid_to:
                    text += f" | 📅 <b>До:</b> {promo.valid_to.strftime('%d.%m.%Y')}"
                else:
                    text += f" | 📅 <b>До:</b> бессрочно"
                text += f"\n"
                if promo.description:
                    text += f"   📝 {promo.description[:40]}..."
                text += f"\n\n"
            
            text += f"<b>Всего активных:</b> {len(promocodes)} промокодов"
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Создать промокод", callback_data='create_promocode')],
            [InlineKeyboardButton("📋 Все промокоды", callback_data='list_promocodes')],
            [InlineKeyboardButton("🕒 Просроченные", callback_data='expired_promocodes')],
            [InlineKeyboardButton("◀️ Назад", callback_data='admin_promocodes')]
        ])
        
        await query.message.edit_text(
            text,
            reply_markup=keyboard,
            parse_mode='HTML'
        )
        
    except Exception as e:
        logger.error(f"Ошибка при отображении активных промокодов: {e}")
        await query.message.edit_text("❌ Ошибка при загрузке активных промокодов.")
    finally:
        session.close()

async def expired_promocodes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать просроченные промокоды"""
    query = update.callback_query
    await query.answer()
    
    engine = context.bot_data.get('engine')
    if not engine:
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    session = get_session(engine)
    
    try:
        # Получаем просроченные промокоды
        now = datetime.now()
        promocodes = session.query(Promocode).filter(
            Promocode.valid_to.isnot(None),
            Promocode.valid_to < now
        ).order_by(Promocode.valid_to.desc()).all()
        
        if not promocodes:
            text = "<b>🕒 Просроченные промокоды</b>\n\nНет просроченных промокодов."
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("➕ Создать промокод", callback_data='create_promocode')],
                [InlineKeyboardButton("📋 Все промокоды", callback_data='list_promocodes')],
                [InlineKeyboardButton("◀️ Назад", callback_data='admin_promocodes')]
            ])
        else:
            text = "<b>🕒 Просроченные промокоды</b>\n\n"
            
            for i, promo in enumerate(promocodes, 1):
                # Определяем тип скидки
                if promo.discount_amount > 0:
                    discount = f"{promo.discount_amount/100:.0f} ₽"
                elif promo.discount_percent > 0:
                    discount = f"{promo.discount_percent}%"
                else:
                    discount = "0"
                
                text += f"{i}. 🕒 <code>{promo.code}</code>\n"
                text += f"   💰 <b>Скидка:</b> {discount}"
                if promo.tariff:
                    text += f" для <b>'{promo.tariff}'</b>"
                text += f"\n"
                text += f"   📊 <b>Использовано:</b> {promo.used_count} раз"
                text += f" | 📅 <b>Истек:</b> {promo.valid_to.strftime('%d.%m.%Y')}"
                text += f"\n"
                if promo.description:
                    text += f"   📝 {promo.description[:40]}..."
                text += f"\n\n"
            
            text += f"<b>Всего просроченных:</b> {len(promocodes)} промокодов"
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Создать промокод", callback_data='create_promocode')],
            [InlineKeyboardButton("📋 Все промокоды", callback_data='list_promocodes')],
            [InlineKeyboardButton("📊 Активные", callback_data='active_promocodes')],
            [InlineKeyboardButton("◀️ Назад", callback_data='admin_promocodes')]
        ])
        
        await query.message.edit_text(
            text,
            reply_markup=keyboard,
            parse_mode='HTML'
        )
        
    except Exception as e:
        logger.error(f"Ошибка при отображении просроченных промокодов: {e}")
        await query.message.edit_text("❌ Ошибка при загрузке просроченных промокодов.")
    finally:
        session.close()

async def start_create_promocode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начало создания промокода"""
    query = update.callback_query
    await query.answer()
    
    text = """<b>➕ Создание нового промокода</b>

Введите код промокода (только латинские буквы и цифры):
Пример: BEST2024, WELCOME50, SPRING1000"""
    
    await query.message.edit_text(text, parse_mode='HTML')
    return PROMO_CODE

async def process_promocode_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка кода промокода"""
    code = update.message.text.strip().upper()
    
    # Проверяем формат
    if not code.isalnum():
        await update.message.reply_text("❌ Код должен содержать только латинские буквы и цифры. Попробуйте еще раз:")
        return PROMO_CODE
    
    if len(code) < 4:
        await update.message.reply_text("❌ Код должен содержать минимум 4 символа. Попробуйте еще раз:")
        return PROMO_CODE
    
    engine = context.bot_data.get('engine')
    if not engine:
        await update.message.reply_text("❌ Ошибка подключения к базе данных.")
        return ConversationHandler.END
    
    session = get_session(engine)
    
    # Проверяем, не существует ли уже такой промокод
    existing = session.query(Promocode).filter_by(code=code).first()
    if existing:
        await update.message.reply_text(f"❌ Промокод <code>{code}</code> уже существует. Введите другой код:")
        session.close()
        return PROMO_CODE
    
    session.close()
    
    context.user_data['promocode_code'] = code
    
    text = f"""✅ <b>Код промокода сохранен:</b> <code>{code}</code>

Выберите тип скидки:
1. <b>Фиксированная сумма</b> (например, 1000 ₽)
2. <b>Процентная скидка</b> (например, 20%)"""
    
    keyboard = [
        [InlineKeyboardButton("💰 Фиксированная сумма", callback_data='discount_fixed')],
        [InlineKeyboardButton("📊 Процентная скидка", callback_data='discount_percent')],
        [InlineKeyboardButton("❌ Отмена", callback_data='cancel_promocode')]
    ]
    
    await update.message.reply_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )
    
    return PROMO_DISCOUNT_TYPE

async def process_discount_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка типа скидки"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'discount_fixed':
        context.user_data['discount_type'] = 'fixed'
        text = "Введите сумму скидки в рублях:\nПример: 1000 (для 1000 ₽)"
    elif query.data == 'discount_percent':
        context.user_data['discount_type'] = 'percent'
        text = "Введите процент скидки (1-100):\nПример: 20 (для 20%)"
    elif query.data == 'cancel_promocode':
        await query.message.edit_text("❌ Создание промокода отменено.")
        return ConversationHandler.END
    
    await query.message.edit_text(text, parse_mode='HTML')
    return PROMO_DISCOUNT_VALUE

async def process_discount_value(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка значения скидки"""
    value_str = update.message.text.strip()
    
    try:
        discount_type = context.user_data.get('discount_type')
        
        if discount_type == 'fixed':
            value = int(value_str)
            if value <= 0:
                await update.message.reply_text("❌ Сумма должна быть больше 0. Попробуйте еще раз:")
                return PROMO_DISCOUNT_VALUE
            
            context.user_data['discount_value'] = value * 100  # Сохраняем в копейках
            discount_text = f"{value} ₽"
            
        elif discount_type == 'percent':
            value = int(value_str)
            if value < 1 or value > 100:
                await update.message.reply_text("❌ Процент должен быть от 1 до 100. Попробуйте еще раз:")
                return PROMO_DISCOUNT_VALUE
            
            context.user_data['discount_value'] = value
            discount_text = f"{value}%"
        
        text = f"""✅ <b>Скидка сохранена:</b> {discount_text}

Выберите тариф, для которого действует промокод:
• Если оставить пустым, промокод будет действовать для всех тарифов"""
        
        # Создаем клавиатуру с тарифами
        keyboard = []
        tariffs = ['creative', '1_month', '3_months', '12_months']
        
        for i in range(0, len(tariffs), 2):
            row = []
            if i < len(tariffs):
                row.append(InlineKeyboardButton(
                    Config.TARIFFS[tariffs[i]]['label'].split(' - ')[0], 
                    callback_data=f'tariff_{tariffs[i]}'
                ))
            if i + 1 < len(tariffs):
                row.append(InlineKeyboardButton(
                    Config.TARIFFS[tariffs[i+1]]['label'].split(' - ')[0], 
                    callback_data=f'tariff_{tariffs[i+1]}'
                ))
            keyboard.append(row)
        
        keyboard.append([InlineKeyboardButton("Для всех тарифов", callback_data='tariff_all')])
        keyboard.append([InlineKeyboardButton("❌ Отмена", callback_data='cancel_promocode')])
        
        await update.message.reply_text(
            text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='HTML'
        )
        
        return PROMO_TARIFF
        
    except ValueError:
        await update.message.reply_text("❌ Введите число. Попробуйте еще раз:")
        return PROMO_DISCOUNT_VALUE

async def process_tariff(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора тарифа"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'tariff_all':
        context.user_data['tariff'] = None
        tariff_text = "для всех тарифов"
    elif query.data.startswith('tariff_'):
        tariff = query.data.replace('tariff_', '')
        context.user_data['tariff'] = tariff
        tariff_text = f"для тарифа '{tariff}'"
    elif query.data == 'cancel_promocode':
        await query.message.edit_text("❌ Создание промокода отменено.")
        return ConversationHandler.END
    
    text = f"""✅ <b>Тариф сохранен:</b> {tariff_text}

Введите максимальное количество использований:
• Введите число (например, 10)
• Или введите 0 для неограниченного использования"""
    
    await query.message.edit_text(text, parse_mode='HTML')
    return PROMO_MAX_USES

async def process_max_uses(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка максимального количества использований"""
    max_uses_str = update.message.text.strip()
    
    try:
        max_uses = int(max_uses_str)
        if max_uses < 0:
            await update.message.reply_text("❌ Количество не может быть отрицательным. Попробуйте еще раз:")
            return PROMO_MAX_USES
        
        context.user_data['max_uses'] = max_uses
        
        text = f"""✅ <b>Максимальное использование сохранено:</b> {max_uses if max_uses > 0 else 'неограниченно'}

Введите дату окончания действия промокода:
• Формат: ДД.ММ.ГГГГ
• Пример: 31.12.2024
• Или введите 'нет' для бессрочного действия"""
        
        await update.message.reply_text(text, parse_mode='HTML')
        return PROMO_VALID_TO
        
    except ValueError:
        await update.message.reply_text("❌ Введите число. Попробуйте еще раз:")
        return PROMO_MAX_USES

async def process_valid_to(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка даты окончания действия"""
    date_str = update.message.text.strip().lower()
    
    if date_str == 'нет':
        context.user_data['valid_to'] = None
        valid_to_text = "бессрочно"
    else:
        try:
            # Пробуем разные форматы даты
            formats = ['%d.%m.%Y', '%d.%m.%y', '%Y-%m-%d']
            
            valid_to = None
            for fmt in formats:
                try:
                    valid_to = datetime.strptime(date_str, fmt)
                    break
                except ValueError:
                    continue
            
            if not valid_to:
                raise ValueError("Неправильный формат даты")
            
            # Устанавливаем время на конец дня
            valid_to = valid_to.replace(hour=23, minute=59, second=59)
            
            # Проверяем, что дата в будущем
            if valid_to < datetime.now():
                await update.message.reply_text("❌ Дата должна быть в будущем. Попробуйте еще раз:")
                return PROMO_VALID_TO
            
            context.user_data['valid_to'] = valid_to
            valid_to_text = valid_to.strftime('%d.%m.%Y')
            
        except Exception as e:
            logger.error(f"Ошибка при разборе даты: {e}")
            await update.message.reply_text("❌ Неправильный формат даты. Используйте ДД.ММ.ГГГГ или 'нет'. Попробуйте еще раз:")
            return PROMO_VALID_TO
    
    text = f"""✅ <b>Дата окончания сохранена:</b> {valid_to_text}

Введите описание промокода (необязательно):
• Можно оставить пустым
• Пример: 'Новогодняя акция 2024'"""
    
    await update.message.reply_text(text, parse_mode='HTML')
    return PROMO_DESCRIPTION

async def process_description_and_save(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка описания и сохранение промокода"""
    description = update.message.text.strip()
    
    # Получаем все данные
    code = context.user_data.get('promocode_code')
    discount_type = context.user_data.get('discount_type')
    discount_value = context.user_data.get('discount_value')
    tariff = context.user_data.get('tariff')
    max_uses = context.user_data.get('max_uses', 1)
    valid_to = context.user_data.get('valid_to')
    
    engine = context.bot_data.get('engine')
    if not engine:
        await update.message.reply_text("❌ Ошибка подключения к базе данных.")
        return ConversationHandler.END
    
    session = get_session(engine)
    
    try:
        # Создаем промокод
        promocode = Promocode(
            code=code,
            tariff=tariff,
            max_uses=max_uses if max_uses > 0 else None,  # 0 = неограниченно
            valid_to=valid_to,
            description=description if description else None,
            created_by=update.effective_user.id,
            is_active=True
        )
        
        # Устанавливаем скидку в зависимости от типа
        if discount_type == 'fixed':
            promocode.discount_amount = discount_value
        elif discount_type == 'percent':
            promocode.discount_percent = discount_value
        
        session.add(promocode)
        session.commit()
        
        # Формируем текст для отображения
        discount_text = f"{discount_value/100:.0f} ₽" if discount_type == 'fixed' else f"{discount_value}%"
        tariff_text = f"для всех тарифов" if not tariff else f"для тарифа '{tariff}'"
        uses_text = f"{max_uses} раз" if max_uses > 0 else "неограниченно"
        valid_text = valid_to.strftime('%d.%m.%Y') if valid_to else "бессрочно"
        
        text = f"""✅ <b>Промокод успешно создан!</b>

🎫 <b>Код:</b> <code>{code}</code>
💰 <b>Скидка:</b> {discount_text}
🏷️ <b>Действие:</b> {tariff_text}
📊 <b>Использований:</b> {uses_text}
📅 <b>Действует до:</b> {valid_text}
📝 <b>Описание:</b> {description or 'нет'}

🆔 <b>ID промокода:</b> {promocode.id}"""
        
        await update.message.reply_text(text, parse_mode='HTML')
        
        # Очищаем user_data
        context.user_data.clear()
        
    except Exception as e:
        logger.error(f"Ошибка при создании промокода: {e}")
        session.rollback()
        await update.message.reply_text("❌ Ошибка при создании промокода.")
    finally:
        session.close()
    
    return ConversationHandler.END

async def edit_promocode_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Меню редактирования промокодов (заглушка)"""
    query = update.callback_query
    await query.answer()
    
    text = """<b>✏️ Редактирование промокодов</b>

Функция редактирования промокодов находится в разработке.
Пока что вы можете:
1. Создать новый промокод
2. Удалить старый и создать новый"""
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Создать промокод", callback_data='create_promocode')],
        [InlineKeyboardButton("📋 Список промокодов", callback_data='list_promocodes')],
        [InlineKeyboardButton("◀️ Назад", callback_data='admin_promocodes')]
    ])
    
    await query.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

async def delete_promocode_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Меню удаления промокодов (заглушка)"""
    query = update.callback_query
    await query.answer()
    
    text = """<b>❌ Удаление промокодов</b>

Функция удаления промокодов находится в разработке.
Пока что промокоды можно только создавать."""
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Создать промокод", callback_data='create_promocode')],
        [InlineKeyboardButton("📋 Список промокодов", callback_data='list_promocodes')],
        [InlineKeyboardButton("◀️ Назад", callback_data='admin_promocodes')]
    ])
    
    await query.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

async def cancel_promocode_creation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отмена создания промокода"""
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.message.edit_text("❌ Создание промокода отменено.")
    else:
        await update.message.reply_text("❌ Создание промокода отменено.")
    
    # Очищаем user_data
    context.user_data.clear()
    
    return ConversationHandler.END

def get_promocodes_conversation_handler():
    """Создание ConversationHandler для управления промокодами"""
    return ConversationHandler(
        entry_points=[CallbackQueryHandler(start_create_promocode, pattern='^create_promocode$')],
        states={
            PROMO_CODE: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_promocode_code)],
            PROMO_DISCOUNT_TYPE: [CallbackQueryHandler(process_discount_type, pattern='^(discount_fixed|discount_percent|cancel_promocode)$')],
            PROMO_DISCOUNT_VALUE: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_discount_value)],
            PROMO_TARIFF: [CallbackQueryHandler(process_tariff, pattern='^(tariff_|tariff_all|cancel_promocode)')],
            PROMO_MAX_USES: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_max_uses)],
            PROMO_VALID_TO: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_valid_to)],
            PROMO_DESCRIPTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_description_and_save)],
        },
        fallbacks=[
            CommandHandler('cancel', cancel_promocode_creation),
            CallbackQueryHandler(cancel_promocode_creation, pattern='^cancel_promocode$')
        ],
        per_message=False
    )