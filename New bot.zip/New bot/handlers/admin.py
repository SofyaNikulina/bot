# handlers/admin.py
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from database import get_session, User, Payment, Subscription, Meeting, AdminLog, PromoUsage, Promocode
from keyboards import (
    get_admin_keyboard, 
    get_admin_reports_keyboard,
    get_meetings_management_keyboard,
    get_meetings_list_keyboard,
    get_meeting_selection_keyboard
)
from config import Config
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

def log_admin_action(session, admin_id: int, action: str, details: dict = None):
    """Логирование действий администратора"""
    try:
        log = AdminLog(
            admin_id=admin_id,
            action=action,
            details=details or {}
        )
        session.add(log)
        session.commit()
        logger.debug(f"Записано действие админа {admin_id}: {action}")
    except Exception as e:
        logger.error(f"Ошибка логирования действия админа: {e}")
        session.rollback()

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /admin"""
    user = update.effective_user
    
    logger.info(f"Команда /admin от пользователя {user.id} (@{user.username})")
    
    if user.id not in Config.ADMIN_IDS:
        logger.warning(f"Пользователь {user.id} попытался получить доступ к админ-панели")
        await update.message.reply_text("⛔ У вас нет прав администратора.")
        return
    
    text = """<b>🛠️ Панель администратора</b>

Выберите раздел для управления:"""
    
    await update.message.reply_text(
        text,
        reply_markup=get_admin_keyboard(),
        parse_mode='HTML'
    )

async def handle_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик админ-панели"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    
    logger.info(f"Админ {user.id} выбрал: {query.data}")
    
    if user.id not in Config.ADMIN_IDS:
        logger.warning(f"Пользователь {user.id} пытается получить доступ к админ-панели")
        await query.message.edit_text("⛔ У вас нет прав администратора.")
        return
    
    # Получаем engine из bot_data
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("❌ Engine не найден в bot_data!")
        await query.message.edit_text("❌ Ошибка подключения к базе данных.")
        return
    
    # Создаем сессию с правильным engine
    session = get_session(engine)
    
    try:
        if query.data == 'admin_stats':
            # Статистика
            total_users = session.query(User).count()
            active_users = session.query(User).filter(User.is_active == True).count()
            subscribed_users = session.query(Subscription).filter(Subscription.is_active == True).count()
            
            # Платежи
            payments = session.query(Payment).filter(Payment.status == 'completed').all()
            total_revenue = sum(p.amount for p in payments) / 100 if payments else 0
            
            # Тарифы
            tariffs_count = {}
            all_tariffs = ['creative', '1_month', '3_months', '12_months']
            for tariff in all_tariffs:
                count = session.query(Subscription).filter(
                    Subscription.tariff == tariff,
                    Subscription.is_active == True
                ).count()
                tariffs_count[tariff] = count
            
            # Активные встречи
            upcoming_meetings = session.query(Meeting).filter(
                Meeting.date_time >= datetime.now(),
                Meeting.is_active == True
            ).count()
            
            text = f"""<b>📊 Статистика клуба «Бестужевки»</b>

<b>👥 Пользователи:</b>
• Всего: {total_users}
• Активных: {active_users}
• С подпиской: {subscribed_users}

<b>💰 Финансы:</b>
• Общая выручка: {total_revenue:,.0f} ₽
• Средний чек: {total_revenue/len(payments) if payments else 0:,.0f} ₽

<b>📈 Тарифы:</b>
• Творческий: {tariffs_count.get('creative', 0)}
• 1 месяц: {tariffs_count.get('1_month', 0)}
• 3 месяца: {tariffs_count.get('3_months', 0)}
• 12 месяцев: {tariffs_count.get('12_months', 0)}

<b>📅 Встречи:</b>
• Предстоящих встреч: {upcoming_meetings}

<b>🔄 За сегодня:</b>
• Новые пользователи: {session.query(User).filter(User.joined_at >= datetime.now().date()).count()}
• Новые оплаты: {session.query(Payment).filter(Payment.created_at >= datetime.now().date(), Payment.status == 'completed').count()}
• Новые встречи: {session.query(Meeting).filter(Meeting.created_at >= datetime.now().date()).count()}"""
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_stats', {
                'total_users': total_users,
                'total_revenue': total_revenue
            })
        
        elif query.data == 'admin_users':
            # Последние 10 пользователей
            users = session.query(User).order_by(User.joined_at.desc()).limit(10).all()
            
            text = "<b>👥 Последние пользователи:</b>\n\n"
            
            for i, db_user in enumerate(users, 1):
                has_subscription = session.query(Subscription).filter(
                    Subscription.user_id == db_user.id,
                    Subscription.is_active == True
                ).first() is not None
                
                user_name = f"{db_user.first_name or ''} {db_user.last_name or ''}".strip()
                if not user_name:
                    user_name = "Без имени"
                
                text += f"{i}. <b>{user_name}</b>\n"
                text += f"   👤 @{db_user.username or 'нет'}\n"
                text += f"   📱 {db_user.phone_number or 'нет'}\n"
                text += f"   📅 {db_user.joined_at.strftime('%d.%m.%Y')}\n"
                text += f"   💎 Подписка: {'✅ да' if has_subscription else '❌ нет'}\n\n"
            
            if len(users) == 10:
                text += "ℹ️ Показаны последние 10 пользователей"
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_users')
        
        elif query.data == 'admin_payments':
            # Последние 10 платежей
            payments = session.query(Payment).filter(Payment.status == 'completed').order_by(Payment.completed_at.desc()).limit(10).all()
            
            text = "<b>💰 Последние платежи:</b>\n\n"
            
            for i, payment in enumerate(payments, 1):
                payment_user = payment.user
                user_name = f"{payment_user.first_name or ''} {payment_user.last_name or ''}".strip()
                if not user_name:
                    user_name = "Без имени"
                
                text += f"{i}. <b>{user_name}</b>\n"
                text += f"   💳 {payment.amount/100:,.0f} ₽\n"
                text += f"   📅 {payment.completed_at.strftime('%d.%m.%Y %H:%M') if payment.completed_at else 'нет даты'}\n"
                text += f"   🏷️ {payment.tariff or 'не указан'}\n"
                if payment.promocode:
                    text += f"   🎫 {payment.promocode}\n"
                text += "\n"
            
            if len(payments) == 10:
                text += "ℹ️ Показаны последние 10 платежей"
            elif not payments:
                text += "ℹ️ Платежей еще нет"
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_payments', {
                'count': len(payments)
            })
        
        elif query.data == 'admin_meetings':
            # Управление встречами
            total_meetings = session.query(Meeting).count()
            upcoming_meetings = session.query(Meeting).filter(
                Meeting.date_time >= datetime.now()
            ).count()
            past_meetings = session.query(Meeting).filter(
                Meeting.date_time < datetime.now()
            ).count()
            
            text = f"""<b>📅 Управление встречами</b>

📊 Статистика:
• Всего встреч: {total_meetings}
• Предстоящих: {upcoming_meetings}
• Прошедших: {past_meetings}

Выберите действие:"""
            
            await query.message.edit_text(
                text,
                reply_markup=get_meetings_management_keyboard(),
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_meetings_management')
        
        elif query.data == 'admin_reports':
            # Раздел отчетов - используем универсальную обработку через reports.py
            from keyboards import get_admin_reports_keyboard
            
            text = "<b>📊 Отчеты и аналитика</b>\n\nВыберите тип отчета:"
            
            await query.message.edit_text(
                text,
                reply_markup=get_admin_reports_keyboard(),
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_reports')
        
        elif query.data == 'admin_promocodes':
            # Управление промокодами
            try:
                from handlers.admin_promocodes import manage_promocodes
                await manage_promocodes(update, context)
            except ImportError as e:
                logger.error(f"Не удалось импортировать manage_promocodes: {e}")
                # Показываем промокоды из базы данных
                promocodes = session.query(Promocode).order_by(Promocode.created_at.desc()).limit(10).all()
                
                text = """<b>🎫 Управление промокодами</b>

<b>Последние промокоды:</b>\n"""
                
                if promocodes:
                    for i, promo in enumerate(promocodes, 1):
                        status = "✅" if promo.is_active else "❌"
                        valid_to = f"до {promo.valid_to.strftime('%d.%m.%Y')}" if promo.valid_to else "без срока"
                        uses = f"{promo.used_count}/{promo.max_uses}"
                        
                        text += f"{i}. {status} <code>{promo.code}</code>\n"
                        text += f"   Скидка: {promo.discount_amount/100 if promo.discount_amount else promo.discount_percent}{'₽' if promo.discount_amount else '%'}\n"
                        text += f"   Использовано: {uses}\n"
                        text += f"   {valid_to}\n\n"
                else:
                    text += "ℹ️ Промокодов пока нет\n\n"
                
                text += "<b>Создать новый промокод:</b>\n"
                text += "Используйте команду <code>/create_promo КОД СУММА</code>\n"
                text += "Пример: <code>/create_promo SUMMER2024 500</code>\n\n"
                text += "Для полного управления промокодами используйте панель."
                
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("📝 Создать промокод", callback_data='create_promocode')],
                    [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
                ])
                
                await query.message.edit_text(
                    text,
                    reply_markup=keyboard,
                    parse_mode='HTML'
                )
            
            log_admin_action(session, user.id, 'viewed_promocodes')
        
        elif query.data == 'admin_broadcast':
            # Рассылка
            total_users = session.query(User).count()
            active_users = session.query(User).filter(User.is_active == True).count()
            subscribed_users = session.query(Subscription).filter(Subscription.is_active == True).count()
            
            text = f"""<b>📢 Рассылка сообщений</b>

👥 Аудитория для рассылки:
• Всего пользователей: {total_users}
• Активных пользователей: {active_users}
• С подпиской: {subscribed_users}

<b>Способы рассылки:</b>

1. <b>Всем пользователям:</b>
<code>/broadcast_all Текст сообщения</code>

2. <b>Только с подпиской:</b>
<code>/broadcast_subscribed Текст сообщения</code>

3. <b>Только активным:</b>
<code>/broadcast_active Текст сообщения</code>

4. <b>По ID пользователей:</b>
<code>/broadcast_ids 123,456,789 Текст сообщения</code>

<b>Пример:</b>
<code>/broadcast_all Привет! Напоминаем о встрече завтра в 19:00.</code>"""
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_broadcast')
        
        elif query.data == 'admin_faq':
            # Управление FAQ
            text = "<b>❓ Управление FAQ</b>\n\n"
            text += "<b>Текущие вопросы FAQ:</b>\n"
            
            faq_items = [
                ("Как часто выходят лекции?", "faq_frequency"),
                ("Где проходит обучение?", "faq_platform"),
                ("Где посмотреть программу?", "faq_program"),
                ("Можно ли смотреть в записи?", "faq_recording"),
                ("Будут ли домашние задания?", "faq_homework"),
                ("Когда можно присоединиться?", "faq_join_time"),
                ("Можно ли вернуть деньги?", "faq_refund"),
                ("Можно ли оплатить в рассрочку?", "faq_installment"),
                ("Как получить бонусы?", "faq_bonuses")
            ]
            
            for question, callback in faq_items:
                text += f"• {question}\n"
            
            text += "\n<b>Для редактирования FAQ:</b>\n"
            text += "1. Измените файл <code>handlers/faq.py</code>\n"
            text += "2. Обновите клавиатуру в <code>keyboards.py</code>\n"
            text += "3. Перезапустите бота"
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_faq_management')
        
        elif query.data == 'admin_metrics':
            # Метрики
            week_ago = datetime.now() - timedelta(days=7)
            
            new_users = session.query(User).filter(User.joined_at >= week_ago).count()
            completed_payments = session.query(Payment).filter(
                Payment.created_at >= week_ago,
                Payment.status == 'completed'
            ).count()
            revenue_7_days = sum(p.amount for p in session.query(Payment).filter(
                Payment.created_at >= week_ago,
                Payment.status == 'completed'
            ).all()) / 100 if completed_payments else 0
            
            # Конверсия
            all_users_week = session.query(User).filter(User.joined_at >= week_ago).count()
            paid_users_week = session.query(User).join(Payment).filter(
                Payment.created_at >= week_ago,
                Payment.status == 'completed',
                User.joined_at >= week_ago
            ).distinct().count()
            
            conversion_rate = (paid_users_week / max(all_users_week, 1)) * 100
            
            text = f"""<b>📈 Метрики и аналитика</b>

📅 <b>За последние 7 дней:</b>
• Новых пользователей: {new_users}
• Оплат: {completed_payments}
• Выручка: {revenue_7_days:,.0f} ₽
• Конверсия: {conversion_rate:.1f}%

📊 <b>Детальная аналитика:</b>
Подробные метрики доступны в еженедельных отчетах.
Используйте раздел 'Отчеты' для получения детальной статистики.

🔍 <b>Дополнительные метрики:</b>
• Среднее время до первой оплаты
• Удержание пользователей
• Популярность тарифов
• Эффективность промокодов"""
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("◀️ Назад в админку", callback_data='admin_back')]
            ])
            
            await query.message.edit_text(
                text,
                reply_markup=keyboard,
                parse_mode='HTML'
            )
            
            log_admin_action(session, user.id, 'viewed_metrics', {
                'new_users_7d': new_users,
                'revenue_7d': revenue_7_days,
                'conversion_rate': conversion_rate
            })
        
        elif query.data == 'admin_back':
            # Возврат в админ-панель
            text = "<b>🛠️ Панель администратора</b>\n\nВыберите раздел:"
            
            await query.message.edit_text(
                text,
                reply_markup=get_admin_keyboard(),
                parse_mode='HTML'
            )
        
        elif query.data.startswith('edit_meeting_menu') or query.data.startswith('delete_meeting_menu'):
            # Меню для редактирования/удаления встреч
            meetings = session.query(Meeting).order_by(Meeting.date_time).all()
            
            if not meetings:
                await query.message.edit_text(
                    "❌ Нет встреч для редактирования/удаления.",
                    reply_markup=get_meetings_list_keyboard()
                )
                return
            
            action = "редактирования" if "edit" in query.data else "удаления"
            
            text = f"<b>📋 Выберите встречу для {action}:</b>\n\n"
            
            await query.message.edit_text(
                text,
                reply_markup=get_meeting_selection_keyboard(
                    meetings, 
                    action_prefix='edit_' if "edit" in query.data else 'delete_'
                ),
                parse_mode='HTML'
            )
        
        elif query.data.startswith('edit_'):
            # Редактирование конкретной встречи
            try:
                meeting_id = int(query.data.split('_')[1])
                meeting = session.query(Meeting).filter_by(id=meeting_id).first()
                
                if not meeting:
                    await query.message.edit_text("❌ Встреча не найдена.")
                    return
                
                from keyboards import get_meeting_detail_keyboard
                
                text = f"""<b>📅 Детали встречи:</b>

🏷️ <b>Название:</b> {meeting.title}
📅 <b>Дата и время:</b> {meeting.date_time.strftime('%d.%m.%Y %H:%M')}
⏱️ <b>Продолжительность:</b> {meeting.duration} мин
📝 <b>Описание:</b> {meeting.description or 'нет'}
🔗 <b>Zoom ссылка:</b> {'✅ есть' if meeting.zoom_link else '❌ нет'}
📊 <b>Статус:</b> {'✅ активна' if meeting.is_active else '⏸️ неактивна'}

🆔 <b>ID встречи:</b> {meeting.id}"""
                
                await query.message.edit_text(
                    text,
                    reply_markup=get_meeting_detail_keyboard(meeting_id),
                    parse_mode='HTML'
                )
                
                log_admin_action(session, user.id, 'viewed_meeting_details', {
                    'meeting_id': meeting_id,
                    'meeting_title': meeting.title
                })
                
            except (ValueError, IndexError) as e:
                logger.error(f"Ошибка при разборе meeting_id: {e}")
                await query.message.edit_text("❌ Ошибка при обработке запроса.")
        
        elif query.data.startswith('add_zoom_'):
            # Добавление Zoom ссылки
            try:
                meeting_id = int(query.data.split('_')[2])
                meeting = session.query(Meeting).filter_by(id=meeting_id).first()
                
                if not meeting:
                    await query.message.edit_text("❌ Встреча не найдена.")
                    return
                
                from keyboards import get_cancel_keyboard
                
                text = f"""<b>🔗 Добавление Zoom ссылки</b>

Для встречи: <b>{meeting.title}</b>
Дата: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}

Отправьте Zoom ссылку в следующем сообщении.

<b>Формат:</b>
https://zoom.us/j/1234567890
или
https://us04web.zoom.us/j/1234567890

<b>Пароль (если есть) можно добавить отдельно.</b>"""
                
                # Сохраняем ID встречи в user_data для обработки в следующем сообщении
                context.user_data['adding_zoom_to'] = meeting_id
                
                await query.message.edit_text(
                    text,
                    reply_markup=get_cancel_keyboard('meetings_list'),
                    parse_mode='HTML'
                )
                
                log_admin_action(session, user.id, 'started_adding_zoom', {
                    'meeting_id': meeting_id
                })
                
            except (ValueError, IndexError) as e:
                logger.error(f"Ошибка при разборе meeting_id для Zoom: {e}")
                await query.message.edit_text("❌ Ошибка при обработке запроса.")
        
        elif query.data == 'create_promocode':
            # Создание промокода
            from handlers.admin_promocodes import create_promocode
            await create_promocode(update, context)
        
        # Все обработчики отчетов теперь полностью перенаправляются в reports.py
        # через глобальный обработчик в bot.py
    
    except Exception as e:
        logger.error(f"Ошибка в админ-панели: {e}", exc_info=True)
        await query.message.edit_text(
            "❌ Произошла ошибка при обработке запроса.",
            parse_mode='HTML'
        )
    finally:
        session.close()