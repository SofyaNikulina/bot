# handlers/utils.py
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
from database import get_session, User, Meeting, Promocode
from keyboards import get_payment_keyboard, get_back_keyboard, get_main_menu_keyboard
from config import Config
import logging
from datetime import datetime
import re

logger = logging.getLogger(__name__)

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик текстовых сообщений (НЕ обрабатывает команды)"""
    user = update.effective_user
    text = update.message.text.strip() if update.message.text else ""
    
    logger.debug(f"🔍 HANDLE_TEXT_MESSAGE вызван для пользователя {user.id}")
    logger.debug(f"  Текст: '{text}'")
    
    # Если это команда (начинается с /) - передаем обработку другим обработчикам
    if text.startswith('/'):
        logger.debug(f"📤 Команда {text} - пропускаем, так как она обрабатывается CommandHandler")
        return
    
    # Проверяем, не добавляет ли админ Zoom ссылку
    if user.id in Config.ADMIN_IDS and 'adding_zoom_to' in context.user_data:
        logger.info(f"  Админ {user.id} добавляет Zoom ссылку, обрабатываем отдельно")
        await handle_zoom_link(update, context)
        return
    
    # === ПРОВЕРКА ПРОМОКОДА ===
    # Обработка промокода - проверяем, что это ожидание промокода
    is_awaiting_promocode = context.user_data.get('awaiting_promocode', False)
    logger.debug(f"  Флаг is_awaiting_promocode: {is_awaiting_promocode}")
    
    if is_awaiting_promocode and text:
        logger.info(f"✅ Пользователь {user.id} ожидает промокод, обрабатываем как промокод: '{text}'")
        engine = context.bot_data.get('engine')
        if not engine:
            logger.error("Engine not found in bot_data")
            await update.message.reply_text("❌ Техническая ошибка, попробуйте позже.")
            # Очищаем флаг при ошибке
            context.user_data.pop('awaiting_promocode', None)
            return
        
        session = get_session(engine)
        try:
            await process_promocode_input(update, context, text, session)
            logger.info(f"✅ Промокод обработан")
            # ВАЖНО: Удаляем флаг после обработки
            context.user_data.pop('awaiting_promocode', None)
            logger.debug(f"  awaiting_promocode удален из user_data")
            return
        except Exception as e:
            logger.error(f"❌ Ошибка обработки промокода: {e}", exc_info=True)
            await update.message.reply_text(
                "❌ Ошибка при обработке промокода. Попробуйте еще раз.",
                parse_mode='Markdown',
                reply_markup=get_back_keyboard('tariff_selection')
            )
            # Очищаем флаг даже при ошибке
            context.user_data.pop('awaiting_promocode', None)
            return
        finally:
            session.close()
    
    # Если флаг awaiting_promocode был установлен, но текст пустой
    if is_awaiting_promocode and not text:
        logger.debug(f"ℹ️  awaiting_promocode был установлен, но текст пустой, очищаем флаг")
        context.user_data.pop('awaiting_promocode', None)
        await update.message.reply_text(
            "❌ Вы отправили пустое сообщение. Промокод должен содержать текст.",
            parse_mode='Markdown',
            reply_markup=get_back_keyboard('tariff_selection')
        )
        return
    
    # Если это обычное текстовое сообщение (не промокод, не команда)
    logger.debug(f"📤 Обычное текстовое сообщение от {user.id}, передаем в forward_user_message")
    
    # Передаем обработку в forward_user_message
    try:
        from handlers.messages import forward_user_message
        await forward_user_message(update, context)
    except Exception as e:
        logger.error(f"❌ Ошибка при передаче в forward_user_message: {e}")

async def handle_start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /start - с кнопкой поделиться контактом"""
    user = update.effective_user
    
    logger.info(f"🚀 Команда /start от пользователя {user.id} (@{user.username})")
    
    # Проверяем, есть ли пользователь в базе
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        await update.message.reply_text("❌ Техническая ошибка, попробуйте позже.")
        return
    
    session = get_session(engine)
    
    try:
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        
        if db_user and db_user.phone_number:
            # Пользователь уже зарегистрирован
            logger.info(f"📝 Пользователь {user.id} уже зарегистрирован")
            
            welcome_text = f"""👋 С возвращением, {user.first_name or 'друг'}!

🤖 **Бот «Бестужевки»** готов помочь вам с:
• 🎯 Выбором подходящего тарифа
• 💰 Оплатой и промокодами
• 📅 Расписанием встреч
• 📞 Связью с менеджерами

Выберите раздел в меню или напишите ваш вопрос!"""
            
            # ИСПРАВЛЕНО: Используем функцию get_main_menu_keyboard с параметром is_admin
            keyboard = get_main_menu_keyboard(is_admin=(user.id in Config.ADMIN_IDS))
            
            await update.message.reply_text(
                welcome_text,
                parse_mode='Markdown',
                reply_markup=keyboard
            )
            
        else:
            # Пользователь не зарегистрирован - просим поделиться контактом
            logger.info(f"📱 Пользователь {user.id} не зарегистрирован, запрашиваем контакт")
            
            welcome_text = f"""👋 Привет, {user.first_name or 'друг'}!

🤖 Добро пожаловать в **Бот «Бестужевки»**!

📲 Для начала работы нам нужен ваш номер телефона, чтобы:
• ✅ Завершить регистрацию
• 📞 Связаться с вами при необходимости
• 💰 Создать личный кабинет

👇 **Нажмите кнопку ниже, чтобы поделиться контактом:**"""
            
            # ИСПРАВЛЕНО: Упрощенная и правильная клавиатура с кнопкой контакта
            keyboard = ReplyKeyboardMarkup(
                [[KeyboardButton("📱 Поделиться контактом", request_contact=True)]],
                resize_keyboard=True,
                one_time_keyboard=True
            )
            
            await update.message.reply_text(
                welcome_text,
                parse_mode='Markdown',
                reply_markup=keyboard
            )
            
            # Сохраняем информацию о пользователе если его нет в БД
            if not db_user:
                logger.info(f"📝 Создаем запись пользователя {user.id} в БД")
                db_user = User(
                    telegram_id=user.id,
                    username=user.username,
                    first_name=user.first_name,
                    last_name=user.last_name,
                    settings={
                        'reminders': True,
                        'notifications': True,
                        'timezone': 'Europe/Moscow'
                    }
                )
                session.add(db_user)
                session.commit()
                logger.info(f"✅ Пользователь {user.id} добавлен в БД (без телефона)")
    
    except Exception as e:
        logger.error(f"❌ Ошибка при обработке /start: {e}", exc_info=True)
        # При ошибке все равно показываем сообщение, но без клавиатуры
        await update.message.reply_text(
            f"""❌ Произошла ошибка. Попробуйте еще раз.

👋 Добро пожаловать в **Бот «Бестужевки»**!

Пожалуйста, отправьте нам ваш номер телефона для регистрации.""",
            parse_mode='Markdown'
        )
        session.rollback()
    finally:
        session.close()

async def process_promocode_input(update: Update, context: ContextTypes.DEFAULT_TYPE, promocode_text: str, session):
    """Обработка ввода промокода"""
    try:
        promocode_text = promocode_text.upper().strip()
        logger.info(f"🔍 Обработка промокода: '{promocode_text}' для пользователя {update.effective_user.id}")
        
        # ИЩЕМ ПРОМОКОД В БАЗЕ ДАННЫХ
        promo = session.query(Promocode).filter_by(code=promocode_text, is_active=True).first()
        
        if not promo:
            logger.warning(f"❌ Промокод не найден в БД: {promocode_text}")
            await update.message.reply_text(
                "❌ Промокод не найден или неактивен.",
                parse_mode='Markdown',
                reply_markup=get_back_keyboard('tariff_selection')
            )
            return
        
        logger.info(f"✅ Найден промокод в БД: {promocode_text} (ID: {promo.id})")
        logger.info(f"  Данные промокода: discount_amount={promo.discount_amount}, discount_percent={promo.discount_percent}, tariff={promo.tariff}")
        
        # Проверяем срок действия
        now = datetime.now()
        if promo.valid_to and promo.valid_to < now:
            logger.warning(f"❌ Промокод просрочен: {promocode_text}, valid_to={promo.valid_to}")
            await update.message.reply_text(
                "❌ Промокод просрочен.",
                parse_mode='Markdown',
                reply_markup=get_back_keyboard('tariff_selection')
            )
            return
        
        # Проверяем лимит использований
        if promo.max_uses and promo.used_count >= promo.max_uses:
            logger.warning(f"❌ Промокод достиг лимита: {promocode_text}, used={promo.used_count}/{promo.max_uses}")
            await update.message.reply_text(
                "❌ Промокод уже использован максимальное количество раз.",
                parse_mode='Markdown',
                reply_markup=get_back_keyboard('tariff_selection')
            )
            return
        
        # Проверяем тариф (если указан)
        selected_tariff = context.user_data.get('selected_tariff')
        if selected_tariff:
            logger.info(f"  Выбран тариф: {selected_tariff}")
            if promo.tariff and promo.tariff != selected_tariff:
                tariff_name = Config.TARIFFS.get(selected_tariff, {}).get('label', selected_tariff)
                promo_tariff_name = Config.TARIFFS.get(promo.tariff, {}).get('label', promo.tariff)
                
                logger.warning(f"❌ Промокод для другого тарифа: {promo.tariff} != {selected_tariff}")
                await update.message.reply_text(
                    f"❌ Этот промокод действует только для тарифа **{promo_tariff_name}**.\n\nВы выбрали: {tariff_name}",
                    parse_mode='Markdown',
                    reply_markup=get_back_keyboard('tariff_selection')
                )
                return
        else:
            # Если тариф не выбран, но промокод привязан к тарифу
            if promo.tariff:
                promo_tariff_name = Config.TARIFFS.get(promo.tariff, {}).get('label', promo.tariff)
                logger.warning(f"❌ Промокод привязан к тарифу, но тариф не выбран: {promo.tariff}")
                await update.message.reply_text(
                    f"❌ Этот промокод действует только для тарифа **{promo_tariff_name}**.\n\nСначала выберите тариф.",
                    parse_mode='Markdown',
                    reply_markup=get_back_keyboard('tariffs')
                )
                return
        
        # Промокод валиден - сохраняем данные
        context.user_data['applied_promocode'] = promocode_text
        context.user_data['promocode_data'] = {
            'id': promo.id,
            'discount_amount': promo.discount_amount,
            'discount_percent': promo.discount_percent,
            'code': promo.code,
            'tariff': promo.tariff
        }
        
        logger.info(f"✅ Промокод сохранен в user_data: {promocode_text}")
        
        # Если есть выбранный тариф, показываем расчет скидки
        if selected_tariff:
            tariff_info = Config.TARIFFS.get(selected_tariff, {})
            original_price = tariff_info.get('price', 0) / 100  # В рублях
            
            # Рассчитываем скидку
            discount = 0
            discount_text = ""
            discount_type = ""
            
            if promo.discount_amount > 0:
                discount = promo.discount_amount / 100  # Переводим в рубли
                discount_text = f"{discount:,.0f} ₽"
                discount_type = "фиксированная сумма"
            elif promo.discount_percent > 0:
                discount = original_price * (promo.discount_percent / 100)
                discount_text = f"{promo.discount_percent}% ({discount:,.0f} ₽)"
                discount_type = "процентная скидка"
            
            final_price = max(0, original_price - discount)
            
            # Форматируем текст ответа
            if discount > 0:
                text_response = f"""✅ **Промокод применен!**

🏷️ **Тариф:** {tariff_info.get('label', '')}
💰 **Исходная цена:** {original_price:,.0f} ₽
🎫 **Скидка ({discount_type}):** {discount_text}
💳 **Итоговая цена:** {final_price:,.0f} ₽

Промокод: `{promocode_text}`"""
            else:
                text_response = f"""ℹ️ **Промокод применен**

🏷️ **Тариф:** {tariff_info.get('label', '')}
💰 **Цена:** {original_price:,.0f} ₽
🎫 **Промокод:** `{promocode_text}` (без скидки)

Перейдите к оплате:"""
            
            await update.message.reply_text(
                text_response,
                parse_mode='Markdown',
                reply_markup=get_payment_keyboard(selected_tariff, promocode_applied=True, promocode=promocode_text)
            )
            
            logger.info(f"✅ Промокод применен к тарифу {selected_tariff}: {promocode_text}, скидка: {discount} руб, итого: {final_price} руб")
        else:
            # Если тариф не выбран, просто подтверждаем промокод
            text_response = f"""✅ **Промокод найден и готов к применению!**

Код: `{promocode_text}`

Теперь выберите тариф, чтобы применить промокод."""
            
            keyboard = get_back_keyboard('tariffs')
            
            await update.message.reply_text(
                text_response,
                parse_mode='Markdown',
                reply_markup=keyboard
            )
            logger.info(f"✅ Промокод сохранен для будущего применения: {promocode_text}")
        
    except Exception as e:
        logger.error(f"❌ Ошибка обработки промокода: {e}", exc_info=True)
        await update.message.reply_text(
            "❌ Произошла ошибка при обработке промокода. Попробуйте еще раз.",
            parse_mode='Markdown',
            reply_markup=get_back_keyboard('tariff_selection')
        )
        raise

async def handle_zoom_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка Zoom ссылки от админа"""
    user = update.effective_user
    
    if user.id not in Config.ADMIN_IDS or 'adding_zoom_to' not in context.user_data:
        # Не админ или не добавляет Zoom - пропускаем
        logger.info(f"❌ Не админ или не добавляет Zoom: user={user.id}, adding_zoom_to={context.user_data.get('adding_zoom_to')}")
        # Передаем обработку дальше
        await forward_user_message(update, context)
        return
    
    meeting_id = context.user_data['adding_zoom_to']
    zoom_link = update.message.text.strip()
    
    # Проверяем, что ссылка валидная
    if not (zoom_link.startswith('http://') or zoom_link.startswith('https://')):
        zoom_link = f"https://{zoom_link}"
    
    # Проверяем, что это Zoom ссылка
    if 'zoom.us' not in zoom_link and 'zoom.com' not in zoom_link:
        await update.message.reply_text(
            "❌ Это не похоже на Zoom ссылку. Отправьте ссылку формата:\n"
            "https://zoom.us/j/1234567890\n"
            "или\n"
            "https://us04web.zoom.us/j/1234567890"
        )
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        meeting = session.query(Meeting).filter_by(id=meeting_id).first()
        if meeting:
            meeting.zoom_link = zoom_link
            meeting.updated_at = datetime.now()
            session.commit()
            
            await update.message.reply_text(
                f"✅ Zoom ссылка добавлена для встречи:\n\n"
                f"**{meeting.title}**\n"
                f"Дата: {meeting.date_time.strftime('%d.%m.%Y %H:%M')}\n\n"
                f"Ссылка: {zoom_link}",
                parse_mode='Markdown'
            )
            logger.info(f"✅ Zoom ссылка добавлена для встречи {meeting_id}: {meeting.title}")
        else:
            await update.message.reply_text("❌ Встреча не найдена.")
    
    except Exception as e:
        logger.error(f"❌ Ошибка добавления Zoom ссылки: {e}")
        session.rollback()
        await update.message.reply_text("❌ Ошибка при сохранении Zoom ссылки.")
    finally:
        session.close()
        # Очищаем контекст независимо от результата
        if 'adding_zoom_to' in context.user_data:
            del context.user_data['adding_zoom_to']

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /help"""
    help_text = """🤖 **Помощь по боту «Бестужевки»**

**Основные команды:**
/start - Начать работу с ботом
/help - Показать это сообщение
/admin - Панель администратора (только для администраторов)

**Как применить промокод:**
1. Выберите тариф в разделе "💰 Тарифы"
2. Нажмите кнопку "🎫 Ввести промокод"
3. Введите ваш промокод
4. Увидите новую цену со скидкой

**Для помощи обращайтесь к менеджеру через меню.**"""
    
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def handle_unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик неизвестных команд"""
    command = update.message.text.split()[0] if update.message.text else ""
    
    # Известные команды, которые обрабатываются другими обработчиками
    known_commands = [
        '/start', '/admin', '/help', '/messages',
        '/broadcast_all', '/broadcast_subscribed', '/broadcast_active', '/broadcast_ids',
        '/add_meeting'
    ]
    
    if command in known_commands:
        # Эта команда уже должна была быть обработана в группе 0
        logger.debug(f"Известная команда попала в handle_unknown_command: {command}")
        return
    
    if command.startswith('/'):
        await update.message.reply_text(
            f"🤔 Команда `{command}` не найдена. Используйте /help для справки.",
            parse_mode='Markdown'
        )
        logger.info(f"Неизвестная команда от {update.effective_user.id}: {command}")

async def forward_user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Функция-заглушка, если реальная функция не импортирована"""
    logger.info(f"ℹ️  forward_user_message вызвана для пользователя {update.effective_user.id}")
    # Можно добавить базовую логику или оставить пустой
    pass