from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
from database import get_session, User
from keyboards import get_privacy_keyboard, get_main_menu_keyboard
from config import Config
import logging
import json

logger = logging.getLogger(__name__)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /start"""
    user = update.effective_user
    
    # Получаем engine из контекста
    engine = context.bot_data.get('engine')
    if not engine:
        logger.error("Engine not found in bot_data")
        return
    
    session = get_session(engine)
    
    try:
        # Проверяем, есть ли пользователь в базе
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        
        if not db_user:
            # КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: Инициализируем настройки при создании пользователя
            db_user = User(
                telegram_id=user.id,
                username=user.username,
                first_name=user.first_name,
                last_name=user.last_name,
                joined_at=update.message.date,
                # Инициализируем настройки по умолчанию
                settings={
                    'reminders': True,      # Получать напоминания о встречах
                    'notifications': True,  # Получать уведомления
                    'timezone': 'Europe/Moscow'  # Часовой пояс по умолчанию
                }
            )
            session.add(db_user)
            session.commit()
            logger.info(f"Новый пользователь: {user.id} - @{user.username}")
            logger.debug(f"Настройки инициализированы: {db_user.settings}")
        else:
            # Если пользователь уже существует, проверяем наличие настроек
            if not db_user.settings:
                db_user.settings = {
                    'reminders': True,
                    'notifications': True,
                    'timezone': 'Europe/Moscow'
                }
                session.commit()
                logger.info(f"Настройки добавлены существующему пользователю: {user.id}")
        
        # Отправляем фото с приветственным сообщением
        welcome_text = """Привет! Это чат-бот клуба «Бестужевки» 💙

Пространство для тех, кому важно не просто знать, а чувствовать и понимать: историю, искусство, философию и культуру общения.

Прежде чем продолжить 🤍

Пожалуйста, подтвердите согласие с Политикой конфиденциальности и оставьте номер телефона — он нужен только для связи по клубу «Бестужевки» и никогда не будет использован для спама."""
        
        # Ссылка на фото 
        photo_url = "https://s6.iimage.su/s/17/uPtHeMRx2hKC14TCDcf6Id6rBB6r41KOXOsi6NfF.jpg"  
        
        try:
            # Пытаемся отправить фото с текстом
            await update.message.reply_photo(
                photo=photo_url,
                caption=welcome_text,
                reply_markup=get_privacy_keyboard(),
                parse_mode='Markdown'
            )
        except Exception as photo_error:
            logger.warning(f"Не удалось отправить фото: {photo_error}. Отправляем только текст.")
            # Если не удалось отправить фото, отправляем только текст
            await update.message.reply_text(
                welcome_text,
                reply_markup=get_privacy_keyboard(),
                parse_mode='Markdown'
            )
        
        # Обновляем время последней активности
        db_user.last_activity = update.message.date
        session.commit()
        
    except Exception as e:
        logger.error(f"Ошибка в start_command: {e}")
        session.rollback()
    finally:
        session.close()

# Остальной код остается без изменений...
async def handle_privacy_policy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик согласия с политикой"""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    engine = context.bot_data.get('engine')
    
    if not engine:
        return
    
    session = get_session(engine)
    
    try:
        # Находим пользователя
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if not db_user:
            await query.message.reply_text("Пожалуйста, начните с команды /start")
            return
        
        if query.data == 'agree_policy':
            # Пользователь согласился с политикой
            db_user.agreed_to_policy = True
            db_user.agreed_at = query.message.date
            
            # Убеждаемся, что настройки установлены
            if not db_user.settings:
                db_user.settings = {
                    'reminders': True,
                    'notifications': True,
                    'timezone': 'Europe/Moscow'
                }
            
            # Обновляем текст исходного сообщения
            await query.message.edit_text(
                "Спасибо за доверие! 🤍\n\nНажмите кнопку ниже, чтобы поделиться номером телефона.",
                reply_markup=None  # Убираем инлайн-кнопки!
            )
            
            # Создаем ReplyKeyboardMarkup для запроса телефона
            phone_keyboard = ReplyKeyboardMarkup(
                [[KeyboardButton("📱 Поделиться номером", request_contact=True)]],
                resize_keyboard=True,
                one_time_keyboard=True
            )
            
            # Отправляем новое сообщение с кнопкой для телефона
            phone_text = """Теперь, пожалуйста, поделитесь своим номером телефона, нажав кнопку ниже.

Это нужно для:
• Связи по вопросам клуба
• Напоминаний о встречах
• Доступа к материалам

Ваши данные защищены и не будут переданы третьим лицам."""
            
            await query.message.reply_text(
                phone_text,
                reply_markup=phone_keyboard  # Используем созданную клавиатуру
            )
            
            # Устанавливаем состояние ожидания телефона
            context.user_data['awaiting_phone'] = True
            
        session.commit()
        
    except Exception as e:
        logger.error(f"Ошибка в handle_privacy_policy: {e}")
        session.rollback()
    finally:
        session.close()

async def handle_contact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик получения номера телефона"""
    if not update.message.contact:
        return
    
    user = update.effective_user
    contact = update.message.contact
    
    # Проверяем, что контакт принадлежит пользователю
    if contact.user_id != user.id:
        await update.message.reply_text("Пожалуйста, поделитесь своим номером телефона.")
        return
    
    engine = context.bot_data.get('engine')
    if not engine:
        return
    
    session = get_session(engine)
    
    try:
        # Находим пользователя
        db_user = session.query(User).filter_by(telegram_id=user.id).first()
        if not db_user:
            await update.message.reply_text("Пожалуйста, начните с команды /start")
            return
        
        # Сохраняем номер телефона
        db_user.phone_number = contact.phone_number
        
        # Убеждаемся, что настройки установлены
        if not db_user.settings:
            db_user.settings = {
                'reminders': True,
                'notifications': True,
                'timezone': 'Europe/Moscow'
            }
        
        # Отправляем приветственное сообщение и главное меню
        welcome_text = """Добро пожаловать в **«Бестужевки»** 💙

«Бестужевки» — это онлайн-клуб, где раз в неделю проходят **лекции и живые встречи в Zoom** на темы:
— история России
— русское искусство
— этикет и культура общения
— философия русской души

Хочешь узнать подробнее?"""
        
        await update.message.reply_text(
            welcome_text,
            reply_markup=get_main_menu_keyboard(),
            parse_mode='Markdown'
        )
        
        # Убираем состояние ожидания
        if 'awaiting_phone' in context.user_data:
            del context.user_data['awaiting_phone']
        
        session.commit()
        
        # Логируем успешную регистрацию
        logger.info(f"Пользователь {user.id} завершил регистрацию, телефон: {contact.phone_number}")
        logger.debug(f"Настройки пользователя: {db_user.settings}")
        
    except Exception as e:
        logger.error(f"Ошибка в handle_contact: {e}")
        session.rollback()
    finally:
        session.close()