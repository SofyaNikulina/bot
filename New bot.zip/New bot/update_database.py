# update_database.py
from database import init_db, Base
from sqlalchemy import create_engine
from config import Config
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def update_database():
    """Обновление структуры базы данных"""
    try:
        # Подключаемся к БД
        engine = create_engine(Config.DATABASE_URL)
        
        # Создаем ВСЕ таблицы (включая новые)
        Base.metadata.create_all(engine)
        
        logger.info("✅ Структура базы данных успешно обновлена!")
        logger.info("   Созданы таблицы: user_messages, admin_replies")
        
    except Exception as e:
        logger.error(f"❌ Ошибка обновления базы данных: {e}")

if __name__ == '__main__':
    update_database()