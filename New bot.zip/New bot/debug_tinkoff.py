# debug_tinkoff.py
import os
import sys
import hashlib
import json
from dotenv import load_dotenv

# Добавляем путь к проекту
sys.path.append('.')

load_dotenv()

print("=" * 70)
print("ДИАГНОСТИКА ТИНЬКОФФ API")
print("=" * 70)

# 1. Проверка переменных окружения
terminal_id = os.getenv('TINKOFF_TERMINAL_ID', '')
terminal_password = os.getenv('TINKOFF_TERMINAL_PASSWORD', '')

print("🔍 ПРОВЕРКА НАСТРОЕК:")
print(f"  Terminal ID: {'✅ ' + terminal_id if terminal_id else '❌ НЕ УКАЗАН'}")
print(f"  Terminal Password: {'✅ ' + '*****' + terminal_password[-3:] if terminal_password else '❌ НЕ УКАЗАН'}")
print(f"  Длина Terminal ID: {len(terminal_id)} символов")
print(f"  Длина Password: {len(terminal_password)} символов")

if not terminal_id or not terminal_password:
    print("\n❌ ОШИБКА: Заполните .env файл с данными Тинькофф!")
    sys.exit(1)

# 2. Проверка формата данных
print("\n🔍 ПРОВЕРКА ФОРМАТА ДАННЫХ:")
if terminal_id.isdigit():
    print("  ✅ Terminal ID состоит из цифр")
else:
    print("  ⚠️  Terminal ID содержит не только цифры")

# 3. Тест генерации токена
print("\n🔍 ТЕСТ ГЕНЕРАЦИИ ТОКЕНА:")
test_data = {
    "TerminalKey": terminal_id,
    "Amount": 100000,  # 1000 рублей
    "OrderId": "test_order_12345",
    "Description": "Тестовый платеж"
}

# Функция генерации токена (из вашего кода)
def generate_token(data_dict, password):
    sorted_data = dict(sorted(data_dict.items()))
    values = []
    for key, value in sorted_data.items():
        if key == "Token":
            continue
        if isinstance(value, dict):
            value = json.dumps(value, separators=(',', ':'))
        values.append(str(value))
    values.append(password)
    concatenated = ''.join(values)
    return hashlib.sha256(concatenated.encode('utf-8')).hexdigest()

test_token = generate_token(test_data, terminal_password)
print(f"  ✅ Токен сгенерирован: {test_token[:20]}...")
print(f"  Длина токена: {len(test_token)} символов")

# 4. Тестовый запрос к API
print("\n🔍 ТЕСТОВЫЙ ЗАПРОС К API:")
import requests

api_url = "https://securepay.tinkoff.ru/v2/"

# Создаем тестовый запрос
test_data["Token"] = test_token

print(f"  URL: {api_url}Init")
print(f"  TerminalKey: {terminal_id}")
print(f"  Amount: {test_data['Amount']} коп. ({test_data['Amount']/100} руб.)")
print(f"  OrderId: {test_data['OrderId']}")
print(f"  Description: {test_data['Description']}")

try:
    response = requests.post(f"{api_url}Init", json=test_data, timeout=10)
    result = response.json()
    
    print(f"\n📨 ОТВЕТ ОТ ТИНЬКОФФ:")
    print(f"  Success: {result.get('Success', False)}")
    print(f"  ErrorCode: {result.get('ErrorCode', 'нет')}")
    print(f"  Message: {result.get('Message', 'нет')}")
    
    if result.get("Success"):
        print(f"\n✅ ТЕСТ ПРОЙДЕН УСПЕШНО!")
        print(f"  PaymentId: {result.get('PaymentId')}")
        print(f"  PaymentURL: {result.get('PaymentURL')}")
    else:
        print(f"\n❌ ОШИБКА В ЗАПРОСЕ!")
        
        # Анализ кодов ошибок
        error_code = result.get('ErrorCode', '')
        error_msg = result.get('Message', '')
        
        print(f"\n🔧 АНАЛИЗ ОШИБКИ {error_code}:")
        if error_code == "204":
            print("  'Неверные параметры' - возможные причины:")
            print("  1. Неверный TerminalKey или Password")
            print("  2. Terminal неактивен в личном кабинете")
            print("  3. Некорректный формат данных")
        elif error_code == "100":
            print("  'Терминал не найден' - проверьте Terminal ID")
        elif error_code == "101":
            print("  'Неверный пароль' - проверьте Terminal Password")
        elif error_code == "103":
            print("  'Сумма меньше минимальной' - минимальная сумма 100 коп. (1 рубль)")
        elif error_code == "104":
            print("  'Сумма больше максимальной'")
        
        print(f"\n📋 ПОЛНЫЙ ОТВЕТ ОТ API:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        
except Exception as e:
    print(f"\n❌ ОШИБКА ПРИ ВЫПОЛНЕНИИ ЗАПРОСА: {e}")

print("\n" + "=" * 70)
print("РЕКОМЕНДАЦИИ:")
print("=" * 70)
print("1. Убедитесь, что Terminal активен в ЛК Тинькофф Бизнес")
print("2. Проверьте корректность Terminal ID и Password")
print("3. Для тестов используйте фиксированные данные:")
print("   - OrderId: 'test_12345' (до 64 символов)")
print("   - Amount: 100000 (1000 рублей)")
print("   - Description: 'Тестовый платеж' (до 250 символов)")
print("4. Убедитесь, что тестовый режим включен в .env:")
print("   TINKOFF_TEST_MODE=true")