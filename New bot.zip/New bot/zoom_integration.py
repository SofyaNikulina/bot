# zoom_integration.py - ИСПРАВЛЕННАЯ ВЕРСИЯ
import requests
import base64
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Optional
from config import Config
import asyncio
import time
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)

# Executor для асинхронных HTTP запросов
executor = ThreadPoolExecutor(max_workers=5)

class ZoomIntegration:
    def __init__(self):
        self.account_id = Config.ZOOM_ACCOUNT_ID
        self.client_id = Config.ZOOM_CLIENT_ID
        self.client_secret = Config.ZOOM_CLIENT_SECRET
        self.api_key = Config.ZOOM_API_KEY
        self.api_secret = Config.ZOOM_API_SECRET
        self.base_url = "https://api.zoom.us/v2"
        self.access_token = None
        self.token_expires = None
        self.use_jwt = False
        
        logger.info(f"🔄 Инициализация ZoomIntegration")
        
        # Проверяем, какой метод аутентификации доступен
        if self.api_key and self.api_secret:
            self.use_jwt = True
            logger.info(f"📝 Используется JWT аутентификация")
        elif self.client_id and self.client_secret and self.account_id:
            logger.info(f"📝 Используется OAuth аутентификация")
        else:
            logger.warning("⚠️ Zoom API не настроен. Проверьте переменные в .env")
    
    def _sync_get_access_token(self) -> Optional[str]:
        """СИНХРОННАЯ версия получения токена"""
        logger.debug(f"🔍 Получение токена: JWT={self.use_jwt}, OAuth={bool(self.client_id)}")
        
        if not Config.ZOOM_ENABLED:
            logger.warning("❌ Zoom API отключен в настройках")
            return None
        
        try:
            # Если используем JWT
            if self.use_jwt:
                import jwt
                
                # Проверяем, не истек ли текущий токен
                if self.access_token and self.token_expires and datetime.now() < self.token_expires:
                    logger.debug(f"📝 Использую существующий JWT токен")
                    return self.access_token
                
                # Генерируем новый JWT токен
                payload = {
                    "iss": self.api_key,
                    "exp": int(time.time()) + 3600  # 1 час
                }
                
                self.access_token = jwt.encode(payload, self.api_secret, algorithm="HS256")
                self.token_expires = datetime.now() + timedelta(minutes=50)
                
                logger.info("✅ JWT токен для Zoom сгенерирован")
                return self.access_token
            
            # Используем OAuth
            if not self.client_id or not self.client_secret or not self.account_id:
                logger.error("❌ Не хватает данных для OAuth аутентификации")
                return None
            
            # Проверяем, не истек ли текущий токен
            if self.access_token and self.token_expires and datetime.now() < self.token_expires:
                logger.debug(f"📝 Использую существующий OAuth токен")
                return self.access_token
            
            # Кодируем client_id:client_secret
            credentials = f"{self.client_id}:{self.client_secret}"
            encoded_credentials = base64.b64encode(credentials.encode()).decode()
            
            headers = {
                "Authorization": f"Basic {encoded_credentials}",
                "Content-Type": "application/x-www-form-urlencoded"
            }
            
            data = {
                "grant_type": "account_credentials",
                "account_id": self.account_id
            }
            
            logger.info(f"🔄 Запрос OAuth токена к Zoom")
            
            response = requests.post(
                "https://zoom.us/oauth/token",
                headers=headers,
                data=data,
                timeout=15
            )
            
            logger.debug(f"📥 Ответ OAuth: статус {response.status_code}")
            
            if response.status_code == 200:
                token_data = response.json()
                self.access_token = token_data['access_token']
                self.token_expires = datetime.now() + timedelta(minutes=50)
                
                logger.info("✅ OAuth токен для Zoom получен")
                return self.access_token
            else:
                logger.error(f"❌ OAuth ошибка Zoom: {response.status_code}")
                logger.error(f"   Ответ: {response.text[:200]}")
                return None
                
        except Exception as e:
            logger.error(f"❌ Ошибка получения токена Zoom: {e}")
            return None
    
    async def get_access_token(self) -> Optional[str]:
        """Асинхронная версия получения токена"""
        loop = asyncio.get_event_loop()
        try:
            token = await loop.run_in_executor(executor, self._sync_get_access_token)
            return token
        except Exception as e:
            logger.error(f"❌ Асинхронная ошибка получения токена: {e}")
            return None
    
    def _sync_create_meeting(self, topic: str, start_time: datetime, duration: int = 90) -> Optional[Dict]:
        """СИНХРОННАЯ версия создания Zoom встречи"""
        logger.info(f"🔄 Создание встречи: '{topic[:30]}...' на {start_time}")
        
        token = self._sync_get_access_token()
        if not token:
            logger.error("❌ Не удалось получить токен для создания встречи")
            return None
        
        try:
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            }
            
            # Форматируем время для Zoom API
            start_time_str = start_time.strftime('%Y-%m-%dT%H:%M:%S')
            
            # Генерируем пароль
            import random
            import string
            digits = ''.join(random.choices(string.digits, k=4))
            letters = ''.join(random.choices(string.ascii_lowercase, k=2))
            password = digits + letters
            
            logger.debug(f"🔑 Сгенерирован пароль: {password}")
            
            meeting_data = {
                "topic": f"«Бестужевки»: {topic}",
                "type": 2,  # Scheduled meeting
                "start_time": start_time_str,
                "duration": duration,
                "timezone": "Europe/Moscow",
                "password": password,
                "settings": {
                    "host_video": True,
                    "participant_video": True,
                    "join_before_host": False,
                    "mute_upon_entry": True,
                    "waiting_room": False,
                    "registrants_email_notification": False,
                    "auto_recording": "cloud"
                }
            }
            
            logger.debug(f"📤 Отправка запроса к Zoom API...")
            
            response = requests.post(
                f"{self.base_url}/users/me/meetings",
                headers=headers,
                json=meeting_data,
                timeout=20
            )
            
            logger.info(f"📥 Ответ Zoom API: статус {response.status_code}")
            
            if response.status_code in [200, 201]:
                meeting = response.json()
                
                result = {
                    'id': str(meeting['id']),
                    'join_url': meeting['join_url'],
                    'start_url': meeting.get('start_url', ''),
                    'password': meeting['password'],
                    'topic': meeting['topic'],
                    'start_time': meeting['start_time'],
                    'duration': meeting['duration']
                }
                
                logger.info(f"✅ Встреча создана: ID={result['id']}")
                logger.info(f"   Ссылка: {result['join_url']}")
                logger.info(f"   Пароль: {result['password']}")
                
                return result
            else:
                logger.error(f"❌ Ошибка Zoom API: {response.status_code}")
                logger.error(f"   Полный ответ: {response.text}")
                return None
                
        except requests.exceptions.Timeout:
            logger.error("❌ Таймаут при создании встречи Zoom")
            return None
        except Exception as e:
            logger.error(f"❌ Ошибка создания встречи Zoom: {e}")
            return None
    
    async def create_meeting(self, topic: str, start_time: datetime, duration: int = 90) -> Optional[Dict]:
        """Асинхронное создание Zoom встречи"""
        loop = asyncio.get_event_loop()
        try:
            result = await loop.run_in_executor(executor, self._sync_create_meeting, topic, start_time, duration)
            return result
        except Exception as e:
            logger.error(f"❌ Асинхронная ошибка создания встречи: {e}")
            return None

# Синглтон
_zoom_instance = None

def get_zoom_instance():
    """Получение экземпляра Zoom"""
    global _zoom_instance
    
    if not Config.ZOOM_ENABLED:
        logger.warning("⚠️ Zoom API отключен в настройках")
        return None
    
    if _zoom_instance is None:
        logger.info("🔄 Создание экземпляра ZoomIntegration")
        _zoom_instance = ZoomIntegration()
    
    return _zoom_instance

async def create_zoom_meeting(topic: str, start_time: datetime, duration: int = 90) -> Optional[Dict]:
    """Создание встречи (обертка)"""
    logger.info(f"🎬 ВЫЗВАНА create_zoom_meeting")
    logger.info(f"   Тема: {topic}")
    logger.info(f"   Время: {start_time}")
    logger.info(f"   Длительность: {duration} мин")
    
    zoom = get_zoom_instance()
    
    if not zoom:
        logger.error("❌ Zoom API не настроен или произошла ошибка инициализации")
        return None
    
    logger.info(f"✅ Экземпляр Zoom получен, начинаю создание встречи...")
    result = await zoom.create_meeting(topic, start_time, duration)
    
    if result:
        logger.info(f"🎉 Zoom встреча УСПЕШНО создана!")
        logger.info(f"   ID встречи: {result['id']}")
        logger.info(f"   Ссылка: {result['join_url']}")
        logger.info(f"   Пароль: {result['password']}")
    else:
        logger.error("💥 Zoom встреча НЕ создана. Результат None.")
    
    return result