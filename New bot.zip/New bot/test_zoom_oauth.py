# test_zoom_oauth.py
import asyncio
import sys
import os
from datetime import datetime, timedelta

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from config import Config
from zoom_integration import get_zoom_instance, create_zoom_meeting

async def test_zoom_oauth():
    """Тест OAuth Zoom API"""
    print("🧪 Тестирование Zoom OAuth API...")
    
    print(f"🔧 Конфигурация Zoom:")
    print(f"   ZOOM_ENABLED: {Config.ZOOM_ENABLED}")
    print(f"   ZOOM_ACCOUNT_ID: {'Установлен' if Config.ZOOM_ACCOUNT_ID else 'Нет'}")
    print(f"   ZOOM_CLIENT_ID: {'Установлен' if Config.ZOOM_CLIENT_ID else 'Нет'}")
    print(f"   ZOOM_CLIENT_SECRET: {'Установлен' if Config.ZOOM_CLIENT_SECRET else 'Нет'}")
    
    if not Config.ZOOM_ENABLED:
        print("❌ Zoom API отключен в конфиге")
        return
    
    # Получаем экземпляр Zoom
    zoom = get_zoom_instance()
    if not zoom:
        print("❌ Не удалось создать экземпляр Zoom")
        return
    
    print(f"✅ Экземпляр Zoom создан")
    print(f"   Использует: {'JWT' if zoom.use_jwt else 'OAuth'}")
    
    # Тест получения токена
    print(f"\n🔄 Тест получения OAuth токена...")
    try:
        token = await zoom.get_access_token()
        if token:
            print(f"✅ OAuth токен получен!")
            print(f"   Длина токена: {len(token)} символов")
            print(f"   Первые 20 символов: {token[:20]}...")
        else:
            print("❌ Не удалось получить токен")
            return
    except Exception as e:
        print(f"❌ Ошибка получения токена: {e}")
        return
    
    # Тест создания встречи
    print(f"\n🔄 Тест создания Zoom встречи...")
    tomorrow = datetime.now() + timedelta(days=1)
    print(f"   Дата встречи: {tomorrow.strftime('%d.%m.%Y %H:%M')}")
    
    try:
        result = await create_zoom_meeting(
            topic="Тестовая встреча из бота",
            start_time=tomorrow,
            duration=60
        )
        
        if result:
            print(f"🎉 ТЕСТ УСПЕШЕН! Встреча создана!")
            print(f"   ID встречи: {result['id']}")
            print(f"   Ссылка: {result['join_url']}")
            print(f"   Пароль: {result['password']}")
            print(f"   Тема: {result['topic']}")
            
            # Проверяем ссылку
            if 'zoom.us' in result['join_url']:
                print(f"✅ Ссылка валидная (содержит zoom.us)")
            else:
                print(f"⚠️ Ссылка может быть невалидной")
        else:
            print("❌ Встреча не создана (результат None)")
            print("   Возможные причины:")
            print("   1. Неправильные OAuth ключи")
            print("   2. Проблемы с доступом к Zoom API")
            print("   3. Ограничения аккаунта Zoom")
            
    except Exception as e:
        print(f"❌ Ошибка создания встречи: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_zoom_oauth())