# check_tables.py
from sqlalchemy import create_engine, inspect
from config import Config

engine = create_engine(Config.DATABASE_URL)
inspector = inspect(engine)

print("📊 Таблицы в базе данных:")
for table_name in inspector.get_table_names():
    print(f"  • {table_name}")

# Проверяем наличие нужных таблиц
required_tables = ['user_messages', 'admin_replies']
print("\n🔍 Проверка наличия таблиц:")
for table in required_tables:
    exists = table in inspector.get_table_names()
    status = "✅" if exists else "❌"
    print(f"  {status} {table}")